# MAI v0.9.2 - VNyan movement, eyes and expressions

MAI now emits high-level avatar cues while VNyan handles smooth animation.

## 1. Built-in motion to enable in VNyan

Open `Menu > Settings` and enable/configure these model-motion features:

- Breathing Motion
- Arm Sway
- Expressive Body Tilt

Keep them subtle. They are the always-on idle layer; MAI's cues sit on top.

## 2. Lip sync

Set `Menu > Settings > Audio > Lip Sync Input` to the VB-CABLE recording side (`CABLE Output`). MAI mirrors TTS to the cable automatically when `MAI_AVATAR_AUDIO_DEVICE` is configured.

## 3. Eye/blink options

### Fastest option: VNyan webcam tracking

Under Web Camera Tracking:

- select your webcam;
- enable `Use Eye Bones` when the model supports eye bones;
- run `Calibrate Eyes and Blinks`;
- use tracking/body/blendshape smoothing to reduce jitter;
- reduce Gaze Strength if the eyes move too aggressively.

This makes the avatar follow your head/eyes. Audio lip sync can still be used for MAI's voice.

### Autonomous MAI option

MAI sends these VNyan REST actions:

- `mai_blink` - `duration_ms`
- `mai_look` - `x`, `y`, `hold_ms`
- `mai_idle` - `head_yaw`, `head_pitch`, `head_roll`, `body_sway`, `energy`, `speaking`
- `mai_expression` - `name`, `intensity`
- `mai_state` - expression plus MAI's current emotional-state values
- `mai_speaking_start`
- `mai_speaking_stop`

Create an `API Message` node for each action you want to use. VNyan receives these on `http://localhost:8069`. Map the payload values through VNyan parameters/math/smoothing to Additive Bone Rotation or expression/blendshape nodes. Use additive rotations for head/body offsets so they blend with other tracking layers instead of replacing them.

Recommended expression names from MAI are:

- neutral
- happy
- excited
- curious
- focused
- playful
- concerned

Map these to the closest expression/blendshape set available on your particular VRM model.

## 4. MAI configuration

Add or update:

```text
MAI_AVATAR_ENABLED=true
MAI_AVATAR_BACKEND=vnyan
MAI_AVATAR_AUDIO_DEVICE=CABLE Input (VB-Audio Virtual Cable)
MAI_AVATAR_VNYAN_URL=http://127.0.0.1:8069
MAI_AVATAR_EVENTS=true
MAI_AVATAR_AUTONOMY=true
MAI_AVATAR_IDLE_MIN_SECONDS=2.8
MAI_AVATAR_IDLE_MAX_SECONDS=6.0
```

Use the exact VB-CABLE playback-device name shown by `/audio-devices` on your PC.

## 5. Tests

Start VNyan and MAI, then run:

```text
/avatar-status
/avatar-test
/avatar-idle-test
/avatar-look 0.5 0.1 1500
/avatar-expression happy 0.8
/voice-test
```

`/avatar-idle-test` sends a head/body cue, gaze cue and blink cue together.

## 6. Dance layer

Do not use the idle/head-offset system as the dance engine. Dance should use a humanoid animation or mocap layer (MMD/VNyan injected animation/VMC/full-body tracking). The idle cues can be reduced or disabled while a choreography animation is playing. This keeps foot placement, hips and arm movement coherent.
