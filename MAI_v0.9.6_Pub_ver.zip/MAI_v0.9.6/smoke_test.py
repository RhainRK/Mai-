from __future__ import annotations

from time import perf_counter

from config import settings


def _ollama_smoke() -> tuple[str, float, str]:
    try:
        from ollama import Client
    except ImportError as exc:
        raise SystemExit(
            "Missing core dependency 'ollama'. Run: python -m pip install -r requirements-core.txt"
        ) from exc

    from idol.model_selection import require_available, resolve_ollama_model

    selection = resolve_ollama_model(
        settings.ollama_url,
        settings.ollama_model,
        settings.ollama_preferred_model,
        settings.ollama_fallback_model,
    )
    model = require_available(selection)
    client = Client(host=settings.ollama_url, timeout=60.0)
    try:
        started = perf_counter()
        options = {"temperature": 0, "num_predict": 16}
        if settings.ollama_num_ctx > 0:
            options["num_ctx"] = settings.ollama_num_ctx
        response = client.chat(
            model=model,
            messages=[{"role": "user", "content": "Reply with exactly: MAI_OK"}],
            stream=False,
            think=False,
            keep_alive=settings.ollama_keep_alive,
            options=options,
        )
        return (response.message.content or "").strip(), perf_counter() - started, model
    finally:
        client.close()


def _openai_compatible_smoke() -> tuple[str, float, str]:
    try:
        from openai import OpenAI
    except ImportError as exc:
        raise SystemExit(
            "Missing core dependency 'openai'. Run: python -m pip install -r requirements-core.txt"
        ) from exc

    client = OpenAI(
        api_key=settings.api_key or "local",
        base_url=settings.api_base_url,
        timeout=60.0,
    )
    try:
        started = perf_counter()
        response = client.chat.completions.create(
            model=settings.api_model,
            messages=[{"role": "user", "content": "Reply with exactly: MAI_OK"}],
            temperature=0,
            max_tokens=16,
        )
        content = (response.choices[0].message.content or "").strip()
        return content, perf_counter() - started, settings.api_model
    finally:
        client.close()


def main():
    if settings.llm_backend == "ollama":
        content, elapsed, model = _ollama_smoke()
    else:
        content, elapsed, model = _openai_compatible_smoke()

    print(f"Testing {model}...")
    print(f"Reply: {content}")
    print(f"Time: {elapsed:.1f}s")
    if "MAI_OK" not in content:
        raise SystemExit("Unexpected model response")
    print("MODEL BACKEND OK")


if __name__ == "__main__":
    main()
