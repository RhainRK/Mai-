# MAI v0.9.2 Avatar Setup

MAI uses VNyan as the 3D avatar renderer and VB-CABLE as the lip-sync audio route.

## Software

1. VNyan for the VRM avatar.
2. VB-CABLE Virtual Audio Device for sending MAI's TTS audio into VNyan.
3. MAI's existing Python voice dependencies.

Unity is not required for this first talking-avatar setup. Keep it for later model editing and custom stage work.

## 1. Install VNyan

Install VNyan, open it, and use the startup wizard to load the downloaded `.vrm` avatar.

## 2. Install VB-CABLE

Install VB-CABLE as administrator and reboot Windows. It creates two endpoints:

- `CABLE Input` - playback endpoint
- `CABLE Output` - recording endpoint

MAI sends her TTS audio to `CABLE Input`. VNyan listens to `CABLE Output`.

## 3. Configure VNyan lip sync

In VNyan open `Menu > Settings > Audio > Lip Sync Input` and choose `CABLE Output`.

Adjust Gain and Smoothing only after the basic mouth movement works.

## 4. Find the exact Windows device name

Start MAI and run:

```text
/audio-devices
```

Find the output device containing `CABLE Input`. Copy its exact name or index.

## 5. Configure MAI

Add these values to `.env`:

```text
MAI_AVATAR_ENABLED=true
MAI_AVATAR_BACKEND=vnyan
MAI_AVATAR_AUDIO_DEVICE=CABLE Input (VB-Audio Virtual Cable)
MAI_AVATAR_VNYAN_URL=http://127.0.0.1:8069
MAI_AVATAR_EVENTS=true
```

If the full device name differs, use the exact value shown by `/audio-devices`. A numeric device index also works.

Leave `MAI_AUDIO_OUTPUT_DEVICE=` blank to keep MAI audible through the normal Windows default speakers while the same speech is mirrored to VNyan for lip sync.

## 6. Test

With VNyan open and the avatar loaded:

```text
/avatar-status
/voice-test
```

You should hear MAI from the normal speakers and see the avatar lip-sync to the same speech.

Then test a real turn:

```text
/talk
```

or continuous conversation:

```text
/voice-loop
```

## Optional VNyan events

MAI also sends these VNyan REST actions while speaking:

- `mai_speaking_start`
- `mai_speaking_stop`
- `mai_avatar_test`

VNyan does not need these actions for basic audio lip sync. They are hooks for later expressions, idle/speaking animations, gestures and stage effects.

To use them, add an `API Message` node in VNyan with the matching Action value. VNyan's built-in REST API listens on port `8069`.

## Dance roadmap

VNyan can play MMD/humanoid animations and supports full-body tracking. The avatar bridge is deliberately separate from MAI's LLM and TTS so dance control can be added without changing her conversational brain.


## Movement, gaze and expressions

MAI v0.9.2 adds autonomous presentation cues for blinking, gaze, subtle idle head/body movement and state-driven expressions. See `VNYAN_MOVEMENT_SETUP.md` for the VNyan graph setup and test commands.
