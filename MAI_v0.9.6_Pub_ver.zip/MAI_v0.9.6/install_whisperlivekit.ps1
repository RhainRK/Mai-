$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Stop-Install([string]$Message) {
    Write-Host ""
    Write-Host "ERROR: $Message" -ForegroundColor Red
    exit 1
}

$PythonCommand = $null
$PythonPrefixArgs = @()

if (Get-Command py -ErrorAction SilentlyContinue) {
    $PythonCommand = "py"
    $PythonPrefixArgs = @("-3.11")
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $PythonCommand = "python"
} else {
    Stop-Install "Python was not found. Install 64-bit Python 3.11 first."
}

& $PythonCommand @PythonPrefixArgs -c "import struct,sys; assert sys.version_info[:2] == (3, 11); assert struct.calcsize('P') * 8 == 64" 2>$null
if ($LASTEXITCODE -ne 0) {
    Stop-Install "Python 3.11 64-bit was not found. WhisperLiveKit supports Python >=3.11,<3.14; MAI standardizes on 3.11."
}

if (-not (Test-Path ".venv-wlk\Scripts\python.exe")) {
    Write-Host "Creating isolated WhisperLiveKit environment (.venv-wlk)..."
    & $PythonCommand @PythonPrefixArgs -m venv .venv-wlk
    if ($LASTEXITCODE -ne 0) { Stop-Install "Could not create .venv-wlk." }
}

$Python = Join-Path $PSScriptRoot ".venv-wlk\Scripts\python.exe"
& $Python -m pip install --upgrade pip setuptools wheel
if ($LASTEXITCODE -ne 0) { Stop-Install "Could not update pip tooling." }

Write-Host "Installing WhisperLiveKit in its isolated environment..."
& $Python -m pip install --upgrade whisperlivekit
if ($LASTEXITCODE -ne 0) { Stop-Install "WhisperLiveKit installation failed." }

Write-Host ""
& $Python -c "import importlib.metadata as m; print('WhisperLiveKit', m.version('whisperlivekit'))"
Write-Host ""
Write-Host "WhisperLiveKit installed." -ForegroundColor Green
Write-Host "Use start_whisperlivekit.bat to launch the local STT server."
Write-Host "MAI sends raw 16-bit PCM, so the launch script enables --pcm-input."
