@echo off
cd /d "%~dp0"
where ollama >nul 2>nul
if errorlevel 1 (
    echo Ollama was not found.
    pause
    exit /b 1
)
echo Ensuring MAI's preferred default brain is installed: qwen3.5:4b
echo.
ollama pull qwen3.5:4b
if errorlevel 1 (
    echo Model installation failed.
    pause
    exit /b 1
)
echo.
echo Installed qwen3.5:4b.
echo MAI v0.9.2 will select it automatically on the next launch.
pause
