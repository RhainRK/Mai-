from __future__ import annotations

from pathlib import Path
import sys


VALID = {
    "auto",
    "qwen3:4b",
    "qwen3.5:4b",
    "qwen3.6:27b",
    "qwen3.6:35b",
}


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in VALID:
        raise SystemExit(
            "Use: python model_switch.py "
            "auto|qwen3:4b|qwen3.5:4b|qwen3.6:27b|qwen3.6:35b"
        )
    model = sys.argv[1]
    path = Path(__file__).with_name(".env")
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    key = "MAI_OLLAMA_MODEL="
    replaced = False
    output = []
    for line in lines:
        if line.startswith(key):
            output.append(f"{key}{model}")
            replaced = True
        else:
            output.append(line)
    if not replaced:
        output.append(f"{key}{model}")
    path.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")
    print(f"MAI model preference set to {model}")


if __name__ == "__main__":
    main()
