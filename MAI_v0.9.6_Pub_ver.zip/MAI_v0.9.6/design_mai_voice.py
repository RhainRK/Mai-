from __future__ import annotations

import base64
import json
import os
from pathlib import Path

import httpx


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "data" / "voices" / "mai" / "previews"
DESCRIPTION = (
    "An original young-adult feminine pop-artist voice. Warm, polished and naturally magnetic, "
    "with a clear modern international-English delivery and a subtle British colour. Medium pitch, "
    "smooth low-mid warmth, bright clean upper resonance without sounding childish or piercing, "
    "crisp diction, relaxed conversational rhythm, quick dry humour, and confident controlled energy. "
    "She should sound human and effortless off stage: poised, witty, friendly, slightly mischievous, "
    "never overly bubbly, breathy, nasal, theatrical or announcer-like. Capable of selective softness "
    "and emotional warmth while keeping self-possession and a distinctive contemporary pop-star presence."
)
SAMPLE = (
    "Okay, that's actually kind of brilliant. I was going to pretend I'm completely unbothered, "
    "but now I'm curious. Give me a second—there's definitely a cleaner way to do this, and I refuse "
    "to let a tiny bug win. Anyway. Hi, I'm MAI. Calm under pressure, mostly."
)


def load_env_value(name: str) -> str:
    value = os.getenv(name, "").strip()
    if value:
        return value
    env = ROOT / ".env"
    if env.exists():
        for raw in env.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, item = line.split("=", 1)
            if key.strip() == name:
                return item.strip().strip('"').strip("'")
    return ""


def main():
    api_key = load_env_value("MAI_ELEVENLABS_API_KEY")
    if not api_key:
        raise SystemExit("Set MAI_ELEVENLABS_API_KEY in .env before running this tool.")

    OUT.mkdir(parents=True, exist_ok=True)
    response = httpx.post(
        "https://api.elevenlabs.io/v1/text-to-voice/design",
        headers={"xi-api-key": api_key, "Content-Type": "application/json"},
        params={"output_format": "mp3_44100_128"},
        json={
            "voice_description": DESCRIPTION,
            "text": SAMPLE,
            "auto_generate_text": False,
            "model_id": "eleven_ttv_v3",
        },
        timeout=180.0,
    )
    response.raise_for_status()
    data = response.json()

    rows = []
    for index, preview in enumerate(data.get("previews", []), start=1):
        audio = base64.b64decode(preview["audio_base_64"])
        path = OUT / f"mai_voice_{index}.mp3"
        path.write_bytes(audio)
        rows.append(
            {
                "index": index,
                "file": str(path.relative_to(ROOT)),
                "generated_voice_id": preview["generated_voice_id"],
                "duration_secs": preview.get("duration_secs"),
                "language": preview.get("language"),
            }
        )

    manifest = {
        "voice_description": DESCRIPTION,
        "sample_text": data.get("text", SAMPLE),
        "previews": rows,
    }
    manifest_path = OUT / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"Generated {len(rows)} MAI voice previews:")
    for row in rows:
        print(f"  [{row['index']}] {row['file']}")
    print("Listen to them, then run: python select_mai_voice.py <number>")


if __name__ == "__main__":
    main()
