from __future__ import annotations

import argparse
import json
from pathlib import Path

from idol.code_graph import CodeGraph


def main() -> None:
    parser = argparse.ArgumentParser(description="Index and query MAI's local code graph.")
    parser.add_argument("command", choices=("index", "query", "export"))
    parser.add_argument("value", nargs="?", default="")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    graph = CodeGraph(root / "data" / "mai_code_graph.sqlite3")
    if args.command == "index":
        result = graph.index(root)
    elif args.command == "query":
        result = graph.query(args.value)
    else:
        destination = Path(args.value or root / "data" / "mai_code_graph.json")
        graph.export_json(destination)
        result = {"exported": str(destination)}
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
