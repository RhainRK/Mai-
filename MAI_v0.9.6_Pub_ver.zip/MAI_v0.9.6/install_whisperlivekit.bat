@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_whisperlivekit.ps1"
if errorlevel 1 (
    echo.
    echo WhisperLiveKit setup did not complete successfully.
    pause
    exit /b 1
)
pause
