from idol.tool_router import ToolRouter


def test_tool_router_routes_only_relevant_group():
    router = ToolRouter()
    assert router.route("let's play chess") == ("chess.",)
    assert router.route("teach me this skill") == ("learning.",)
    assert router.route("make this a goal") == ("goals.",)
    assert router.route("we decided the debut direction") == ("continuity.",)


def test_tool_router_keeps_normal_analysis_in_chat():
    router = ToolRouter()
    assert router.route("analyse why the sky is blue") == ()
    assert router.route("I changed my mind about lunch") == ()
