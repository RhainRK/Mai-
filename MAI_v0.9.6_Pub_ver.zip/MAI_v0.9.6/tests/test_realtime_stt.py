import asyncio

import pytest

from idol.realtime.stt import WhisperLiveKitClient


def test_extract_lines():
    committed, partial = WhisperLiveKitClient._extract(
        {
            "lines": [
                {"text": "hello", "speaker": 1},
                {"text": "world", "speaker": 1},
            ],
            "buffer_transcription": "hello world again",
        }
    )
    assert committed == "hello world"
    assert partial == "again"


def test_next_event_surfaces_receiver_failure_instead_of_hanging():
    async def run():
        client = WhisperLiveKitClient("ws://127.0.0.1:8000")

        async def fail():
            await asyncio.sleep(0)
            raise RuntimeError("socket failed")

        client.receiver = asyncio.create_task(fail())
        with pytest.raises(RuntimeError, match="Streaming STT receiver failed: socket failed"):
            await asyncio.wait_for(client.next_event(), timeout=0.5)

    asyncio.run(run())


def test_next_event_surfaces_clean_receiver_close():
    async def run():
        client = WhisperLiveKitClient("ws://127.0.0.1:8000")

        async def close_cleanly():
            await asyncio.sleep(0)

        client.receiver = asyncio.create_task(close_cleanly())
        with pytest.raises(RuntimeError, match="Streaming STT connection closed"):
            await asyncio.wait_for(client.next_event(), timeout=0.5)

    asyncio.run(run())
