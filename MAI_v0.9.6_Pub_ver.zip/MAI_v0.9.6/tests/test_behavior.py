from pathlib import Path
from types import SimpleNamespace

from idol.behavior import BehaviorProfile


PROFILE = Path(__file__).parents[1] / "data" / "persona" / "mai_profile.json"
STATE = SimpleNamespace(energy=0.7, playfulness=0.7)


def test_creative_mode():
    profile = BehaviorProfile(PROFILE)
    assert profile.mode("Let's rewrite the chorus", STATE).name == "creative"


def test_performance_mode():
    profile = BehaviorProfile(PROFILE)
    assert profile.mode("We need to rehearse the stage", STATE).name == "performance"


def test_vulnerable_mode():
    profile = BehaviorProfile(PROFILE)
    assert profile.mode("I failed and I'm worried", STATE).name == "vulnerable"


def test_fan_facing_mode_is_charming_but_not_maximal_vulnerability():
    profile = BehaviorProfile(PROFILE)
    mode = profile.mode("What would you say to your fans at a fan meeting?", STATE)
    assert mode.name == "fan_facing"
    assert mode.playful_charm >= 0.8
    assert mode.star_presence >= 0.8
    assert mode.vulnerability < mode.warmth


def test_interview_mode_is_distinct_from_relaxed_chat():
    profile = BehaviorProfile(PROFILE)
    mode = profile.mode("Press interview: tell the journalist about the new era", STATE)
    assert mode.name == "interview"
    assert mode.directness >= 0.8
    assert mode.star_presence >= 0.8


def test_serious_problem_overrides_fan_service_keywords():
    profile = BehaviorProfile(PROFILE)
    mode = profile.mode("A fan found a serious bug, fix it urgently", STATE)
    assert mode.name == "focused"


def test_creator_close_social_register_is_injected():
    profile = BehaviorProfile(PROFILE)
    relationship = SimpleNamespace(is_creator=True, familiarity=0.1)
    prompt = profile.prompt_for_relationship("Hey", STATE, relationship)
    assert "social_register=creator_close" in prompt
    assert "Rhain" in prompt


def test_profile_expression_and_design_note_reach_prompt():
    profile = BehaviorProfile(PROFILE)
    prompt = profile.prompt("Hey", STATE)
    assert "big_five:" in prompt
    assert "expression:" in prompt
    assert "design_note:" in prompt
