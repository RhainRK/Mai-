from pathlib import Path

from idol.code_graph import CodeGraph
from idol.context_governor import ContextGovernor
from idol.database import connect_database
from idol.memory import MemoryStore


def test_context_governor_caches_omitted_messages(tmp_path):
    conn = connect_database(tmp_path / "context.sqlite3")
    governor = ContextGovernor(conn, 6000, 0.25)
    recent = [{"role": "user", "content": "old detail " * 300} for _ in range(6)]
    result = governor.govern(recent, "new unrelated request", 4500)
    assert governor.last_report.compressed_items > 0
    key = governor.last_report.cache_keys[0]
    assert governor.retrieve(key)
    assert all(m['role'] != 'system' for m in result)


def test_memory_observation_consolidation(tmp_path, monkeypatch):
    monkeypatch.setattr("idol.memory.settings.embedding_model", "hash-v1-128")
    store = MemoryStore(str(tmp_path / "memory.sqlite3"))
    store.observe_turn("test", "Remember the blue setting", "Noted")
    store.observe_turn("test", "Continue the project", "Done")
    memory_id = store.consolidate_session("test", minimum=2)
    assert memory_id is not None
    assert store.stats()["episodes"] == 1


def test_code_graph_incremental_index(tmp_path):
    source = tmp_path / "sample.py"
    source.write_text("import json\n\ndef run():\n    return json.dumps({})\n", encoding="utf-8")
    graph = CodeGraph(tmp_path / "graph.sqlite3")
    first = graph.index(tmp_path)
    second = graph.index(tmp_path)
    assert first["changed_files"] == 1
    assert second["changed_files"] == 0
    assert graph.query("run")["nodes"]
