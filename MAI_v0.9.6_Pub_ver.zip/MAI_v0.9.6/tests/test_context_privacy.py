from idol.context import TurnContextBuilder
from idol.planner import Planner


class Persona:
    def system_description(self):
        return "PUBLIC PERSONA"


class State:
    def drift_toward_baseline(self):
        pass

    def as_prompt(self):
        return "stable"


class GuardedMemory:
    def __init__(self):
        self.private_calls = 0

    def recall(self, *args, **kwargs):
        self.private_calls += 1
        raise AssertionError("public context must not recall private memory")

    def get_profile(self):
        self.private_calls += 1
        raise AssertionError("public context must not load private profile")

    def recent_messages(self, *args, **kwargs):
        self.private_calls += 1
        raise AssertionError("public context must not load private chat history")


class Relationship:
    def as_prompt(self):
        return "PRIVATE_RELATIONSHIP_SENTINEL"


class Goals:
    def infer_turn_goal(self, text):
        return "answer the public question"

    def as_prompt(self):
        return "PRIVATE_STANDING_GOAL_SENTINEL"


class Learning:
    def context(self, text):
        return "PRIVATE_LEARNING_SENTINEL"


class Tasks:
    def context(self):
        return "PRIVATE_TASK_SENTINEL"


class Tools:
    def names(self, route=None):
        return ["PRIVATE_TOOL_SENTINEL"]


class Behavior:
    def prompt(self, text, state):
        return "broadcast-safe behavior"


class Identity:
    def canon(self, audience):
        assert audience == "public"
        return [{"key": "identity.name", "value": "MAI", "visibility": "public"}]

    def context(self, audience):
        assert audience == "public"
        return "PUBLIC_IDENTITY_CONTEXT"


class Career:
    def context_with_refs(self, text, audience):
        assert audience == "public"
        return "PUBLIC_CAREER_CONTEXT", ["identity.name"], ["evt_public"]


class Continuity:
    def context_with_refs(self, text, audience):
        assert audience == "public"
        return "PUBLIC_CONTINUITY_CONTEXT", [88]


def test_public_context_never_loads_or_embeds_private_runtime_state():
    memory = GuardedMemory()
    builder = TurnContextBuilder(
        persona=Persona(),
        state=State(),
        memory=memory,
        relationship=Relationship(),
        goals=Goals(),
        planner=Planner(),
        learning=Learning(),
        tasks=Tasks(),
        tools=Tools(),
        behavior=Behavior(),
        identity=Identity(),
        career=Career(),
        continuity=Continuity(),
        short_term_turns=14,
        memory_recall_limit=8,
    )

    retrieved = builder.retrieve("What are you working on?", public_mode=True)
    prepared = builder.prepare(
        "What are you working on?",
        (),
        retrieved,
        public_mode=True,
    )
    prompt = prepared.messages[0]["content"]

    assert memory.private_calls == 0
    assert retrieved.memory_ids == []
    assert retrieved.continuity_ids == [88]
    assert retrieved.career_event_ids == ["evt_public"]
    assert "PUBLIC_IDENTITY_CONTEXT" in prompt
    assert "PUBLIC_CAREER_CONTEXT" in prompt
    assert "PUBLIC_CONTINUITY_CONTEXT" in prompt
    assert "PRIVATE_RELATIONSHIP_SENTINEL" not in prompt
    assert "PRIVATE_STANDING_GOAL_SENTINEL" not in prompt
    assert "PRIVATE_LEARNING_SENTINEL" not in prompt
    assert "PRIVATE_TASK_SENTINEL" not in prompt
    assert "PRIVATE_TOOL_SENTINEL" not in prompt
