from idol.continuity import ContinuityStore
from idol.embeddings import SemanticEmbedder


def make_store():
    # Deterministic backend
    embedder = SemanticEmbedder("__missing_test_model__")
    return ContinuityStore(":memory:", embedder, candidate_limit=100)


def test_set_current_supersedes_old_value_without_deleting_history():
    store = make_store()
    try:
        first = store.set_current(
            "creative",
            "music.debut_direction",
            "Bright synth-pop with playful hooks.",
            reason="initial direction",
        )
        second = store.set_current(
            "creative",
            "music.debut_direction",
            "Darker electronic pop with cinematic tension.",
            reason="the project evolved",
        )

        current = store.current("creative")
        history = store.history("music.debut_direction", memory_type="creative")

        assert len(current) == 1
        assert current[0]["id"] == second["id"]
        assert current[0]["content"].startswith("Darker electronic")
        assert len(history) == 2
        assert history[0]["status"] == "superseded"
        assert history[0]["superseded_by_id"] == second["id"]
        assert history[1]["status"] == "current"
        assert history[1]["supersedes_id"] == first["id"]
    finally:
        store.close()


def test_identical_current_value_is_idempotent():
    store = make_store()
    try:
        first = store.set_current("preference", "visual.palette", "black and silver")
        second = store.set_current("preference", "visual.palette", "black and silver")
        assert first["id"] == second["id"]
        assert store.stats()["records"] == 1
    finally:
        store.close()


def test_public_context_only_exposes_public_records():
    store = make_store()
    try:
        public = store.set_current(
            "semantic", "artist.public_genre", "electronic pop", visibility="public"
        )
        store.set_current(
            "creative", "album.secret_title", "Project Moon", visibility="internal"
        )
        text, ids = store.context_with_refs("What genre and album are you making?", "public")
        assert public["id"] in ids
        assert "electronic pop" in text
        assert "Project Moon" not in text
    finally:
        store.close()


def test_history_queries_can_retrieve_superseded_direction():
    store = make_store()
    try:
        store.set_current("creative", "music.direction", "bubblegum pop")
        store.set_current("creative", "music.direction", "industrial electronic pop")
        rows = store.recall("why did the music direction change from before?", include_history=None)
        statuses = {row["status"] for row in rows}
        assert "current" in statuses
        assert "superseded" in statuses
    finally:
        store.close()


def test_retract_removes_record_from_current_context_but_keeps_history():
    store = make_store()
    try:
        row = store.set_current("semantic", "lore.test", "temporary lore")
        store.retract(row["id"], reason="not actually canon")
        assert store.current("semantic") == []
        history = store.history("lore.test")
        assert history[0]["status"] == "retracted"
        assert history[0]["reason"] == "not actually canon"
    finally:
        store.close()


def test_episode_is_historical_but_recallable_without_becoming_current_truth():
    store = make_store()
    try:
        episode = store.record_episode("studio.session", "MAI tested a brighter chorus melody.")
        assert episode["status"] == "historical"
        assert store.current("episodic") == []
        recalled = store.recall("What happened in the studio chorus session?")
        assert any(row["id"] == episode["id"] for row in recalled)
    finally:
        store.close()


def test_repeated_revisions_keep_exactly_one_current_value_and_linear_chain():
    store = make_store()
    try:
        ids = []
        for index in range(200):
            row = store.set_current(
                "creative",
                "music.long_running_direction",
                f"direction version {index}",
                reason=f"revision {index}",
            )
            ids.append(row["id"])
        current = store.current("creative")
        current_for_key = [row for row in current if row["memory_key"] == "music.long_running_direction"]
        assert len(current_for_key) == 1
        assert current_for_key[0]["id"] == ids[-1]
        history = store.history("music.long_running_direction", memory_type="creative")
        assert len(history) == 200
        for left, right in zip(history, history[1:]):
            assert left["superseded_by_id"] == right["id"]
            assert right["supersedes_id"] == left["id"]
        assert history[-1]["status"] == "current"
    finally:
        store.close()


def test_continuity_schema_can_be_added_to_existing_v17_database_without_touching_old_tables(tmp_path):
    import sqlite3

    db = tmp_path / "existing.sqlite3"
    conn = sqlite3.connect(db)
    conn.execute("CREATE TABLE messages(id INTEGER PRIMARY KEY, role TEXT, content TEXT, created_at TEXT)")
    conn.execute("INSERT INTO messages(role, content, created_at) VALUES ('user', 'legacy turn', 'now')")
    conn.commit()
    conn.close()

    embedder = SemanticEmbedder("__missing_test_model__")
    store = ContinuityStore(str(db), embedder)
    try:
        store.set_current("creative", "music.direction", "electronic pop")
    finally:
        store.close()

    conn = sqlite3.connect(db)
    try:
        assert conn.execute("SELECT content FROM messages").fetchone()[0] == "legacy turn"
        assert conn.execute("SELECT COUNT(*) FROM continuity_memories").fetchone()[0] == 1
    finally:
        conn.close()


def test_public_projection_keeps_last_announced_value_when_private_direction_changes():
    store = make_store()
    try:
        public = store.set_current(
            "creative",
            "music.debut_direction",
            "Bright futuristic pop with R&B polish.",
            visibility="public",
        )
        private = store.set_current(
            "creative",
            "music.debut_direction",
            "A darker unannounced electronic direction.",
            visibility="internal",
            reason="secret pre-release pivot",
        )

        internal = store.current("creative", audience="internal")
        projected = store.current("creative", audience="public")
        public_text, public_ids = store.context_with_refs(
            "What is your debut sound?", audience="public"
        )

        assert internal[0]["id"] == private["id"]
        assert len(projected) == 1
        assert projected[0]["id"] == public["id"]
        assert projected[0]["status"] == "public_current"
        assert "Bright futuristic pop" in public_text
        assert "darker unannounced" not in public_text
        assert public["id"] in public_ids
        assert private["id"] not in public_ids
    finally:
        store.close()


def test_new_public_announcement_updates_public_projection():
    store = make_store()
    try:
        first = store.set_current(
            "creative", "music.direction", "bright pop", visibility="public"
        )
        store.set_current(
            "creative", "music.direction", "secret darker pop", visibility="internal"
        )
        announced = store.set_current(
            "creative", "music.direction", "dark futuristic pop", visibility="public"
        )
        projected = store.current("creative", audience="public")
        assert projected[0]["id"] == announced["id"]
        assert projected[0]["id"] != first["id"]
        assert projected[0]["content"] == "dark futuristic pop"
    finally:
        store.close()
