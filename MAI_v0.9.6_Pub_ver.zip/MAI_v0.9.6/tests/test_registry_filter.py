from pydantic import BaseModel

from idol.tools.audit import ToolAuditLog
from idol.tools.base import ToolDefinition, ToolPermission
from idol.tools.registry import ToolRegistry


class EmptyArgs(BaseModel):
    pass


def test_registry_filters_schemas_by_prefix(tmp_path):
    audit = ToolAuditLog(str(tmp_path / "tools.sqlite3"))
    registry = ToolRegistry(audit)
    try:
        registry.register(
            ToolDefinition(
                name="chess.state",
                description="state",
                args_model=EmptyArgs,
                permission=ToolPermission.READ,
                handler=lambda _: {},
            )
        )
        registry.register(
            ToolDefinition(
                name="learning.list",
                description="list",
                args_model=EmptyArgs,
                permission=ToolPermission.READ,
                handler=lambda _: [],
            )
        )
        schemas = registry.schemas(("chess.",))
        assert len(schemas) == 1
        assert schemas[0]["function"]["name"] == "chess.state"
    finally:
        audit.close()
