from pathlib import Path
import tempfile

from idol.continuity import ContinuityStore
from idol.embeddings import SemanticEmbedder
from idol.tools.audit import ToolAuditLog
from idol.tools.base import ToolCall
from idol.tools.continuity_tools import register_continuity_tools
from idol.tools.registry import ToolRegistry


def build():
    temp = tempfile.NamedTemporaryFile(suffix=".sqlite3", delete=False)
    temp.close()
    embedder = SemanticEmbedder("__missing_test_model__")
    continuity = ContinuityStore(temp.name, embedder)
    audit = ToolAuditLog(temp.name)
    registry = ToolRegistry(audit)
    register_continuity_tools(registry, continuity)
    return Path(temp.name), continuity, audit, registry


def test_commit_tool_versions_same_key_and_preserves_reason():
    path, continuity, audit, registry = build()
    try:
        first = registry.execute(
            ToolCall(
                "1",
                "continuity.commit",
                {
                    "memory_type": "creative",
                    "key": "music.debut_direction",
                    "content": "bright synth-pop",
                    "reason": "first settled direction",
                    "visibility": "private",
                    "confidence": 0.9,
                    "importance": 0.9,
                },
            )
        )
        second = registry.execute(
            ToolCall(
                "2",
                "continuity.commit",
                {
                    "memory_type": "creative",
                    "key": "music.debut_direction",
                    "content": "dark electronic pop",
                    "reason": "new settled direction",
                    "visibility": "private",
                    "confidence": 0.95,
                    "importance": 0.95,
                },
            )
        )
        assert first.success and second.success
        history = continuity.history("music.debut_direction")
        assert history[0]["status"] == "superseded"
        assert history[1]["reason"] == "new settled direction"
        assert audit.recent(1)[0]["tool"] == "continuity.commit"
    finally:
        audit.close()
        continuity.close()
        path.unlink(missing_ok=True)


def test_commit_tool_rejects_unapproved_memory_type():
    path, continuity, audit, registry = build()
    try:
        result = registry.execute(
            ToolCall(
                "1",
                "continuity.commit",
                {
                    "memory_type": "episodic",
                    "key": "x.test",
                    "content": "should not be accepted by commit tool",
                    "reason": "",
                    "visibility": "private",
                    "confidence": 0.9,
                    "importance": 0.9,
                },
            )
        )
        assert result.success is False
    finally:
        audit.close()
        continuity.close()
        path.unlink(missing_ok=True)
