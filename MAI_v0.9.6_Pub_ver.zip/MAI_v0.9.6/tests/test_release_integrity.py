from pathlib import Path
import tomllib

from idol.version import __version__
from model_switch import VALID


def test_release_version_is_synchronized():
    project = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
    assert project["project"]["version"] == __version__ == "0.9.6"


def test_manual_qwen36_profiles_are_available_without_changing_auto_default():
    assert "qwen3.6:27b" in VALID
    assert "qwen3.6:35b" in VALID
    assert "auto" in VALID
