from pathlib import Path

from idol.memory import MemoryStore


def test_memory_hybrid_recall_and_forget(tmp_path: Path):
    store = MemoryStore(str(tmp_path / "memory.sqlite3"))
    try:
        physics_id = store.add_memory("The user likes quantum physics", "semantic", 0.8)
        store.add_memory("The user likes puzzle games", "semantic", 0.7)
        results = store.recall("What science subject does the user like?", 2)
        assert results
        assert any("physics" in item["content"].casefold() for item in results)
        assert store.stats()["memories"] == 2
        assert store.forget_memory(physics_id)
        assert store.stats()["memories"] == 1
    finally:
        store.close()
