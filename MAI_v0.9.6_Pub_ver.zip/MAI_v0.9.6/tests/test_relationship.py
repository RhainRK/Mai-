from idol.relationship import RelationshipState


def test_relationship_round_trip():
    state = RelationshipState()
    state.update("Thanks, what do you think?")
    restored = RelationshipState.from_dict(state.to_dict())
    assert restored.interaction_count == 1
    assert restored.trust > 0.10
