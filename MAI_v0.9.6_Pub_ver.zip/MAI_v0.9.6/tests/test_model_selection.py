from idol import model_selection


def test_model_selection_prefers_qwen35(monkeypatch):
    monkeypatch.setattr(
        model_selection,
        "installed_ollama_models",
        lambda *_: ("qwen3:4b", "qwen3.5:4b"),
    )
    result = model_selection.resolve_ollama_model(
        "http://localhost:11434",
        "auto",
        "qwen3.5:4b",
        "qwen3:4b",
    )
    assert result.selected == "qwen3.5:4b"


def test_model_selection_falls_back(monkeypatch):
    monkeypatch.setattr(
        model_selection,
        "installed_ollama_models",
        lambda *_: ("qwen3:4b",),
    )
    result = model_selection.resolve_ollama_model(
        "http://localhost:11434",
        "auto",
        "qwen3.5:4b",
        "qwen3:4b",
    )
    assert result.selected == "qwen3:4b"
