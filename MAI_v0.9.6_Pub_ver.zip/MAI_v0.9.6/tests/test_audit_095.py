import sqlite3
from types import SimpleNamespace

import pytest

from idol.code_graph import CodeGraph
from idol.context_governor import ContextGovernor
from idol.memory import MemoryStore
from idol.tools.registry import ToolRegistry
from idol.tools.runtime import ToolRuntime
from idol.tools.base import ToolCall


def test_deny_all_permissions():
    assert ToolRegistry(None, allowed_permissions=[]).allowed_permissions == set()


def test_tool_route_is_enforced():
    class Registry:
        def schemas(self, prefixes):
            return [{'function': {'name': 'safe.read'}}]
        def execute(self, call):
            raise AssertionError('Unadvertised tool executed')
    class LLM:
        def generate(self, messages, tools=None):
            if len(messages) == 1:
                return SimpleNamespace(content='', tool_calls=[ToolCall(call_id='x', name='unsafe.write', arguments={})])
            return SimpleNamespace(content='Denied', tool_calls=[])
        def assistant_tool_message(self, response):
            return {'role': 'assistant', 'content': ''}
        def tool_result_message(self, call, result):
            assert not result.success
            return {'role': 'tool', 'content': result.error}
    assert ToolRuntime(LLM(), Registry()).run([{'role': 'user', 'content': 'test'}]) == 'Denied'


@pytest.mark.parametrize('fixed', [0, 5600, 5999, 6500])
def test_governor_budget_and_roles(tmp_path, fixed):
    conn = sqlite3.connect(tmp_path / 'cache.db')
    governor = ContextGovernor(conn, 6000)
    recent = [{'role': role, 'content': f'{i} {role} ' + 'word ' * 250}
              for i in range(12) for role in ('user', 'assistant')]
    result = governor.govern(recent, 'word', fixed)
    assert sum(len(m['content']) + 32 for m in result) <= max(0, 6000 - fixed - 64)
    assert not any(m['role'] == 'system' for m in result)
    for i, m in enumerate(result):
        if m['role'] == 'assistant':
            assert i and result[i-1]['role'] == 'user'
    conn.close()


def test_superseded_memory_stays_inactive_after_forgetting_replacement(tmp_path):
    memory = MemoryStore(str(tmp_path / 'memory.db'))
    old = memory.add_memory('My setting is blue', importance=1)
    new = memory.supersede(old, 'My setting is green')
    assert old not in [r['id'] for r in memory.recall('setting', 20)]
    memory.forget_memory(new)
    assert old not in [r['id'] for r in memory.recall('setting', 20)]
    with pytest.raises(ValueError):
        memory.supersede(99999, 'invalid')
    memory.close()


def test_pinning_preserves_importance(tmp_path):
    memory = MemoryStore(str(tmp_path / 'memory.db'))
    mid = memory.add_memory('Preference', importance=0.33)
    memory.pin_memory(mid)
    memory.pin_memory(mid, False)
    assert memory.conn.execute('SELECT importance FROM memories WHERE id=?', (mid,)).fetchone()[0] == 0.33
    memory.close()


def test_episode_batches_not_overwritten(tmp_path):
    memory = MemoryStore(str(tmp_path / 'memory.db'))
    for text in ['first', 'second']:
        memory.observe_turn('session', text, 'reply')
        memory.consolidate_session('session', minimum=1)
    assert memory.stats()['episodes'] == 2
    memory.close()


def test_graph_removes_deleted_and_invalid_sources(tmp_path):
    root = tmp_path / 'repo'
    root.mkdir()
    source = root / 'module.py'
    source.write_text('def alpha(): pass')
    graph = CodeGraph(tmp_path / 'index.db')
    graph.index(root)
    assert graph.query('alpha')['nodes']
    source.write_text('def broken(')
    graph.index(root)
    assert not graph.query('alpha')['nodes']
    source.write_text('def beta(): pass')
    graph.index(root)
    source.unlink()
    assert graph.index(root)['removed_files'] == 1
    assert not graph.query('beta')['nodes']
    graph.close()
