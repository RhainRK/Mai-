from pathlib import Path

from idol.learning import LearningStore


def test_teach_and_practice(tmp_path: Path):
    store = LearningStore(str(tmp_path / "mai.sqlite3"))
    store.teach("chess", "Control the centre.")
    store.record_practice("chess", "opening", "developed pieces", 0.8, "good")
    skill = store.skill("chess")
    assert skill["lessons"][0]["content"] == "Control the centre."
    assert skill["mastery"] > 0
    store.close()


def test_parse_teaching(tmp_path: Path):
    store = LearningStore(str(tmp_path / "mai.sqlite3"))
    lesson = store.parse_teaching(
        "Teach you chess: castle before starting a risky attack"
    )
    assert lesson.skill == "chess"
    assert "castle" in lesson.content
    store.close()
