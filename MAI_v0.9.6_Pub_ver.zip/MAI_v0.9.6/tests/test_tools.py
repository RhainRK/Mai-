from pathlib import Path
import tempfile

from pydantic import Field

from idol.tools.audit import ToolAuditLog
from idol.tools.base import (
    ToolArgs,
    ToolCall,
    ToolDefinition,
    ToolPermission,
)
from idol.tools.registry import ToolRegistry


class AddArgs(ToolArgs):
    a: int
    b: int


def build_registry():
    temp = tempfile.NamedTemporaryFile(
        suffix=".sqlite3",
        delete=False,
    )
    temp.close()

    audit = ToolAuditLog(temp.name)
    registry = ToolRegistry(audit)
    registry.register(
        ToolDefinition(
            "math.add",
            "Add two integers.",
            AddArgs,
            lambda args: {"sum": args.a + args.b},
            ToolPermission.READ,
        )
    )
    return Path(temp.name), audit, registry


def test_tool_executes():
    path, audit, registry = build_registry()

    try:
        result = registry.execute(
            ToolCall(
                call_id="1",
                name="math.add",
                arguments={"a": 2, "b": 3},
            )
        )
        assert result.success is True
        assert result.output == {"sum": 5}
        assert audit.recent(1)[0]["success"] is True
    finally:
        audit.close()
        path.unlink(missing_ok=True)


def test_tool_rejects_extra_fields():
    path, audit, registry = build_registry()

    try:
        result = registry.execute(
            ToolCall(
                call_id="1",
                name="math.add",
                arguments={
                    "a": 2,
                    "b": 3,
                    "extra": 4,
                },
            )
        )
        assert result.success is False
    finally:
        audit.close()
        path.unlink(missing_ok=True)


def test_schema_is_strict():
    path, audit, registry = build_registry()

    try:
        schema = registry.schemas()[0]
        params = schema["function"]["parameters"]
        assert params["additionalProperties"] is False
        assert schema["function"]["strict"] is True
    finally:
        audit.close()
        path.unlink(missing_ok=True)
