from pathlib import Path

from idol.career import CareerStore
from idol.identity import IdentityStore


IDENTITY = Path(__file__).parents[1] / "data" / "persona" / "mai_identity.json"


def test_career_store_separates_public_and_private(tmp_path: Path):
    store = CareerStore(str(tmp_path / "career.sqlite3"))
    identity = IdentityStore(IDENTITY)
    try:
        store.seed_identity(identity)
        store.record_event(
            "release",
            "First single",
            "MAI released her first single.",
            visibility="public",
        )
        store.record_event(
            "development",
            "Secret prototype",
            "An unreleased internal stage prototype was tested.",
            visibility="internal",
        )
        public = store.context("first single", "public")
        internal = store.context("prototype", "internal")
        assert "First single" in public
        assert "Secret prototype" not in public
        assert "Secret prototype" in internal
        assert store.stats()["career_events"] == 2
    finally:
        store.close()
