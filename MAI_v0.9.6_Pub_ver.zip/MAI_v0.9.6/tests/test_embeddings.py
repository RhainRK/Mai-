import numpy as np

from idol.embeddings import SemanticEmbedder


def test_fallback_embedding_is_normalized(monkeypatch):
    embedder = SemanticEmbedder("unused", fallback_dim=64)
    embedder._backend = "hash"
    vector = embedder.encode("music performance")
    assert np.isclose(np.linalg.norm(vector), 1.0)
