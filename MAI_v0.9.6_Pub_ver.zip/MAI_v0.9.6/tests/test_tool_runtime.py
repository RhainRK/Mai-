from pathlib import Path
import tempfile

from idol.llm import LLMResponse
from idol.tools.audit import ToolAuditLog
from idol.tools.base import (
    ToolArgs,
    ToolCall,
    ToolDefinition,
    ToolPermission,
)
from idol.tools.registry import ToolRegistry
from idol.tools.runtime import ToolRuntime


class EchoArgs(ToolArgs):
    text: str


class FakeLLM:
    def __init__(self):
        self.calls = 0

    def generate(self, messages, tools=None):
        self.calls += 1
        if self.calls == 1:
            return LLMResponse(
                content="",
                tool_calls=[
                    ToolCall(
                        call_id="abc",
                        name="test.echo",
                        arguments={"text": "hello"},
                    )
                ],
                raw_message={
                    "role": "assistant",
                    "content": "",
                    "tool_calls": [],
                },
            )
        return LLMResponse(
            content="Done.",
            tool_calls=[],
            raw_message={
                "role": "assistant",
                "content": "Done.",
            },
        )

    def chat(self, messages):
        return "fallback"

    def assistant_tool_message(self, response):
        return response.raw_message

    def tool_result_message(self, call, result):
        return {
            "role": "tool",
            "tool_call_id": call.call_id,
            "content": str(result.output),
        }


def test_runtime_executes_tool():
    temp = tempfile.NamedTemporaryFile(
        suffix=".sqlite3",
        delete=False,
    )
    temp.close()
    path = Path(temp.name)

    audit = ToolAuditLog(temp.name)
    registry = ToolRegistry(audit)
    registry.register(
        ToolDefinition(
            "test.echo",
            "Echo text.",
            EchoArgs,
            lambda args: {"text": args.text},
            ToolPermission.READ,
        )
    )

    try:
        runtime = ToolRuntime(
            FakeLLM(),
            registry,
            max_steps=3,
        )
        assert runtime.run(
            [{"role": "user", "content": "hello"}]
        ) == "Done."
    finally:
        audit.close()
        path.unlink(missing_ok=True)


class EmptyAfterToolLLM(FakeLLM):
    def generate(self, messages, tools=None):
        self.calls += 1
        if self.calls == 1:
            return LLMResponse(
                content="",
                tool_calls=[
                    ToolCall(
                        call_id="empty-1",
                        name="test.echo",
                        arguments={"text": "hello"},
                    )
                ],
                raw_message={"role": "assistant", "content": "", "tool_calls": []},
            )
        if self.calls == 2:
            return LLMResponse(
                content="",
                tool_calls=[],
                raw_message={"role": "assistant", "content": ""},
            )
        return LLMResponse(
            content="Final answer after tool.",
            tool_calls=[],
            raw_message={"role": "assistant", "content": "Final answer after tool."},
        )


def test_runtime_forces_final_answer_after_empty_tool_turn():
    temp = tempfile.NamedTemporaryFile(suffix=".sqlite3", delete=False)
    temp.close()
    path = Path(temp.name)
    audit = ToolAuditLog(temp.name)
    registry = ToolRegistry(audit)
    registry.register(
        ToolDefinition(
            "test.echo",
            "Echo text.",
            EchoArgs,
            lambda args: {"text": args.text},
            ToolPermission.READ,
        )
    )
    try:
        runtime = ToolRuntime(EmptyAfterToolLLM(), registry, max_steps=3)
        assert runtime.run([{"role": "user", "content": "hello"}]) == "Final answer after tool."
    finally:
        audit.close()
        path.unlink(missing_ok=True)



def test_observer_failure_does_not_break_tool_execution():
    temp = tempfile.NamedTemporaryFile(suffix=".sqlite3", delete=False)
    temp.close()
    path = Path(temp.name)
    audit = ToolAuditLog(temp.name)
    registry = ToolRegistry(audit)
    registry.register(
        ToolDefinition(
            "test.echo",
            "Echo text.",
            EchoArgs,
            lambda args: {"text": args.text},
            ToolPermission.READ,
        )
    )

    def broken_observer(call, result):
        raise RuntimeError("telemetry failed")

    try:
        runtime = ToolRuntime(FakeLLM(), registry, max_steps=3)
        assert runtime.run(
            [{"role": "user", "content": "use tool"}],
            observer=broken_observer,
        ) == "Done."
    finally:
        audit.close()
        path.unlink(missing_ok=True)
