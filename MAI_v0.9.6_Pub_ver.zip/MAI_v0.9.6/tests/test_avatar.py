from idol.avatar import VNyanAvatarBridge


def test_avatar_status_disabled():
    bridge = VNyanAvatarBridge(False, "CABLE Input", "http://127.0.0.1:8069")
    try:
        status = bridge.status()
        assert status.enabled is False
        assert status.backend == "vnyan"
        assert status.audio_device == "CABLE Input"
        assert status.autonomy is True
        assert bridge.test() is False
    finally:
        bridge.close()


def test_expression_selection_uses_state_and_text():
    name, intensity = VNyanAvatarBridge._expression(
        "That is amazing!",
        {"energy": 0.9, "confidence": 0.8},
    )
    assert name == "excited"
    assert 0.6 <= intensity <= 1.0


def test_look_values_are_clamped(monkeypatch):
    bridge = VNyanAvatarBridge(False, "", "http://127.0.0.1:8069", autonomy=False)
    sent = {}

    def fake_send(action, payload=None):
        sent["action"] = action
        sent["payload"] = payload
        return True

    monkeypatch.setattr(bridge, "send", fake_send)
    try:
        assert bridge.look(5, -5, 10) is True
        assert sent["action"] == "mai_look"
        assert sent["payload"]["x"] == "1.000"
        assert sent["payload"]["y"] == "-1.000"
        assert sent["payload"]["hold_ms"] == "100"
    finally:
        bridge.close()
