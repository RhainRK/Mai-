from pathlib import Path

from idol.identity import IdentityStore
from idol.relationship import RelationshipState


IDENTITY = Path(__file__).parents[1] / "data" / "persona" / "mai_identity.json"


def test_rhain_is_canonical_creator():
    identity = IdentityStore(IDENTITY)
    creator = identity.creator()
    assert creator["name"] == "Rhain"
    assert creator["subject_id"] == "creator:Rhain"
    assert "creator" in creator["role"]
    assert identity.creator_name == "Rhain"
    assert "Rhain" in identity.context("internal")


def test_creator_is_public_canon_without_local_operator_claim():
    identity = IdentityStore(IDENTITY)
    public = identity.context("public")
    assert "relationship.creator" in public
    assert "Rhain" in public


def test_private_relationship_can_be_authoritatively_bound_to_creator():
    state = RelationshipState()
    state.bind_subject(
        subject_id="creator:Rhain",
        display_name="Rhain",
        role="creator",
    )
    prompt = state.as_prompt()
    assert state.is_creator is True
    assert "display_name=Rhain" in prompt
    assert "role=creator" in prompt
    assert "current_private_operator_is_creator=true" in prompt


def test_relationship_round_trip_preserves_creator_binding():
    state = RelationshipState(
        subject_id="creator:Rhain",
        display_name="Rhain",
        role="creator",
    )
    restored = RelationshipState.from_dict(state.to_dict())
    assert restored.subject_id == "creator:Rhain"
    assert restored.display_name == "Rhain"
    assert restored.is_creator is True
