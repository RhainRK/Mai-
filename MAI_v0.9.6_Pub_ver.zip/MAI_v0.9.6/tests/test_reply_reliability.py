import asyncio
import weakref
from types import SimpleNamespace

from idol.agent import IdolAgent
from idol.coordinator import TurnCoordinator
from idol.llm import LLMResponse
from idol.telemetry import TraceJournal, TurnMetrics
from idol.replies import (
    DETERMINISTIC_FAILURE_REPLY,
    ReplyGuard,
    VisibleTextFilter,
    sanitize_visible_text,
)


class RecoveringLLM:
    def __init__(self, replies):
        self.replies = list(replies)
        self.calls = 0
        self.last_metrics = TurnMetrics(model="fake")

    def generate(self, messages, tools=None):
        self.calls += 1
        content = self.replies.pop(0) if self.replies else ""
        return LLMResponse(content=content, tool_calls=[], raw_message={})


class EmptyStreamLLM(RecoveringLLM):
    def stream_text(self, messages):
        if False:
            yield ""

    async def astream_text(self, messages, cancel_event):
        if False:
            yield ""


class FakeState:
    def react_to_user_message(self, text):
        pass


class FakeRelationship:
    def update(self, text):
        pass

    def to_dict(self):
        return {"ok": True}


class FakeRouter:
    def route(self, text):
        return ()




class FakeContextBuilder:
    def retrieve(self, text, public_mode=False, task_override=None):
        return SimpleNamespace(
            memory_ids=[] if public_mode else [7],
            canon_keys=["identity.name"],
            career_event_ids=[],
        )

    def prepare(self, text, route, retrieved, public_mode=False):
        return SimpleNamespace(
            messages=[{"role": "user", "content": text}],
            plan=SimpleNamespace(
                strategy=(
                    "public-safe direct response"
                    if public_mode
                    else "direct contextual response"
                )
            ),
        )

class FakeMemory:
    def __init__(self):
        self.messages = []
        self.extracted = []
        self.states = []

    def add_message(self, role, content):
        self.messages.append((role, content))

    def extract_and_store(self, text):
        self.extracted.append(text)

    def save_state(self, key, value):
        self.states.append((key, value))


def make_stream_agent(llm):
    agent = IdolAgent.__new__(IdolAgent)
    agent.llm = llm
    agent.reply_guard = ReplyGuard(llm, recovery_attempts=2)
    agent.state = FakeState()
    agent.relationship = FakeRelationship()
    agent.tool_router = FakeRouter()
    agent.memory = FakeMemory()
    agent.trace_journal = TraceJournal(":memory:")
    agent.coordinator = TurnCoordinator(
        llm=llm,
        runtime=None,
        reply_guard=agent.reply_guard,
        tool_router=agent.tool_router,
        context_builder=FakeContextBuilder(),
        state=agent.state,
        relationship=agent.relationship,
        memory=agent.memory,
        trace_journal=agent.trace_journal,
        model_name="fake",
    )
    weakref.finalize(agent, agent.trace_journal.close)
    return agent


def test_sanitize_keeps_final_answer_after_hidden_reasoning():
    text = "<think>private reasoning</think>Here is the answer."
    assert sanitize_visible_text(text) == "Here is the answer."


def test_sanitize_drops_unclosed_hidden_reasoning():
    assert sanitize_visible_text("<analysis>private only") == ""


def test_visible_stream_filter_handles_split_reasoning_tags():
    parser = VisibleTextFilter()
    chunks = ["<thi", "nk>secret</th", "ink>Hel", "lo"]
    visible = "".join(parser.push(chunk) for chunk in chunks) + parser.flush()
    assert visible == "Hello"


def test_reply_guard_recovers_empty_reply():
    llm = RecoveringLLM(["Recovered final answer."])
    guard = ReplyGuard(llm, recovery_attempts=2)
    assert guard.ensure([{"role": "user", "content": "hello"}], "") == (
        "Recovered final answer."
    )
    assert guard.stats() == {
        "recovery_attempts": 1,
        "recovered_replies": 1,
        "deterministic_fallbacks": 0,
        "backend_failures": 0,
    }


def test_reply_guard_retries_thought_only_then_recovers():
    llm = RecoveringLLM([
        "<think>still reasoning</think>",
        "Visible final.",
    ])
    guard = ReplyGuard(llm, recovery_attempts=2)
    assert guard.ensure([{"role": "user", "content": "hello"}], "") == "Visible final."
    assert guard.stats()["recovery_attempts"] == 2


def test_reply_guard_has_deterministic_last_resort():
    llm = RecoveringLLM(["", "<analysis>nothing visible</analysis>"])
    guard = ReplyGuard(llm, recovery_attempts=2)
    assert guard.ensure([{"role": "user", "content": "hello"}], "") == (
        DETERMINISTIC_FAILURE_REPLY
    )
    assert guard.stats()["deterministic_fallbacks"] == 1


def test_stream_respond_recovers_when_model_stream_is_empty_and_commits_turn():
    llm = EmptyStreamLLM(["Recovered streamed answer."])
    agent = make_stream_agent(llm)

    chunks = list(agent.stream_respond("hello"))

    assert chunks == ["Recovered streamed answer."]
    assert agent.memory.messages == [
        ("user", "hello"),
        ("assistant", "Recovered streamed answer."),
    ]


def test_async_stream_respond_recovers_when_model_stream_is_empty():
    async def collect():
        llm = EmptyStreamLLM(["Recovered async answer."])
        agent = make_stream_agent(llm)
        cancel = asyncio.Event()
        return [chunk async for chunk in agent.astream_respond("hello", cancel)], agent

    chunks, agent = asyncio.run(collect())
    assert chunks == ["Recovered async answer."]
    assert agent.memory.messages[-1] == ("assistant", "Recovered async answer.")


class FailingStreamLLM(EmptyStreamLLM):
    def stream_text(self, messages):
        from idol.llm import LLMError

        raise LLMError("backend unavailable")
        yield  # pragma: no cover

    async def astream_text(self, messages, cancel_event):
        from idol.llm import LLMError

        raise LLMError("backend unavailable")
        yield  # pragma: no cover


def test_stream_backend_failure_still_produces_reply():
    llm = FailingStreamLLM(["Recovered after backend failure."])
    agent = make_stream_agent(llm)
    assert list(agent.stream_respond("hello")) == ["Recovered after backend failure."]
    assert agent.reply_guard.stats()["backend_failures"] == 1


def test_async_stream_backend_failure_still_produces_reply():
    async def collect():
        llm = FailingStreamLLM(["Recovered async after failure."])
        agent = make_stream_agent(llm)
        return [
            chunk
            async for chunk in agent.astream_respond("hello", asyncio.Event())
        ], agent

    chunks, agent = asyncio.run(collect())
    assert chunks == ["Recovered async after failure."]
    assert agent.reply_guard.stats()["backend_failures"] == 1

class FailingChatLLM(RecoveringLLM):
    def chat(self, messages):
        from idol.llm import LLMError

        raise LLMError("backend unavailable")


def test_nonstream_backend_failure_still_produces_reply_and_commits():
    llm = FailingChatLLM(["Recovered nonstream answer."])
    agent = make_stream_agent(llm)

    reply = agent.respond("hello")

    assert reply == "Recovered nonstream answer."
    assert agent.memory.messages == [
        ("user", "hello"),
        ("assistant", "Recovered nonstream answer."),
    ]
    assert agent.reply_guard.stats()["backend_failures"] == 1
