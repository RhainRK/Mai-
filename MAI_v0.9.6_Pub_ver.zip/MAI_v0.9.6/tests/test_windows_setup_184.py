from pathlib import Path


def test_setup_targets_python_311_and_qwen35():
    setup = Path("setup_windows.ps1").read_text(encoding="utf-8")
    assert "-3.11" in setup
    assert "qwen3.5:4b" in setup
    assert "ollama pull qwen3:4b" not in setup


def test_whisperlivekit_is_isolated_and_pcm_compatible():
    installer = Path("install_whisperlivekit.ps1").read_text(encoding="utf-8")
    launcher = Path("start_whisperlivekit.bat").read_text(encoding="utf-8")
    assert ".venv-wlk" in installer
    assert "whisperlivekit" in installer.casefold()
    assert "--pcm-input" in launcher
    assert "--port 8000" in launcher


def test_setup_guide_warns_against_training_in_runtime_env():
    guide = Path("SETUP_WINDOWS_STEP_BY_STEP.md").read_text(encoding="utf-8")
    assert "Python 3.11" in guide
    assert "qwen3.5:4b" in guide
    assert "training/requirements.txt" in guide
    assert "Do **not**" in guide
