import asyncio
import weakref
from types import SimpleNamespace

from idol.coordinator import TurnCoordinator
from idol.llm import LLMError, LLMResponse
from idol.replies import ReplyGuard
from idol.telemetry import TraceJournal, TurnMetrics


class FakeLLM:
    def __init__(self, answer="Visible answer.", recover="Recovered complete answer."):
        self.answer = answer
        self.recover = recover
        self.last_metrics = TurnMetrics(model="fake", wall_seconds=0.01)

    def chat(self, messages):
        return self.answer

    def generate(self, messages, tools=None):
        return LLMResponse(content=self.recover, tool_calls=[], raw_message={})

    def stream_text(self, messages):
        yield self.answer

    async def astream_text(self, messages, cancel_event):
        yield self.answer


class PartialFailLLM(FakeLLM):
    def stream_text(self, messages):
        yield "Partial answer"
        raise LLMError("stream died")

    async def astream_text(self, messages, cancel_event):
        yield "Partial answer"
        raise LLMError("stream died")


class FakeState:
    def __init__(self):
        self.seen = []

    def react_to_user_message(self, text):
        self.seen.append(text)


class FakeRelationship:
    def __init__(self):
        self.seen = []

    def update(self, text):
        self.seen.append(text)

    def to_dict(self):
        return {"turns": len(self.seen)}


class FakeMemory:
    def __init__(self):
        self.messages = []
        self.extracted = []
        self.states = []

    def add_message(self, role, content):
        self.messages.append((role, content))

    def extract_and_store(self, text):
        self.extracted.append(text)

    def save_state(self, key, value):
        self.states.append((key, value))


class FakeRouter:
    def __init__(self, route=()):
        self._route = route

    def route(self, text):
        return self._route


class FakeContextBuilder:
    def __init__(self):
        self.public_flags = []

    def retrieve(self, text, public_mode=False, task_override=None):
        self.public_flags.append(public_mode)
        return SimpleNamespace(
            memory_ids=[] if public_mode else [11, 12],
            continuity_ids=[21] if not public_mode else [],
            canon_keys=["identity.name", "identity.nature"],
            career_event_ids=["evt_demo"],
        )

    def prepare(self, text, route, retrieved, public_mode=False):
        return SimpleNamespace(
            messages=[{"role": "user", "content": text}],
            plan=SimpleNamespace(
                strategy=(
                    "public-safe direct response"
                    if public_mode
                    else ("tool-assisted response" if route else "direct contextual response")
                )
            ),
        )


class FakeRuntime:
    def __init__(self, answer="Tool answer."):
        self.answer = answer

    def run(self, messages, prefixes=None, observer=None):
        if observer:
            observer(
                SimpleNamespace(name="goals.create"),
                SimpleNamespace(success=True),
            )
        return self.answer


def make_coordinator(llm=None, route=()):
    llm = llm or FakeLLM()
    state = FakeState()
    relationship = FakeRelationship()
    memory = FakeMemory()
    builder = FakeContextBuilder()
    journal = TraceJournal(":memory:", retention=2500)
    coordinator = TurnCoordinator(
        llm=llm,
        runtime=FakeRuntime(),
        reply_guard=ReplyGuard(llm, recovery_attempts=2),
        tool_router=FakeRouter(route),
        context_builder=builder,
        state=state,
        relationship=relationship,
        memory=memory,
        trace_journal=journal,
        model_name="fake-model",
    )
    weakref.finalize(coordinator, journal.close)
    return coordinator, memory, relationship, builder, journal


def test_turn_lifecycle_is_complete_and_trace_has_no_raw_prompt_text():
    coordinator, memory, _, _, journal = make_coordinator()

    reply = coordinator.respond("super-secret-user-text")

    assert reply == "Visible answer."
    trace = coordinator.last_trace.as_dict()
    assert [stage["name"] for stage in trace["stages"]] == [
        "RECEIVE",
        "CLASSIFY",
        "RETRIEVE",
        "PLAN",
        "ACT",
        "VERIFY",
        "RESPOND",
        "COMMIT",
    ]
    assert trace["response_completed"] is True
    assert trace["success"] is True
    assert trace["memory_ids"] == [11, 12]
    assert trace["continuity_ids"] == [21]
    assert "super-secret-user-text" not in str(trace)
    assert memory.messages[-1] == ("assistant", "Visible answer.")
    assert journal.get(trace["trace_id"])["response_completed"] is True


def test_public_turn_withholds_private_commit_and_tool_route():
    coordinator, memory, relationship, builder, _ = make_coordinator(route=("goals.",))

    reply = coordinator.respond("press question", public_mode=True)

    assert reply == "Visible answer."
    assert memory.messages == []
    assert relationship.seen == []
    assert builder.public_flags == [True]
    trace = coordinator.last_trace.as_dict()
    assert trace["route"] == []
    assert trace["memory_ids"] == []
    assert trace["continuity_ids"] == []
    assert trace["stages"][-1]["status"] == "skipped"


def test_tool_calls_are_observable_without_recording_arguments_or_outputs():
    coordinator, _, _, _, _ = make_coordinator(route=("goals.",))

    assert coordinator.respond("make a goal") == "Tool answer."

    trace = coordinator.last_trace.as_dict()
    assert trace["route"] == ["goals."]
    assert trace["tool_calls"] == [{"name": "goals.create", "success": True}]
    assert trace["plan_strategy"] == "tool-assisted response"


def test_partial_stream_failure_recovers_complete_answer_and_commits_only_recovery():
    coordinator, memory, _, _, _ = make_coordinator(PartialFailLLM())

    chunks = list(coordinator.stream_respond("hello"))

    assert chunks == ["Partial answer", "\n\nRecovered complete answer."]
    assert memory.messages[-1] == ("assistant", "Recovered complete answer.")
    trace = coordinator.last_trace.as_dict()
    act = next(stage for stage in trace["stages"] if stage["name"] == "ACT")
    assert act["status"] == "recovered"
    assert act["details"]["partial_chars"] == len("Partial answer")
    assert trace["response_completed"] is True
    assert trace["error"] == "stream_backend_failed"


def test_partial_async_stream_failure_recovers_complete_answer():
    async def collect():
        coordinator, memory, _, _, _ = make_coordinator(PartialFailLLM())
        chunks = [
            chunk
            async for chunk in coordinator.astream_respond("hello", asyncio.Event())
        ]
        return chunks, memory, coordinator

    chunks, memory, coordinator = asyncio.run(collect())
    assert chunks == ["Partial answer", "\n\nRecovered complete answer."]
    assert memory.messages[-1] == ("assistant", "Recovered complete answer.")
    assert coordinator.last_trace.response_completed is True


def test_cancelled_async_turn_is_never_committed():
    async def collect():
        coordinator, memory, _, _, _ = make_coordinator()
        cancel = asyncio.Event()
        cancel.set()
        chunks = [chunk async for chunk in coordinator.astream_respond("hello", cancel)]
        return chunks, memory, coordinator

    chunks, memory, coordinator = asyncio.run(collect())
    assert chunks == []
    assert memory.messages == []
    assert coordinator.last_trace.response_completed is False
    assert coordinator.last_trace.error == "cancelled_before_act"


def test_one_thousand_simulated_turns_have_no_missing_reply():
    coordinator, memory, _, _, journal = make_coordinator()

    for index in range(1000):
        assert coordinator.respond(f"turn-{index}") == "Visible answer."

    stats = journal.stats()
    assert stats["turns"] == 1000
    assert stats["completed_replies"] == 1000
    assert stats["failed_turns"] == 0
    assert stats["completion_rate"] == 1.0
    assert len(memory.messages) == 2000
