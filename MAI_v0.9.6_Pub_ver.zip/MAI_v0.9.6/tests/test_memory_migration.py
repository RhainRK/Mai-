import sqlite3
from pathlib import Path

from idol.memory import MemoryStore


def test_memory_migrates_old_schema(tmp_path: Path):
    path = tmp_path / "old.sqlite3"
    conn = sqlite3.connect(path)
    conn.executescript(
        """
        CREATE TABLE messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kind TEXT NOT NULL,
            content TEXT NOT NULL,
            importance REAL NOT NULL DEFAULT 0.5,
            embedding BLOB,
            created_at TEXT NOT NULL,
            last_accessed TEXT NOT NULL
        );
        CREATE TABLE profile_facts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT NOT NULL,
            value TEXT NOT NULL,
            confidence REAL NOT NULL DEFAULT 0.7,
            updated_at TEXT NOT NULL,
            UNIQUE(key, value)
        );
        CREATE TABLE app_state (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        """
    )
    conn.execute(
        "INSERT INTO memories(kind, content, importance, embedding, created_at, last_accessed) VALUES (?, ?, ?, ?, ?, ?)",
        ("semantic", "old memory", 0.8, None, "2026-01-01T00:00:00+00:00", "2026-01-01T00:00:00+00:00"),
    )
    conn.commit()
    conn.close()

    store = MemoryStore(str(path))
    try:
        columns = {row[1] for row in store.conn.execute("PRAGMA table_info(memories)")}
        assert {"content_hash", "embedding_model", "access_count"} <= columns
        assert store.stats()["memories"] == 1
    finally:
        store.close()
