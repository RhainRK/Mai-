from idol.realtime.chunking import SentenceChunker


def test_sentence_chunker():
    chunker = SentenceChunker(min_chars=10, max_chars=80)
    chunks = chunker.push(
        "This is the first sentence. This is the second "
    )
    assert chunks == ["This is the first sentence."]

    tail = chunker.flush()
    assert tail == "This is the second"
