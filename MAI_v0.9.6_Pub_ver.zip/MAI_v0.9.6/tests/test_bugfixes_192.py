import asyncio
import builtins
from pathlib import Path
from types import SimpleNamespace

import httpx
import numpy as np
import pytest

import main as main_module
from idol.audio_io import AudioConfig, MicrophoneRecorder
from idol.avatar import VNyanAvatarBridge
from idol.realtime.session import RealtimeSession
from idol.realtime.tts import StreamingTTS


class _FakeIdol:
    def __init__(self):
        self.closed = False
        self.chess = None

    def close(self):
        self.closed = True


@pytest.mark.parametrize(
    "command",
    [
        "/avatar-expression happy nope",
        "/practice singing | task | result | nope | feedback",
        "/work goal-1 nope",
    ],
)
def test_malformed_numeric_cli_commands_do_not_exit(monkeypatch, command, capsys):
    fake = _FakeIdol()
    commands = iter([command, "/quit"])
    monkeypatch.setattr(main_module, "IdolAgent", lambda: fake)
    monkeypatch.setattr(builtins, "input", lambda _prompt="": next(commands))

    main_module.main()

    output = capsys.readouterr().out
    assert "Use:" in output
    assert fake.closed is True


def test_empty_chess_command_defaults_to_board(capsys):
    class Chess:
        def board_text(self):
            return "BOARD"

    fake = SimpleNamespace(chess=Chess())
    main_module.chess_command(fake, "")
    assert "BOARD" in capsys.readouterr().out


def test_short_false_microphone_trigger_stops_after_silence(monkeypatch):
    cfg = AudioConfig(
        sample_rate=1000,
        frame_ms=10,
        calibration_seconds=0.01,
        silence_seconds=0.03,
        min_speech_seconds=0.08,
        max_record_seconds=1.0,
        pre_roll_seconds=0.01,
        start_floor=0.01,
        stop_floor=0.005,
    )
    recorder = MicrophoneRecorder(cfg)

    class Stream:
        def __init__(self):
            self.reads = 0

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def read(self, frames):
            self.reads += 1
            level = 0.0 if self.reads == 1 else (0.2 if self.reads == 2 else 0.0)
            return np.full((frames, 1), level, dtype=np.float32), False

    stream = Stream()
    fake_sd = SimpleNamespace(InputStream=lambda **_kwargs: stream)
    monkeypatch.setattr(recorder, "_sounddevice", lambda: fake_sd)

    assert recorder.listen_until_silence("unused.wav") is None
    assert stream.reads < 10


def test_avatar_close_is_idempotent():
    bridge = VNyanAvatarBridge(False, "", "http://127.0.0.1:8069", autonomy=False)
    bridge.close()
    bridge.close()
    assert bridge.send("after_close") is False


def test_realtime_requirement_includes_sounddevice():
    requirements = Path("requirements-realtime.txt").read_text(encoding="utf-8")
    assert "sounddevice" in requirements


def test_realtime_sender_failure_is_surfaced_and_cleaned_up():
    async def run():
        class Audio:
            def __init__(self):
                self.closed = False
                self.playing = False
                self.processor = None

            def start(self):
                pass

            async def read(self):
                await asyncio.sleep(0)
                return b"pcm"

            def stop_playback(self):
                pass

            def close(self):
                self.closed = True

        class STT:
            def __init__(self):
                self.closed = False

            async def connect(self):
                pass

            async def send(self, _chunk):
                raise RuntimeError("send failed")

            async def next_event(self):
                await asyncio.Event().wait()

            async def close(self):
                self.closed = True

        class TTS:
            def __init__(self):
                self.closed = False

            async def close(self):
                self.closed = True

        session = RealtimeSession.__new__(RealtimeSession)
        session.agent = SimpleNamespace(avatar=SimpleNamespace(speaking_finished=lambda: None))
        session.settings = SimpleNamespace()
        session.audio = Audio()
        session.stt = STT()
        session.tts = TTS()
        session.cancel_event = asyncio.Event()
        session.response_task = None
        session.spoken_text = ""
        session.partial_text = ""
        session.closed = False
        session.avatar_speaking = False

        with pytest.raises(RuntimeError, match="Realtime microphone sender failed: send failed"):
            await asyncio.wait_for(session.run(), timeout=1.0)

        assert session.audio.closed is True
        assert session.stt.closed is True
        assert session.tts.closed is True

    asyncio.run(run())


def test_streaming_tts_rejects_sample_rate_mismatch():
    async def run():
        def handler(_request):
            return httpx.Response(
                200,
                headers={"X-Sample-Rate": "16000"},
                content=b"\x00\x00" * 8,
            )

        tts = StreamingTTS("http://tts.invalid/v1", "model", "mai", sample_rate=24000)
        await tts.client.aclose()
        tts.client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        try:
            with pytest.raises(RuntimeError, match="16000 Hz PCM"):
                async for _ in tts.stream("hello", asyncio.Event()):
                    pass
        finally:
            await tts.close()

    asyncio.run(run())


def test_realtime_normalization_preserves_unicode_words():
    assert RealtimeSession._normalize("こんにちは、MAI！") == "こんにちは mai"


def test_windows_speech_timeout_becomes_voice_error(monkeypatch, tmp_path):
    import subprocess
    import idol.voice as voice_mod
    from idol.voice import VoiceError, WindowsSpeechEngine
    from idol.voice_profile import VoiceProfile

    monkeypatch.setattr(voice_mod.platform, "system", lambda: "Windows")

    def fake_run(*args, **kwargs):
        assert kwargs["timeout"] == 2.0
        raise subprocess.TimeoutExpired(cmd=args[0], timeout=2.0)

    monkeypatch.setattr(voice_mod.subprocess, "run", fake_run)
    engine = WindowsSpeechEngine(VoiceProfile(), timeout=2.0)
    with pytest.raises(VoiceError, match="timed out"):
        engine.synthesize("hello", str(tmp_path / "voice.wav"))


def test_http_tts_rejects_non_wav_payload(monkeypatch, tmp_path):
    from idol.voice import HttpSpeechEngine, VoiceError
    from idol.voice_profile import VoiceProfile

    class Response:
        def raise_for_status(self):
            return None

        def iter_bytes(self, chunk_size):
            yield b"not-a-wave-file" * 8

    class StreamContext:
        def __enter__(self):
            return Response()

        def __exit__(self, exc_type, exc, tb):
            return False

    engine = HttpSpeechEngine(VoiceProfile(), "http://127.0.0.1:1", "test", 1.0)
    monkeypatch.setattr(engine.session, "stream", lambda *args, **kwargs: StreamContext())
    try:
        with pytest.raises(VoiceError, match="invalid WAV"):
            engine.synthesize("hello", str(tmp_path / "voice.wav"))
    finally:
        engine.close()


def test_windows_setup_can_fall_back_from_py_launcher_to_python_command():
    setup = Path("setup_windows.ps1").read_text(encoding="utf-8")
    assert "if (-not $PythonCommand -and (Get-Command python" in setup
    assert "$PythonCommand = \"py\"" in setup
    assert "$PythonCommand = \"python\"" in setup
