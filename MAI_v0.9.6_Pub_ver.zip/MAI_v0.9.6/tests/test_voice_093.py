from pathlib import Path

from idol.voice import UnifiedVoice, WindowsSpeechEngine
from idol.voice_profile import VoiceProfile


def test_auto_voice_falls_back_to_windows_without_elevenlabs_credentials(tmp_path: Path):
    voice = UnifiedVoice(
        VoiceProfile(),
        "auto",
        "http://127.0.0.1:8080/v1",
        "cosyvoice3",
        30.0,
        str(tmp_path / "DiffSinger"),
    )
    try:
        assert isinstance(voice.speech, WindowsSpeechEngine)
    finally:
        voice.close()


def test_voice_designer_uses_original_mai_description():
    source = Path("design_mai_voice.py").read_text(encoding="utf-8")
    assert "An original young-adult feminine pop-artist voice" in source
    assert "clone" not in source.casefold()
    assert "Ariana" not in source
    assert "Lisa" not in source
    assert "Natty" not in source



def test_elevenlabs_stream_error_reads_body_before_reporting(tmp_path: Path):
    import httpx
    import pytest

    from idol.elevenlabs_voice import ElevenLabsError, ElevenLabsSpeechEngine

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            401,
            json={"detail": {"status": "invalid_api_key", "message": "bad key"}},
            request=request,
        )

    engine = ElevenLabsSpeechEngine("test-key", "test-voice")
    engine.client.close()
    engine.client = httpx.Client(transport=httpx.MockTransport(handler))
    try:
        with pytest.raises(ElevenLabsError) as exc_info:
            engine.synthesize("hello", str(tmp_path / "voice.wav"))
        message = str(exc_info.value)
        assert "401" in message
        assert "bad key" in message
        assert "Attempted to access streaming response content" not in message
    finally:
        engine.close()
