from pathlib import Path

from idol.voice import WindowsSpeechEngine
from idol.voice_profile import VoiceProfile


def test_windows_script_contains_encoded_text(tmp_path: Path):
    engine = WindowsSpeechEngine(VoiceProfile(), rate=2, volume=90)
    script = engine._script("Hello MAI", tmp_path / "voice.wav")
    assert "FromBase64String" in script
    assert "$s.Rate = 2" in script
    assert "$s.Volume = 90" in script
    assert "SetOutputToWaveFile" in script


def test_powershell_string_escape():
    assert WindowsSpeechEngine._ps_string("a'b") == "'a''b'"

from idol.elevenlabs_voice import ElevenLabsSpeechEngine


def test_elevenlabs_payload_uses_voice_controls():
    engine = ElevenLabsSpeechEngine(
        "test-key",
        "voice-123",
        model="eleven_v3_conversational",
        stability=0.55,
        similarity_boost=0.8,
        style=0.18,
        speed=1.0,
    )
    try:
        payload = engine.payload("Hello")
        assert payload["text"] == "Hello"
        assert payload["model_id"] == "eleven_v3_conversational"
        assert payload["voice_settings"]["stability"] == 0.55
        assert payload["voice_settings"]["similarity_boost"] == 0.8
        assert payload["voice_settings"]["style"] == 0.18
        assert payload["voice_settings"]["speed"] == 1.0
        assert engine.output_format == "pcm_24000"
    finally:
        engine.close()
