import json
import sqlite3
from pathlib import Path

import httpx
import pytest

from idol.behavior import BehaviorProfile, BehaviorProfileError
from idol.career import CareerStore
from idol.database import connect_database, database_health
from idol.identity import IdentityStore
from idol.model_selection import ModelSelectionError, installed_ollama_models, require_available, resolve_ollama_model
from idol.tools.audit import ToolAuditLog


IDENTITY = Path(__file__).parents[1] / "data" / "persona" / "mai_identity.json"
PROFILE = Path(__file__).parents[1] / "data" / "persona" / "mai_profile.json"


def test_database_connections_enforce_foreign_keys(tmp_path: Path):
    path = tmp_path / "fk.sqlite3"
    conn = connect_database(path)
    try:
        with conn:
            conn.execute("CREATE TABLE parent(id INTEGER PRIMARY KEY)")
            conn.execute(
                "CREATE TABLE child(parent_id INTEGER REFERENCES parent(id))"
            )
        assert conn.execute("PRAGMA foreign_keys").fetchone()[0] == 1
        with pytest.raises(sqlite3.IntegrityError):
            with conn:
                conn.execute("INSERT INTO child(parent_id) VALUES (999)")
    finally:
        conn.close()

    health = database_health(path)
    assert health["quick_check"] == "ok"
    assert health["foreign_key_violations"] == 0
    assert health["foreign_keys_enabled"] is True


def test_identity_seed_is_authoritative_and_not_duplicated_in_career_prompt(tmp_path: Path):
    identity_path = tmp_path / "identity.json"
    payload = json.loads(IDENTITY.read_text(encoding="utf-8"))
    identity_path.write_text(json.dumps(payload), encoding="utf-8")

    store = CareerStore(str(tmp_path / "career.sqlite3"))
    try:
        store.seed_identity(IdentityStore(identity_path))
        first = store.get_canon("identity.name")
        assert first["value"] == "MAI"
        assert first["source"].startswith("identity_file:")

        for item in payload["canon"]:
            if item["key"] == "identity.name":
                item["value"] = "MAI TEST UPDATED"
        identity_path.write_text(json.dumps(payload), encoding="utf-8")
        store.seed_identity(IdentityStore(identity_path))

        refreshed = store.get_canon("identity.name")
        assert refreshed["value"] == "MAI TEST UPDATED"
        context = store.context("name", "internal")
        assert "MAI TEST UPDATED" not in context

        store.set_canon(
            "career.test_fact",
            "A career-authored fact",
            locked=False,
            source="career_test",
        )
        context = store.context("career", "internal")
        assert "A career-authored fact" in context
    finally:
        store.close()


def test_behavior_profile_validation_fails_early(tmp_path: Path):
    valid = BehaviorProfile(PROFILE)
    assert valid.data["expression"]

    malformed = tmp_path / "bad.json"
    malformed.write_text(json.dumps({"expression": {}}), encoding="utf-8")
    with pytest.raises(BehaviorProfileError):
        BehaviorProfile(malformed)


def test_tool_audit_redacts_common_secrets(tmp_path: Path):
    log = ToolAuditLog(str(tmp_path / "audit.sqlite3"))
    try:
        log.record(
            "future.publish",
            {
                "title": "hello",
                "api_key": "super-secret",
                "nested": {"Authorization": "Bearer abc", "safe": "ok"},
            },
            True,
            output={"session_token": "token-value", "id": "123"},
        )
        row = log.recent(1)[0]
        assert row["arguments"]["api_key"] == "[REDACTED]"
        assert row["arguments"]["nested"]["Authorization"] == "[REDACTED]"
        assert row["arguments"]["nested"]["safe"] == "ok"
        assert row["output"]["session_token"] == "[REDACTED]"
        assert row["output"]["id"] == "123"
    finally:
        log.close()


def test_model_selection_reports_unavailable_model():
    selection = resolve_ollama_model(
        "http://localhost:11434",
        "qwen3.5:4b",
        "qwen3.5:4b",
        "qwen3:4b",
        installed=("qwen3:4b",),
    )
    assert selection.selected_available is False
    with pytest.raises(ModelSelectionError, match="ollama pull qwen3.5:4b"):
        require_available(selection)


def test_model_list_network_error_is_normalized(monkeypatch):
    def fail(*args, **kwargs):
        raise httpx.ConnectError("offline")

    monkeypatch.setattr(httpx, "get", fail)
    with pytest.raises(ModelSelectionError, match="Is Ollama running"):
        installed_ollama_models("http://127.0.0.1:11434")
