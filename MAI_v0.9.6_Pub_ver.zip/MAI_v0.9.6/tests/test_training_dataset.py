from pathlib import Path
import sys

sys.path.insert(
    0,
    str(Path(__file__).resolve().parents[1] / "training"),
)

from dataset import (
    dedupe,
    split_rows,
    to_prompt_completion,
    validate_row,
)


SYSTEM = "You are MAI."


def test_row_validation():
    row = {
        "mode": "focused",
        "input": "Help me debug this.",
        "response": "Show me the smallest reproducible failure first.",
    }
    assert validate_row(row) == []


def test_identity_filter():
    row = {
        "mode": "relaxed",
        "input": "Who are you?",
        "response": "I am Lisa.",
    }
    assert "identity" in validate_row(row)


def test_prompt_completion_shape():
    row = {
        "mode": "creative",
        "input": "The chorus feels flat.",
        "response": "Give it a stronger contrast.",
    }
    item = to_prompt_completion(row, SYSTEM)
    assert item["prompt"][0]["role"] == "system"
    assert item["completion"][0]["role"] == "assistant"


def test_dedupe():
    row = {
        "mode": "relaxed",
        "input": "Hi",
        "response": "Hey.",
    }
    assert len(dedupe([row, row])) == 1


def test_split_keeps_rows():
    rows = [
        {
            "prompt": [{"role": "user", "content": f"{mode}-{i}"}],
            "completion": [{"role": "assistant", "content": "x"}],
            "mode": mode,
        }
        for mode in (
            "relaxed",
            "focused",
            "creative",
            "performance",
            "vulnerable",
        )
        for i in range(20)
    ]
    train, evaluation = split_rows(rows)
    assert len(train) + len(evaluation) == len(rows)
    assert 10 <= len(evaluation) <= 20
    assert {row["mode"] for row in evaluation} == {
        "relaxed",
        "focused",
        "creative",
        "performance",
        "vulnerable",
    }
