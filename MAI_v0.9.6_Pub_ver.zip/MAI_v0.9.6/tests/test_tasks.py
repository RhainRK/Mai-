from pathlib import Path
import tempfile

from idol.tasks import TaskStore


def make_store():
    temp = tempfile.NamedTemporaryFile(
        suffix=".sqlite3",
        delete=False,
    )
    temp.close()
    return Path(temp.name), TaskStore(temp.name)


def test_goal_lifecycle():
    path, store = make_store()

    try:
        goal = store.create(
            "Learn chess",
            "Play a complete legal game",
            [
                "Learn legal movement",
                "Practice opening principles",
            ],
            4,
        )
        assert goal["status"] == "active"
        assert len(goal["steps"]) == 2

        step = store.claim_next(goal["id"])
        assert step["status"] == "running"

        goal = store.complete(
            goal["id"],
            step["id"],
            "Reviewed legal movement.",
        )
        assert goal["steps"][0]["status"] == "completed"

        second = store.claim_next(goal["id"])
        goal = store.complete(
            goal["id"],
            second["id"],
            "Practised development and castling.",
        )
        assert goal["status"] == "completed"
    finally:
        store.close()
        path.unlink(missing_ok=True)


def test_retry():
    path, store = make_store()

    try:
        goal = store.create(
            "Test",
            "Finish",
            ["One", "Two"],
        )
        step = store.claim_next(goal["id"])
        goal = store.fail(
            goal["id"],
            step["id"],
            "Blocked",
            True,
        )
        assert goal["steps"][0]["status"] == "pending"

        again = store.claim_next(goal["id"])
        assert again["attempts"] == 2
    finally:
        store.close()
        path.unlink(missing_ok=True)


def test_completion_requires_claim():
    path, store = make_store()

    try:
        goal = store.create(
            "Test",
            "Finish",
            ["One", "Two"],
        )
        step = goal["steps"][0]
        try:
            store.complete(
                goal["id"],
                step["id"],
                "Not claimed",
            )
        except ValueError:
            pass
        else:
            raise AssertionError("Expected ValueError")
    finally:
        store.close()
        path.unlink(missing_ok=True)


def test_nonretry_failure_fails_goal():
    path, store = make_store()

    try:
        goal = store.create(
            "Test",
            "Finish",
            ["One", "Two"],
        )
        step = store.claim_next(goal["id"])
        goal = store.fail(
            goal["id"],
            step["id"],
            "Blocked",
            False,
        )
        assert goal["status"] == "failed"
    finally:
        store.close()
        path.unlink(missing_ok=True)
