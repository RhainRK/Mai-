import numpy as np

from idol.realtime.audio import resample_int16


def test_resample_size():
    source = np.arange(2400, dtype=np.int16)
    output = resample_int16(source, 24000, 16000)
    assert 1599 <= output.size <= 1601
