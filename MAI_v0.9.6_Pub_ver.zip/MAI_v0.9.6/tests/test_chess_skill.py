import pytest

chess = pytest.importorskip("chess")

from idol.chess_skill import ChessSkill


def test_chess_state_and_move():
    skill = ChessSkill()
    state = skill.state()
    assert state["turn"] == "white"
    assert "e4" in state["legal_moves"]

    result = skill.play("e4")
    assert result["san"] == "e4"
    assert result["next_turn"] == "black"
