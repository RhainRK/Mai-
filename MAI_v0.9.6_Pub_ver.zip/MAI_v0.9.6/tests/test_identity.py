from pathlib import Path

from idol.identity import IdentityStore


IDENTITY = Path(__file__).parents[1] / "data" / "persona" / "mai_identity.json"


def test_identity_is_versioned_and_builds_persona():
    identity = IdentityStore(IDENTITY)
    persona = identity.persona()
    assert identity.identity_id == "mai"
    assert identity.version
    assert len(identity.fingerprint) == 64
    assert persona.stage_name == "MAI"
    assert "AI" in persona.public_identity


def test_public_identity_filters_internal_canon():
    identity = IdentityStore(IDENTITY)
    public = identity.context("public")
    internal = identity.context("internal")
    assert "privacy.rule" not in public
    assert "privacy.rule" in internal
