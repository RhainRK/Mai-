from __future__ import annotations

from dataclasses import dataclass
import random
import threading
import time

import httpx


@dataclass(frozen=True, slots=True)
class AvatarStatus:
    enabled: bool
    backend: str
    audio_device: str
    url: str
    events: bool
    autonomy: bool


class VNyanAvatarBridge:
    def __init__(
        self,
        enabled: bool,
        audio_device: str,
        base_url: str,
        events: bool = True,
        timeout: float = 2.0,
        autonomy: bool = True,
        idle_min_seconds: float = 2.8,
        idle_max_seconds: float = 6.0,
    ):
        self.enabled = bool(enabled)
        self.audio_device = audio_device.strip()
        self.base_url = base_url.rstrip("/")
        self.events = bool(events)
        self.autonomy = bool(autonomy)
        self.idle_min_seconds = max(1.0, float(idle_min_seconds))
        self.idle_max_seconds = max(self.idle_min_seconds, float(idle_max_seconds))
        self.timeout = max(0.05, float(timeout))
        self.client = httpx.Client(timeout=self.timeout)
        self._client_lock = threading.Lock()
        self._rng = random.Random()
        self._stop = threading.Event()
        self._closed = threading.Event()
        self._speaking = threading.Event()
        self._energy = 0.7
        self._motion_thread: threading.Thread | None = None
        if self.enabled and self.events and self.autonomy:
            self._start_motion_loop()

    def status(self) -> AvatarStatus:
        return AvatarStatus(
            enabled=self.enabled,
            backend="vnyan",
            audio_device=self.audio_device,
            url=self.base_url,
            events=self.events,
            autonomy=self.autonomy,
        )

    def send(self, action: str, payload: dict[str, str] | None = None) -> bool:
        if not self.enabled or not self.events or self._closed.is_set():
            return False
        clean = {str(key): str(value) for key, value in (payload or {}).items()}
        try:
            with self._client_lock:
                if self._closed.is_set():
                    return False
                response = self.client.post(
                    self.base_url,
                    json={"action": action, "payload": clean},
                )
            response.raise_for_status()
            return True
        except httpx.HTTPError:
            return False

    @staticmethod
    def _expression(text: str, state: dict | None = None) -> tuple[str, float]:
        state = state or {}
        lowered = text.casefold()
        energy = float(state.get("energy", 0.7))
        confidence = float(state.get("confidence", 0.72))
        stress = float(state.get("stress", 0.18))
        curiosity = float(state.get("curiosity", 0.78))
        playfulness = float(state.get("playfulness", 0.68))
        focus = float(state.get("focus", 0.65))

        if any(word in lowered for word in ("sorry", "worried", "problem", "difficult")) or stress >= 0.5:
            return "concerned", max(0.45, min(1.0, stress))
        if any(word in lowered for word in ("amazing", "great", "love", "excited", "yes!")) or energy >= 0.84:
            return "excited", max(0.6, min(1.0, energy))
        if any(word in lowered for word in ("hmm", "interesting", "wonder", "maybe")) or curiosity >= 0.9:
            return "curious", max(0.5, min(1.0, curiosity))
        if focus >= 0.8:
            return "focused", max(0.5, min(1.0, focus))
        if playfulness >= 0.78:
            return "playful", max(0.5, min(1.0, playfulness))
        if confidence >= 0.76:
            return "happy", max(0.45, min(0.9, confidence))
        return "neutral", 0.5

    def sync_state(self, state: dict | None = None, text: str = "") -> bool:
        state = state or {}
        self._energy = max(0.0, min(1.0, float(state.get("energy", self._energy))))
        expression, intensity = self._expression(text, state)
        payload = {
            "expression": expression,
            "intensity": f"{intensity:.3f}",
            "energy": f"{self._energy:.3f}",
            "confidence": f"{float(state.get('confidence', 0.72)):.3f}",
            "stress": f"{float(state.get('stress', 0.18)):.3f}",
            "curiosity": f"{float(state.get('curiosity', 0.78)):.3f}",
            "playfulness": f"{float(state.get('playfulness', 0.68)):.3f}",
            "focus": f"{float(state.get('focus', 0.65)):.3f}",
        }
        sent = self.send("mai_state", payload)
        self.send(
            "mai_expression",
            {"name": expression, "intensity": f"{intensity:.3f}"},
        )
        return sent

    def expression(self, name: str, intensity: float = 0.7) -> bool:
        intensity = max(0.0, min(1.0, float(intensity)))
        return self.send(
            "mai_expression",
            {"name": name.strip().casefold() or "neutral", "intensity": f"{intensity:.3f}"},
        )

    def look(self, x: float, y: float, hold_ms: int = 1400) -> bool:
        x = max(-1.0, min(1.0, float(x)))
        y = max(-1.0, min(1.0, float(y)))
        return self.send(
            "mai_look",
            {"x": f"{x:.3f}", "y": f"{y:.3f}", "hold_ms": str(max(100, int(hold_ms)))},
        )

    def blink(self, duration_ms: int = 145) -> bool:
        return self.send("mai_blink", {"duration_ms": str(max(60, int(duration_ms)))})

    def speaking_started(self, text: str = "", state: dict | None = None) -> bool:
        self._speaking.set()
        if state is not None:
            self.sync_state(state, text)
        payload = {"text": text[:400]} if text else {}
        payload["energy"] = f"{self._energy:.3f}"
        return self.send("mai_speaking_start", payload)

    def speaking_finished(self) -> bool:
        self._speaking.clear()
        return self.send("mai_speaking_stop", {"energy": f"{self._energy:.3f}"})

    def idle_test(self) -> bool:
        sent = self.send(
            "mai_idle",
            {
                "head_yaw": "7.0",
                "head_pitch": "-2.0",
                "head_roll": "2.0",
                "body_sway": "0.25",
                "energy": f"{self._energy:.3f}",
            },
        )
        self.look(0.35, 0.10, 1000)
        self.blink()
        return sent

    def test(self) -> bool:
        return self.send("mai_avatar_test", {"source": "MAI"})

    def _start_motion_loop(self):
        if self._motion_thread is not None:
            return
        self._motion_thread = threading.Thread(
            target=self._motion_loop,
            name="mai-avatar-motion",
            daemon=True,
        )
        self._motion_thread.start()

    def _motion_loop(self):
        next_blink = time.monotonic() + self._rng.uniform(2.2, 4.8)
        next_look = time.monotonic() + self._rng.uniform(1.8, 3.8)
        next_idle = time.monotonic() + self._rng.uniform(
            self.idle_min_seconds,
            self.idle_max_seconds,
        )

        while not self._stop.wait(0.12):
            now = time.monotonic()
            speaking = self._speaking.is_set()

            if now >= next_blink:
                self.blink(self._rng.randint(105, 180))
                next_blink = now + self._rng.uniform(2.5, 5.5)

            if now >= next_look:
                span = 0.48 if speaking else 0.28
                self.look(
                    self._rng.uniform(-span, span),
                    self._rng.uniform(-span * 0.55, span * 0.55),
                    self._rng.randint(900, 2400),
                )
                next_look = now + self._rng.uniform(1.6, 3.4 if speaking else 5.0)

            if now >= next_idle:
                motion_scale = 1.0 if speaking else 0.55
                energy = max(0.2, self._energy)
                self.send(
                    "mai_idle",
                    {
                        "head_yaw": f"{self._rng.uniform(-6.0, 6.0) * motion_scale:.2f}",
                        "head_pitch": f"{self._rng.uniform(-2.8, 2.8) * motion_scale:.2f}",
                        "head_roll": f"{self._rng.uniform(-2.4, 2.4) * motion_scale:.2f}",
                        "body_sway": f"{self._rng.uniform(-0.30, 0.30) * motion_scale:.3f}",
                        "energy": f"{energy:.3f}",
                        "speaking": "1" if speaking else "0",
                    },
                )
                next_idle = now + self._rng.uniform(
                    self.idle_min_seconds * (0.65 if speaking else 1.0),
                    self.idle_max_seconds * (0.75 if speaking else 1.0),
                )

    def close(self):
        if self._closed.is_set():
            return
        self._closed.set()
        self._stop.set()
        if self._motion_thread is not None:
            self._motion_thread.join(timeout=self.timeout + 0.5)
        with self._client_lock:
            self.client.close()
