from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
from typing import Any, Literal

import numpy as np

from .database import close_database, connect_database


MemoryType = Literal["episodic", "semantic", "preference", "creative", "relationship", "working"]
_VALID_TYPES = {"episodic", "semantic", "preference", "creative", "relationship", "working"}
_VALID_VISIBILITY = {"public", "private", "internal"}
_HISTORY_HINT_RE = re.compile(
    r"\b(used to|previous(?:ly)?|before|changed?|change|why did|history|earlier|originally|old)\b",
    re.IGNORECASE,
)
_TOKEN_RE = re.compile(r"[\w']+", re.UNICODE)


class ContinuityStore:
    """Versioned long-term continuity store."""

    def __init__(self, db_path: str, embedder, candidate_limit: int = 400):
        self.conn = connect_database(db_path, timeout=30.0)
        self.embedder = embedder
        self.candidate_limit = max(50, int(candidate_limit))
        self._setup()

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _normalize_key(key: str) -> str:
        value = re.sub(r"[^a-z0-9_.-]+", "_", key.strip().casefold())
        return value.strip("_.-")

    @staticmethod
    def _hash(subject: str, memory_type: str, key: str, content: str) -> str:
        normalized = " ".join(content.casefold().split())
        payload = f"{subject}\0{memory_type}\0{key}\0{normalized}"
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    @staticmethod
    def _recency(created_at: str) -> float:
        try:
            created = datetime.fromisoformat(created_at)
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            days = max(0.0, (datetime.now(timezone.utc) - created).total_seconds() / 86400.0)
            return math.exp(-days / 180.0)
        except (TypeError, ValueError):
            return 0.0

    def _setup(self) -> None:
        with self.conn:
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS continuity_memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    subject TEXT NOT NULL DEFAULT 'mai',
                    memory_type TEXT NOT NULL,
                    memory_key TEXT NOT NULL,
                    content TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'current',
                    visibility TEXT NOT NULL DEFAULT 'private',
                    confidence REAL NOT NULL DEFAULT 0.8,
                    importance REAL NOT NULL DEFAULT 0.7,
                    source TEXT NOT NULL DEFAULT 'creator',
                    reason TEXT NOT NULL DEFAULT '',
                    supersedes_id INTEGER,
                    superseded_by_id INTEGER,
                    content_hash TEXT NOT NULL,
                    embedding BLOB,
                    embedding_model TEXT,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY(supersedes_id) REFERENCES continuity_memories(id),
                    FOREIGN KEY(superseded_by_id) REFERENCES continuity_memories(id)
                );

                CREATE UNIQUE INDEX IF NOT EXISTS idx_continuity_current_key
                    ON continuity_memories(subject, memory_type, memory_key)
                    WHERE status='current';
                CREATE INDEX IF NOT EXISTS idx_continuity_status
                    ON continuity_memories(status, memory_type, importance DESC, id DESC);
                CREATE INDEX IF NOT EXISTS idx_continuity_visibility
                    ON continuity_memories(visibility, status, id DESC);
                CREATE INDEX IF NOT EXISTS idx_continuity_hash
                    ON continuity_memories(content_hash);
                CREATE INDEX IF NOT EXISTS idx_continuity_supersedes
                    ON continuity_memories(supersedes_id, superseded_by_id);
                """
            )

    def _validate(
        self,
        memory_type: str,
        visibility: str,
        confidence: float,
        importance: float,
    ) -> tuple[str, str, float, float]:
        memory_type = memory_type.strip().casefold()
        visibility = visibility.strip().casefold()
        if memory_type not in _VALID_TYPES:
            raise ValueError(f"memory_type must be one of: {', '.join(sorted(_VALID_TYPES))}")
        if visibility not in _VALID_VISIBILITY:
            raise ValueError("visibility must be public, private, or internal")
        return (
            memory_type,
            visibility,
            max(0.0, min(float(confidence), 1.0)),
            max(0.0, min(float(importance), 1.0)),
        )

    def set_current(
        self,
        memory_type: str,
        key: str,
        content: str,
        *,
        subject: str = "mai",
        visibility: str = "private",
        confidence: float = 0.85,
        importance: float = 0.8,
        source: str = "creator",
        reason: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        subject = subject.strip().casefold() or "mai"
        key = self._normalize_key(key)
        content = content.strip()
        reason = reason.strip()
        if not key or not content:
            raise ValueError("A stable memory key and content are required")
        memory_type, visibility, confidence, importance = self._validate(
            memory_type, visibility, confidence, importance
        )

        existing = self.conn.execute(
            """
            SELECT * FROM continuity_memories
            WHERE subject=? AND memory_type=? AND memory_key=? AND status='current'
            LIMIT 1
            """,
            (subject, memory_type, key),
        ).fetchone()

        digest = self._hash(subject, memory_type, key, content)
        now = self._now()
        if existing is not None and existing["content_hash"] == digest:
            with self.conn:
                self.conn.execute(
                    """
                    UPDATE continuity_memories
                    SET confidence=MAX(confidence, ?), importance=MAX(importance, ?),
                        visibility=?, source=?, reason=CASE WHEN ?='' THEN reason ELSE ? END,
                        metadata_json=?, updated_at=?
                    WHERE id=?
                    """,
                    (
                        confidence,
                        importance,
                        visibility,
                        source,
                        reason,
                        reason,
                        json.dumps(metadata or {}, ensure_ascii=False),
                        now,
                        existing["id"],
                    ),
                )
            return self.get(int(existing["id"]))

        vector = self.embedder.encode(content).astype(np.float32, copy=False)
        old_id = int(existing["id"]) if existing is not None else None
        with self.conn:
            # Version rollover
            if old_id is not None:
                self.conn.execute(
                    """
                    UPDATE continuity_memories
                    SET status='superseded', updated_at=?
                    WHERE id=?
                    """,
                    (now, old_id),
                )
            cursor = self.conn.execute(
                """
                INSERT INTO continuity_memories(
                    subject, memory_type, memory_key, content, status, visibility,
                    confidence, importance, source, reason, supersedes_id,
                    content_hash, embedding, embedding_model, metadata_json,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, 'current', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    subject,
                    memory_type,
                    key,
                    content,
                    visibility,
                    confidence,
                    importance,
                    source,
                    reason,
                    old_id,
                    digest,
                    vector.tobytes(),
                    self.embedder.identity,
                    json.dumps(metadata or {}, ensure_ascii=False),
                    now,
                    now,
                ),
            )
            new_id = int(cursor.lastrowid)
            if old_id is not None:
                self.conn.execute(
                    """
                    UPDATE continuity_memories
                    SET superseded_by_id=?, updated_at=?
                    WHERE id=?
                    """,
                    (new_id, now, old_id),
                )
        return self.get(new_id)

    def record_episode(
        self,
        key: str,
        content: str,
        *,
        visibility: str = "private",
        importance: float = 0.6,
        source: str = "runtime",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        key = self._normalize_key(key)
        content = content.strip()
        if not key or not content:
            raise ValueError("Episode key and content are required")
        _, visibility, confidence, importance = self._validate(
            "episodic", visibility, 1.0, importance
        )
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")
        memory_key = f"{key}.{stamp}"
        digest = self._hash("mai", "episodic", memory_key, content)
        vector = self.embedder.encode(content).astype(np.float32, copy=False)
        now = self._now()
        with self.conn:
            cursor = self.conn.execute(
                """
                INSERT INTO continuity_memories(
                    subject, memory_type, memory_key, content, status, visibility,
                    confidence, importance, source, reason, content_hash,
                    embedding, embedding_model, metadata_json, created_at, updated_at
                ) VALUES ('mai', 'episodic', ?, ?, 'historical', ?, ?, ?, ?, '', ?, ?, ?, ?, ?, ?)
                """,
                (
                    memory_key,
                    content,
                    visibility,
                    confidence,
                    importance,
                    source,
                    digest,
                    vector.tobytes(),
                    self.embedder.identity,
                    json.dumps(metadata or {}, ensure_ascii=False),
                    now,
                    now,
                ),
            )
        return self.get(int(cursor.lastrowid))

    def get(self, memory_id: int) -> dict[str, Any]:
        row = self.conn.execute(
            "SELECT * FROM continuity_memories WHERE id=?", (int(memory_id),)
        ).fetchone()
        if row is None:
            raise ValueError(f"Unknown continuity memory: {memory_id}")
        return self._decode(row)

    @staticmethod
    def _decode(row: sqlite3.Row) -> dict[str, Any]:
        item = dict(row)
        item["confidence"] = float(item["confidence"])
        item["importance"] = float(item["importance"])
        try:
            item["metadata"] = json.loads(item.pop("metadata_json"))
        except (json.JSONDecodeError, TypeError):
            item["metadata"] = {}
            item.pop("metadata_json", None)
        item.pop("embedding", None)
        return item

    def _public_projection_rows(
        self,
        *,
        subject: str = "mai",
        memory_type: str | None = None,
        limit: int = 100,
    ) -> list[sqlite3.Row]:
        """Build the current public continuity projection."""
        clauses = ["subject=?", "visibility='public'", "memory_type!='episodic'"]
        args: list[Any] = [subject.strip().casefold() or "mai"]
        if memory_type:
            value = memory_type.strip().casefold()
            if value not in _VALID_TYPES:
                raise ValueError(f"Unknown memory type: {memory_type}")
            clauses.append("memory_type=?")
            args.append(value)

        rows = self.conn.execute(
            f"""
            SELECT * FROM continuity_memories
            WHERE {' AND '.join(clauses)}
            ORDER BY id DESC
            """,
            tuple(args),
        ).fetchall()
        selected: list[sqlite3.Row] = []
        seen: set[tuple[str, str]] = set()
        for row in rows:
            key = (str(row["memory_type"]), str(row["memory_key"]))
            if key in seen:
                continue
            seen.add(key)
            # Public retraction
            if row["status"] == "retracted":
                continue
            selected.append(row)
            if len(selected) >= max(1, int(limit)):
                break
        selected.sort(
            key=lambda row: (float(row["importance"]), str(row["updated_at"]), int(row["id"])),
            reverse=True,
        )
        return selected[: max(1, int(limit))]

    def current(
        self,
        memory_type: str | None = None,
        *,
        subject: str = "mai",
        audience: str = "internal",
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        if audience.casefold() == "public":
            result = []
            for row in self._public_projection_rows(
                subject=subject, memory_type=memory_type, limit=limit
            ):
                item = self._decode(row)
                item["status"] = "public_current"
                result.append(item)
            return result

        clauses = ["subject=?", "status='current'"]
        args: list[Any] = [subject.strip().casefold() or "mai"]
        if memory_type:
            value = memory_type.strip().casefold()
            if value not in _VALID_TYPES:
                raise ValueError(f"Unknown memory type: {memory_type}")
            clauses.append("memory_type=?")
            args.append(value)
        args.append(max(1, int(limit)))
        rows = self.conn.execute(
            f"""
            SELECT * FROM continuity_memories
            WHERE {' AND '.join(clauses)}
            ORDER BY importance DESC, updated_at DESC, id DESC
            LIMIT ?
            """,
            tuple(args),
        ).fetchall()
        return [self._decode(row) for row in rows]

    def history(
        self,
        key: str,
        *,
        memory_type: str | None = None,
        subject: str = "mai",
        audience: str = "internal",
    ) -> list[dict[str, Any]]:
        key = self._normalize_key(key)
        clauses = ["subject=?", "memory_key=?"]
        args: list[Any] = [subject.strip().casefold() or "mai", key]
        if memory_type:
            clauses.append("memory_type=?")
            args.append(memory_type.strip().casefold())
        if audience.casefold() == "public":
            clauses.append("visibility='public'")
        rows = self.conn.execute(
            f"""
            SELECT * FROM continuity_memories
            WHERE {' AND '.join(clauses)}
            ORDER BY created_at ASC, id ASC
            """,
            tuple(args),
        ).fetchall()
        return [self._decode(row) for row in rows]

    def retract(self, memory_id: int, *, reason: str = "") -> dict[str, Any]:
        item = self.get(memory_id)
        if item["status"] != "current":
            return item
        now = self._now()
        with self.conn:
            self.conn.execute(
                """
                UPDATE continuity_memories
                SET status='retracted', reason=CASE WHEN ?='' THEN reason ELSE ? END,
                    updated_at=?
                WHERE id=?
                """,
                (reason.strip(), reason.strip(), now, int(memory_id)),
            )
        return self.get(memory_id)

    def _embedding_for(self, row: sqlite3.Row) -> np.ndarray:
        if row["embedding"] and row["embedding_model"] == self.embedder.identity:
            return np.frombuffer(row["embedding"], dtype=np.float32)
        vector = self.embedder.encode(row["content"]).astype(np.float32, copy=False)
        with self.conn:
            self.conn.execute(
                "UPDATE continuity_memories SET embedding=?, embedding_model=?, updated_at=? WHERE id=?",
                (vector.tobytes(), self.embedder.identity, self._now(), row["id"]),
            )
        return vector

    def recall(
        self,
        query: str,
        *,
        subject: str = "mai",
        audience: str = "internal",
        limit: int = 8,
        include_history: bool | None = None,
    ) -> list[dict[str, Any]]:
        query = query.strip()
        if not query or limit <= 0:
            return []
        if include_history is None:
            include_history = bool(_HISTORY_HINT_RE.search(query))

        public_mode = audience.casefold() == "public"
        projected_ids: set[int] = set()
        if public_mode and not include_history:
            projected = self._public_projection_rows(
                subject=subject, limit=self.candidate_limit
            )
            projected_ids = {int(row["id"]) for row in projected}
            episode_rows = self.conn.execute(
                """
                SELECT * FROM continuity_memories
                WHERE subject=? AND visibility='public'
                  AND memory_type='episodic' AND status='historical'
                ORDER BY importance DESC, updated_at DESC, id DESC
                LIMIT ?
                """,
                (subject.strip().casefold() or "mai", self.candidate_limit),
            ).fetchall()
            rows = [*projected, *episode_rows]
        else:
            clauses = ["subject=?"]
            args: list[Any] = [subject.strip().casefold() or "mai"]
            if not include_history:
                clauses.append("(status='current' OR (memory_type='episodic' AND status='historical'))")
            else:
                clauses.append("status IN ('current','superseded','retracted','historical')")
            if public_mode:
                clauses.append("visibility='public'")
            args.append(self.candidate_limit)
            rows = self.conn.execute(
                f"""
                SELECT * FROM continuity_memories
                WHERE {' AND '.join(clauses)}
                ORDER BY importance DESC, updated_at DESC, id DESC
                LIMIT ?
                """,
                tuple(args),
            ).fetchall()
        if not rows:
            return []

        qvec = self.embedder.encode(query).astype(np.float32, copy=False)
        qtokens = set(_TOKEN_RE.findall(query.casefold()))
        scored: list[tuple[float, sqlite3.Row]] = []
        for row in rows:
            vector = self._embedding_for(row)
            if vector.shape != qvec.shape:
                continue
            semantic = float(np.dot(vector, qvec))
            semantic_unit = max(0.0, min((semantic + 1.0) / 2.0, 1.0))
            tokens = set(_TOKEN_RE.findall(f"{row['memory_key']} {row['content']}".casefold()))
            lexical = len(qtokens & tokens) / max(1, len(qtokens | tokens))
            importance = max(0.0, min(float(row["importance"]), 1.0))
            recency = self._recency(row["updated_at"])
            is_current_for_audience = row["status"] == "current" or int(row["id"]) in projected_ids
            current_bonus = 0.08 if is_current_for_audience else 0.0
            score = semantic_unit * 0.58 + lexical * 0.22 + importance * 0.09 + recency * 0.03 + current_bonus
            scored.append((score, row))

        scored.sort(key=lambda item: item[0], reverse=True)
        result = []
        seen: set[tuple[str, str, str]] = set()
        for score, row in scored:
            signature = (row["memory_type"], row["memory_key"], row["content"].casefold())
            if signature in seen:
                continue
            seen.add(signature)
            item = self._decode(row)
            if public_mode and int(row["id"]) in projected_ids:
                item["status"] = "public_current"
            item["recall_score"] = float(score)
            result.append(item)
            if len(result) >= limit:
                break
        return result

    def context_with_refs(
        self,
        query: str,
        audience: str = "internal",
        limit: int = 8,
    ) -> tuple[str, list[int]]:
        rows = self.recall(query, audience=audience, limit=limit)
        if not rows:
            return "None yet.", []
        lines = []
        ids = []
        for item in rows:
            ids.append(int(item["id"]))
            state = (
                "CURRENT"
                if item["status"] in {"current", "public_current"}
                else item["status"].upper()
            )
            reason = f"; reason: {item['reason']}" if item.get("reason") else ""
            lines.append(
                f"- [{state} {item['memory_type']}] {item['memory_key']}: {item['content']}{reason}"
            )
        return "\n".join(lines), ids

    def stats(self) -> dict[str, Any]:
        total = int(self.conn.execute("SELECT COUNT(*) FROM continuity_memories").fetchone()[0])
        current = int(
            self.conn.execute("SELECT COUNT(*) FROM continuity_memories WHERE status='current'").fetchone()[0]
        )
        superseded = int(
            self.conn.execute("SELECT COUNT(*) FROM continuity_memories WHERE status='superseded'").fetchone()[0]
        )
        by_type = {
            row["memory_type"]: int(row["n"])
            for row in self.conn.execute(
                "SELECT memory_type, COUNT(*) AS n FROM continuity_memories GROUP BY memory_type"
            ).fetchall()
        }
        return {
            "records": total,
            "current": current,
            "superseded": superseded,
            "by_type": by_type,
            "embedding_backend": self.embedder.identity,
            "embedding_fallback_error": self.embedder.load_error,
        }

    def close(self) -> None:
        close_database(self.conn)
