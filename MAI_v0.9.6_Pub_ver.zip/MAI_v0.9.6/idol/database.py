from __future__ import annotations

from pathlib import Path
import sqlite3
from typing import Any


def connect_database(
    db_path: str | Path,
    *,
    timeout: float = 5.0,
    row_factory: bool = True,
) -> sqlite3.Connection:
    """Open SQLite with MAI's standard connection policy."""
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    timeout = max(0.1, float(timeout))
    connect_kwargs: dict[str, Any] = {
        "timeout": timeout,
        "isolation_level": "DEFERRED",
    }
    # SQLite compatibility
    if hasattr(sqlite3, "LEGACY_TRANSACTION_CONTROL"):
        connect_kwargs["autocommit"] = sqlite3.LEGACY_TRANSACTION_CONTROL
    conn = sqlite3.connect(str(path), **connect_kwargs)
    if row_factory:
        conn.row_factory = sqlite3.Row

    # Connection pragmas
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute(f"PRAGMA busy_timeout={max(100, int(timeout * 1000))}")
    conn.execute("PRAGMA optimize=0x10002")
    return conn


def close_database(conn: sqlite3.Connection) -> None:
    """Give SQLite a cheap chance to refresh planner stats before closing."""
    try:
        conn.execute("PRAGMA optimize")
    except sqlite3.DatabaseError:
        # Best-effort optimisation
        pass
    finally:
        conn.close()


def database_health(db_path: str | Path) -> dict[str, Any]:
    """Return non-destructive integrity diagnostics for doctor.py/tests."""
    path = Path(db_path)
    if not path.exists():
        return {
            "exists": False,
            "quick_check": "not_created",
            "foreign_key_violations": 0,
            "foreign_keys_enabled": True,
        }

    conn = connect_database(path, timeout=5.0)
    try:
        quick_rows = conn.execute("PRAGMA quick_check").fetchall()
        quick = "; ".join(str(row[0]) for row in quick_rows) or "unknown"
        fk_rows = conn.execute("PRAGMA foreign_key_check").fetchall()
        fk_enabled = bool(conn.execute("PRAGMA foreign_keys").fetchone()[0])
        return {
            "exists": True,
            "quick_check": quick,
            "foreign_key_violations": len(fk_rows),
            "foreign_keys_enabled": fk_enabled,
        }
    finally:
        close_database(conn)
