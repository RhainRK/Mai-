from __future__ import annotations

from dataclasses import dataclass
import sqlite3

from .planner import TurnPlan
from .prompts import build_system_prompt
from .context_governor import ContextGovernor


@dataclass(slots=True)
class RetrievedTurnContext:
    memories: list[dict]
    profile: list[dict]
    recent: list[dict]
    identity_text: str
    career_text: str
    continuity_text: str
    memory_ids: list[int]
    continuity_ids: list[int]
    canon_keys: list[str]
    career_event_ids: list[str]
    relationship_text: str
    goals_text: str
    learned_skills: str
    task_context: str


@dataclass(slots=True)
class PreparedTurn:
    messages: list[dict]
    plan: TurnPlan
    memory_ids: list[int]
    continuity_ids: list[int]
    canon_keys: list[str]
    career_event_ids: list[str]


class TurnContextBuilder:
    """Builds one consistent context boundary for every MAI conversation surface."""

    def __init__(
        self,
        *,
        persona,
        state,
        memory,
        relationship,
        goals,
        planner,
        learning,
        tasks,
        tools,
        behavior,
        identity,
        career,
        continuity,
        short_term_turns: int,
        memory_recall_limit: int,
        context_data_char_limit: int = 4500,
        input_context_char_limit: int = 14000,
        context_compression_threshold: float = 0.72,
    ):
        self.persona = persona
        self.state = state
        self.memory = memory
        self.relationship = relationship
        self.goals = goals
        self.planner = planner
        self.learning = learning
        self.tasks = tasks
        self.tools = tools
        self.behavior = behavior
        self.identity = identity
        self.career = career
        self.continuity = continuity
        self.short_term_turns = short_term_turns
        self.memory_recall_limit = memory_recall_limit
        self.context_data_char_limit = max(1500, int(context_data_char_limit))
        self.input_context_char_limit = max(6000, int(input_context_char_limit))
        governor_conn = getattr(self.memory, "conn", None) or sqlite3.connect(":memory:")
        governor_conn.row_factory = sqlite3.Row
        self.governor = ContextGovernor(
            governor_conn,
            self.input_context_char_limit,
            context_compression_threshold,
        )

    def retrieve(
        self,
        text: str,
        *,
        public_mode: bool,
        task_override: str | None = None,
    ) -> RetrievedTurnContext:
        self.state.drift_toward_baseline()
        audience = "public" if public_mode else "internal"

        memories = [] if public_mode else self.memory.recall(
            text,
            self.memory_recall_limit,
        )
        profile = [] if public_mode else self.memory.get_profile()
        recent = [] if public_mode else self.memory.recent_messages(
            self.short_term_turns
        )

        identity_rows = self.identity.canon(audience)
        identity_keys = [str(item.get("key", "")) for item in identity_rows if item.get("key")]
        career_text, career_canon_keys, event_ids = self.career.context_with_refs(
            text,
            audience,
        )
        continuity_text, continuity_ids = self.continuity.context_with_refs(
            text,
            audience,
        )
        canon_keys = list(dict.fromkeys([*identity_keys, *career_canon_keys]))

        return RetrievedTurnContext(
            memories=memories,
            profile=profile,
            recent=recent,
            identity_text=self.identity.context(audience),
            career_text=career_text,
            continuity_text=continuity_text,
            memory_ids=[int(item["id"]) for item in memories if "id" in item],
            continuity_ids=continuity_ids,
            canon_keys=canon_keys,
            career_event_ids=event_ids,
            relationship_text=(
                "Public audience; private relationship state is withheld."
                if public_mode
                else self.relationship.as_prompt()
            ),
            goals_text=(
                "Withheld in public mode."
                if public_mode
                else self.goals.as_prompt()
            ),
            learned_skills=(
                "Withheld in public mode."
                if public_mode
                else self.learning.context(text)
            ),
            task_context=(
                "Withheld in public mode."
                if public_mode
                else (task_override or self.tasks.context())
            ),
        )

    def _bounded_recent(
        self,
        messages: list[dict],
        system_chars: int,
        user_chars: int,
    ) -> list[dict]:
        """Keep the newest conversation history inside the configured input budget."""
        remaining = self.input_context_char_limit - system_chars - user_chars
        if remaining <= 0 or not messages:
            return []

        selected: list[dict] = []
        used = 0
        for message in reversed(messages):
            content = str(message.get("content", ""))
            cost = len(content) + 32
            if selected and used + cost > remaining:
                break
            if not selected and cost > remaining:
                keep = max(0, remaining - 64)
                if keep:
                    copy = dict(message)
                    copy["content"] = "…[older message truncated]… " + content[-keep:]
                    selected.append(copy)
                break
            selected.append(dict(message))
            used += cost

        selected.reverse()
        if selected and selected[0].get("role") == "assistant":
            selected.pop(0)
        return selected

    def prepare(
        self,
        text: str,
        route: tuple[str, ...],
        retrieved: RetrievedTurnContext,
        *,
        public_mode: bool,
    ) -> PreparedTurn:
        goal = self.goals.infer_turn_goal(text)
        plan = self.planner.plan(
            goal,
            retrieved.memories,
            retrieved.profile,
            route=route,
            public_mode=public_mode,
        )

        behavior_prompt = getattr(self.behavior, "prompt_for_relationship", None)
        behavior_text = (
            behavior_prompt(text, self.state, self.relationship)
            if callable(behavior_prompt)
            else self.behavior.prompt(text, self.state)
        )

        prompt = build_system_prompt(
            self.persona,
            self.state,
            retrieved.profile,
            retrieved.memories,
            retrieved.relationship_text,
            retrieved.goals_text,
            plan.as_prompt(),
            retrieved.learned_skills,
            retrieved.task_context,
            self.tools.names(route) if route else [],
            behavior_text,
            retrieved.identity_text,
            retrieved.career_text,
            retrieved.continuity_text,
            public_mode,
            self.context_data_char_limit,
        )

        governed = self.governor.govern(retrieved.recent, text, len(prompt) + len(text))
        recent = governed
        messages = [
            {"role": "system", "content": prompt},
            *recent,
            {"role": "user", "content": text},
        ]
        return PreparedTurn(
            messages=messages,
            plan=plan,
            memory_ids=retrieved.memory_ids,
            continuity_ids=retrieved.continuity_ids,
            canon_keys=retrieved.canon_keys,
            career_event_ids=retrieved.career_event_ids,
        )
