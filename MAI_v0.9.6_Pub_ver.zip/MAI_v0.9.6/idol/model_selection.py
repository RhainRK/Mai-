from __future__ import annotations

from dataclasses import dataclass

import httpx


class ModelSelectionError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class ModelSelection:
    selected: str
    installed: tuple[str, ...]
    preferred_available: bool
    fallback_available: bool
    selected_available: bool


def installed_ollama_models(base_url: str, timeout: float = 4.0) -> tuple[str, ...]:
    url = f"{base_url.rstrip('/')}/api/tags"
    try:
        response = httpx.get(url, timeout=timeout)
        response.raise_for_status()
        payload = response.json()
    except (httpx.HTTPError, ValueError) as exc:
        raise ModelSelectionError(
            f"Could not query Ollama at {base_url}. Is Ollama running? ({exc})"
        ) from exc
    if not isinstance(payload, dict):
        raise ModelSelectionError(f"Ollama returned an invalid model-list response from {url}")
    return tuple(
        item.get("name", "")
        for item in payload.get("models", [])
        if isinstance(item, dict) and item.get("name")
    )


def _matches(installed: tuple[str, ...], model: str) -> bool:
    return any(name == model or name.startswith(f"{model}:") for name in installed)


def resolve_ollama_model(
    base_url: str,
    requested: str,
    preferred: str,
    fallback: str,
    *,
    installed: tuple[str, ...] | None = None,
) -> ModelSelection:
    installed = installed if installed is not None else installed_ollama_models(base_url)
    preferred_ok = _matches(installed, preferred)
    fallback_ok = _matches(installed, fallback)

    if requested and requested.casefold() != "auto":
        selected = requested
    elif preferred_ok:
        selected = preferred
    else:
        selected = fallback

    return ModelSelection(
        selected=selected,
        installed=installed,
        preferred_available=preferred_ok,
        fallback_available=fallback_ok,
        selected_available=_matches(installed, selected),
    )


def require_available(selection: ModelSelection) -> str:
    """Validate model availability at startup."""
    if selection.selected_available:
        return selection.selected

    installed = ", ".join(selection.installed) if selection.installed else "none"
    raise ModelSelectionError(
        f"Ollama model '{selection.selected}' is not installed. "
        f"Installed models: {installed}. Run: ollama pull {selection.selected}"
    )
