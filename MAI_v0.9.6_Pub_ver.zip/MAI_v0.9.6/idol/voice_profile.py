from dataclasses import asdict, dataclass
import json
from pathlib import Path


@dataclass(frozen=True, slots=True)
class VoiceProfile:
    voice_id: str = "mai_v1"
    description: str = (
        "Original young-adult feminine pop-artist voice; warm, polished and self-possessed; "
        "clear modern international-English delivery with subtle British colour; medium pitch; "
        "smooth low-mid warmth; bright clean upper resonance; crisp diction; dry conversational timing."
    )
    speech_speed: float = 1.0
    speech_energy: float = 0.72
    speech_warmth: float = 0.64
    speech_breathiness: float = 0.18
    singing_breathiness: float = 0.20
    singing_energy: float = 0.82
    vibrato_amount: float = 0.24
    pitch_expression: float = 0.72
    tts_voice_name: str = "mai"

    def save(self, path: str = "data/voices/mai/profile.json"):
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
