from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class TurnPlan:
    goal: str
    strategy: str
    steps: tuple[str, ...]
    completion_criterion: str

    def as_prompt(self) -> str:
        steps = "\n".join(f"- {step}" for step in self.steps)
        return (
            f"Goal: {self.goal}\n"
            f"Strategy: {self.strategy}\n"
            f"Execution steps:\n{steps}\n"
            f"Completion criterion: {self.completion_criterion}"
        )


class Planner:
    """Builds a small observable execution plan, not hidden chain-of-thought."""

    def plan(
        self,
        turn_goal: str,
        memories: list[dict],
        profile: list[dict],
        route: tuple[str, ...] = (),
        public_mode: bool = False,
    ) -> TurnPlan:
        if public_mode:
            strategy = "public-safe direct response"
            steps = (
                "Use only public identity and confirmed public career context.",
                "Answer directly without private memory or tools.",
                "Return one complete visible response.",
            )
        elif route:
            strategy = "tool-assisted response"
            steps = (
                f"Use only routed tool families: {', '.join(route)}.",
                "Verify tool success before claiming completion.",
                "Synthesize one complete visible response from the result.",
            )
        else:
            strategy = "direct contextual response"
            steps = (
                f"Use up to {len(memories)} retrieved memories when relevant.",
                f"Use up to {len(profile)} known user facts when relevant.",
                "Return one complete visible response.",
            )

        return TurnPlan(
            goal=turn_goal,
            strategy=strategy,
            steps=steps,
            completion_criterion=(
                "A visible user-facing reply exists and no unverified action is claimed."
            ),
        )

    def make_plan(
        self,
        turn_goal: str,
        memories: list[dict],
        profile: list[dict],
        route: tuple[str, ...] = (),
        public_mode: bool = False,
    ) -> str:
        return self.plan(
            turn_goal,
            memories,
            profile,
            route=route,
            public_mode=public_mode,
        ).as_prompt()
