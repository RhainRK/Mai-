from __future__ import annotations

from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path
from typing import Any

from .persona import Persona


class IdentityError(RuntimeError):
    pass


class IdentityStore:
    """Versioned file-backed identity authority."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.data = self._load()
        self._fingerprint = self._compute_fingerprint()

    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise IdentityError(f"Identity file not found: {self.path}") from exc
        except json.JSONDecodeError as exc:
            raise IdentityError(f"Identity file is invalid JSON: {self.path}: {exc}") from exc

        required = ("schema_version", "identity_version", "identity_id", "persona", "canon")
        missing = [key for key in required if key not in data]
        if missing:
            raise IdentityError(f"Identity file is missing: {', '.join(missing)}")
        if not isinstance(data["canon"], list):
            raise IdentityError("identity.canon must be a list")

        seen_keys: set[str] = set()
        allowed_visibility = {"public", "private", "internal"}
        for index, item in enumerate(data["canon"]):
            if not isinstance(item, dict):
                raise IdentityError(f"identity.canon[{index}] must be an object")
            key = str(item.get("key", "")).strip()
            value = str(item.get("value", "")).strip()
            if not key or not value:
                raise IdentityError(f"identity.canon[{index}] requires key and value")
            if key in seen_keys:
                raise IdentityError(f"Duplicate canonical identity key: {key}")
            seen_keys.add(key)
            visibility = str(item.get("visibility", "public")).casefold()
            if visibility not in allowed_visibility:
                raise IdentityError(
                    f"identity.canon[{index}] has invalid visibility: {visibility}"
                )
        return data

    @property
    def identity_id(self) -> str:
        return str(self.data["identity_id"])

    @property
    def version(self) -> str:
        return str(self.data["identity_version"])

    def _compute_fingerprint(self) -> str:
        payload = json.dumps(
            self.data,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        )
        return sha256(payload.encode("utf-8")).hexdigest()

    @property
    def fingerprint(self) -> str:
        return self._fingerprint

    def persona(self) -> Persona:
        source = dict(self.data.get("persona", {}))
        defaults = asdict(Persona())
        values = {key: source.get(key, default) for key, default in defaults.items()}
        return Persona(**values)

    def creator(self) -> dict[str, Any]:
        """Return the canonical creator record, if configured."""
        creator = self.data.get("creator", {})
        return dict(creator) if isinstance(creator, dict) else {}

    @property
    def creator_name(self) -> str:
        return str(self.creator().get("name", "")).strip()

    @property
    def creator_subject_id(self) -> str:
        return str(self.creator().get("subject_id", "")).strip()

    def creator_context(self, audience: str = "internal") -> str:
        creator = self.creator()
        if not creator:
            return "No canonical creator is configured."
        visibility = str(creator.get("visibility", "internal")).casefold()
        if audience.casefold() == "public" and visibility != "public":
            return "Creator identity is not public."
        name = str(creator.get("name", "Unknown"))
        role = str(creator.get("role", "creator"))
        relation = str(creator.get("relationship_to_mai", ""))
        return f"Creator: {name} ({role}). {relation}".strip()

    def canon(self, audience: str = "internal") -> list[dict[str, Any]]:
        audience = audience.casefold()
        rows = []
        for item in self.data.get("canon", []):
            visibility = str(item.get("visibility", "public")).casefold()
            if audience == "public" and visibility != "public":
                continue
            rows.append(dict(item))
        return rows

    def context(self, audience: str = "internal") -> str:
        rows = self.canon(audience)
        canon = "\n".join(
            f"- {item.get('key', 'fact')}: {item.get('value', '')}"
            for item in rows
        ) or "None."
        principles = "\n".join(
            f"- {item}" for item in self.data.get("creative_principles", [])
        ) or "None."
        return (
            f"Identity version: {self.version}\n"
            f"CANONICAL FACTS\n{canon}\n\n"
            f"CREATIVE PRINCIPLES\n{principles}\n\n"
            f"CREATOR\n{self.creator_context(audience)}"
        )

    def summary(self) -> dict[str, Any]:
        return {
            "identity_id": self.identity_id,
            "identity_version": self.version,
            "fingerprint": self.fingerprint,
            "canon_facts": len(self.data.get("canon", [])),
            "creator_name": self.creator_name or None,
            "creator_subject_id": self.creator_subject_id or None,
            "path": str(self.path),
        }
