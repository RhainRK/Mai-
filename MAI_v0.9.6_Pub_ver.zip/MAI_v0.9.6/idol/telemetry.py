from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3

from .database import close_database, connect_database
from time import perf_counter
from typing import Any
from uuid import uuid4


@dataclass(slots=True)
class TurnMetrics:
    model: str = ""
    wall_seconds: float = 0.0
    prompt_tokens: int | None = None
    output_tokens: int | None = None
    tokens_per_second: float | None = None

    def as_dict(self) -> dict:
        return asdict(self)


class TurnTimer:
    def __init__(self):
        self.started = perf_counter()

    def elapsed(self) -> float:
        return perf_counter() - self.started


@dataclass(slots=True)
class StageRecord:
    name: str
    status: str
    started_ms: float
    duration_ms: float
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class TurnTrace:
    """Trace observable turn orchestration metadata."""

    trace_id: str
    mode: str
    model: str
    input_chars: int
    started_at: str
    route: list[str] = field(default_factory=list)
    memory_ids: list[int] = field(default_factory=list)
    continuity_ids: list[int] = field(default_factory=list)
    canon_keys: list[str] = field(default_factory=list)
    career_event_ids: list[str] = field(default_factory=list)
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    stages: list[StageRecord] = field(default_factory=list)
    plan_strategy: str = ""
    success: bool = False
    response_completed: bool = False
    output_chars: int = 0
    error: str | None = None
    finished_at: str | None = None
    wall_seconds: float = 0.0
    prompt_tokens: int | None = None
    output_tokens: int | None = None
    tokens_per_second: float | None = None
    _started_perf: float = field(default_factory=perf_counter, repr=False)
    _active_stage: str | None = field(default=None, repr=False)
    _active_stage_started: float | None = field(default=None, repr=False)

    @classmethod
    def create(cls, mode: str, model: str, input_chars: int) -> "TurnTrace":
        return cls(
            trace_id=f"turn_{uuid4().hex[:16]}",
            mode=mode,
            model=model,
            input_chars=max(0, int(input_chars)),
            started_at=datetime.now(timezone.utc).isoformat(),
        )

    def start_stage(self, name: str) -> None:
        if self._active_stage is not None:
            self.end_stage("ok")
        self._active_stage = name
        self._active_stage_started = perf_counter()

    def end_stage(
        self,
        status: str = "ok",
        details: dict[str, Any] | None = None,
    ) -> None:
        if self._active_stage is None or self._active_stage_started is None:
            return
        now = perf_counter()
        self.stages.append(
            StageRecord(
                name=self._active_stage,
                status=status,
                started_ms=(self._active_stage_started - self._started_perf) * 1000.0,
                duration_ms=(now - self._active_stage_started) * 1000.0,
                details=dict(details or {}),
            )
        )
        self._active_stage = None
        self._active_stage_started = None

    def add_tool(self, name: str, success: bool) -> None:
        self.tool_calls.append({"name": str(name), "success": bool(success)})

    def finish(
        self,
        *,
        success: bool,
        response_completed: bool,
        output_chars: int = 0,
        error: str | None = None,
        metrics: TurnMetrics | dict[str, Any] | None = None,
    ) -> None:
        if self._active_stage is not None:
            self.end_stage("ok" if success else "error")
        self.success = bool(success)
        self.response_completed = bool(response_completed)
        self.output_chars = max(0, int(output_chars))
        self.error = error[:500] if error else None
        self.finished_at = datetime.now(timezone.utc).isoformat()
        self.wall_seconds = perf_counter() - self._started_perf

        if metrics is not None:
            values = metrics.as_dict() if hasattr(metrics, "as_dict") else dict(metrics)
            self.prompt_tokens = values.get("prompt_tokens")
            self.output_tokens = values.get("output_tokens")
            self.tokens_per_second = values.get("tokens_per_second")

    def as_dict(self) -> dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "mode": self.mode,
            "model": self.model,
            "input_chars": self.input_chars,
            "started_at": self.started_at,
            "route": list(self.route),
            "memory_ids": list(self.memory_ids),
            "continuity_ids": list(self.continuity_ids),
            "canon_keys": list(self.canon_keys),
            "career_event_ids": list(self.career_event_ids),
            "tool_calls": list(self.tool_calls),
            "stages": [asdict(stage) for stage in self.stages],
            "plan_strategy": self.plan_strategy,
            "success": self.success,
            "response_completed": self.response_completed,
            "output_chars": self.output_chars,
            "error": self.error,
            "finished_at": self.finished_at,
            "wall_seconds": self.wall_seconds,
            "prompt_tokens": self.prompt_tokens,
            "output_tokens": self.output_tokens,
            "tokens_per_second": self.tokens_per_second,
        }

    def summary(self) -> dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "mode": self.mode,
            "model": self.model,
            "route": list(self.route),
            "memory_ids": list(self.memory_ids),
            "continuity_ids": list(self.continuity_ids),
            "career_event_ids": list(self.career_event_ids),
            "tools": [item["name"] for item in self.tool_calls],
            "plan_strategy": self.plan_strategy,
            "success": self.success,
            "response_completed": self.response_completed,
            "wall_seconds": round(self.wall_seconds, 4),
            "error": self.error,
        }


class TraceJournal:
    """SQLite-backed, privacy-minimised journal of turn traces."""

    def __init__(self, db_path: str, retention: int = 2000):
        self.conn = connect_database(db_path, timeout=30.0)
        self.retention = max(100, int(retention))
        self._setup()

    def _setup(self) -> None:
        with self.conn:
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS turn_traces (
                    trace_id TEXT PRIMARY KEY,
                    mode TEXT NOT NULL,
                    model TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    finished_at TEXT,
                    success INTEGER NOT NULL DEFAULT 0,
                    response_completed INTEGER NOT NULL DEFAULT 0,
                    wall_seconds REAL NOT NULL DEFAULT 0,
                    input_chars INTEGER NOT NULL DEFAULT 0,
                    output_chars INTEGER NOT NULL DEFAULT 0,
                    error TEXT,
                    trace_json TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_turn_traces_started
                    ON turn_traces(started_at DESC);
                CREATE INDEX IF NOT EXISTS idx_turn_traces_success
                    ON turn_traces(success, response_completed, started_at DESC);
                """
            )

    def save(self, trace: TurnTrace) -> None:
        payload = json.dumps(trace.as_dict(), ensure_ascii=False, default=str)
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO turn_traces(
                    trace_id, mode, model, started_at, finished_at, success,
                    response_completed, wall_seconds, input_chars, output_chars,
                    error, trace_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(trace_id) DO UPDATE SET
                    mode=excluded.mode,
                    model=excluded.model,
                    finished_at=excluded.finished_at,
                    success=excluded.success,
                    response_completed=excluded.response_completed,
                    wall_seconds=excluded.wall_seconds,
                    input_chars=excluded.input_chars,
                    output_chars=excluded.output_chars,
                    error=excluded.error,
                    trace_json=excluded.trace_json
                """,
                (
                    trace.trace_id,
                    trace.mode,
                    trace.model,
                    trace.started_at,
                    trace.finished_at,
                    int(trace.success),
                    int(trace.response_completed),
                    float(trace.wall_seconds),
                    int(trace.input_chars),
                    int(trace.output_chars),
                    trace.error,
                    payload,
                ),
            )
        if trace.finished_at:
            self._prune()

    def _prune(self) -> None:
        with self.conn:
            self.conn.execute(
                """
                DELETE FROM turn_traces
                WHERE trace_id IN (
                    SELECT trace_id FROM turn_traces
                    ORDER BY started_at DESC
                    LIMIT -1 OFFSET ?
                )
                """,
                (self.retention,),
            )

    @staticmethod
    def _decode(row: sqlite3.Row | None) -> dict[str, Any] | None:
        if row is None:
            return None
        return json.loads(row["trace_json"])

    def get(self, trace_id: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT trace_json FROM turn_traces WHERE trace_id=?",
            (trace_id,),
        ).fetchone()
        return self._decode(row)

    def recent(self, limit: int = 20) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 100))
        rows = self.conn.execute(
            """
            SELECT trace_json FROM turn_traces
            ORDER BY started_at DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [json.loads(row["trace_json"]) for row in rows]

    def stats(self) -> dict[str, Any]:
        total, completed, failed = self.conn.execute(
            """
            SELECT
                COUNT(*),
                SUM(CASE WHEN response_completed=1 THEN 1 ELSE 0 END),
                SUM(CASE WHEN success=0 AND finished_at IS NOT NULL THEN 1 ELSE 0 END)
            FROM turn_traces
            """
        ).fetchone()
        total = int(total or 0)
        completed = int(completed or 0)
        failed = int(failed or 0)
        return {
            "turns": total,
            "completed_replies": completed,
            "failed_turns": failed,
            "completion_rate": (completed / total) if total else 1.0,
            "retention": self.retention,
        }

    def close(self) -> None:
        close_database(self.conn)
