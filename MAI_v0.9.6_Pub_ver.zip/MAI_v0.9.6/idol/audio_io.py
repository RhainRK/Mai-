from collections import deque
from dataclasses import dataclass
from pathlib import Path
import wave

import numpy as np


class AudioIOError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class AudioConfig:
    sample_rate: int = 16000
    channels: int = 1
    dtype: str = "float32"
    frame_ms: int = 30
    silence_seconds: float = 0.85
    min_speech_seconds: float = 0.25
    max_record_seconds: float = 30.0
    pre_roll_seconds: float = 0.30
    calibration_seconds: float = 0.35
    start_multiplier: float = 3.0
    stop_multiplier: float = 1.8
    start_floor: float = 0.008
    stop_floor: float = 0.005


class MicrophoneRecorder:
    def __init__(self, config: AudioConfig | None = None):
        self.config = config or AudioConfig()

    @staticmethod
    def _sounddevice():
        try:
            import sounddevice as sd
            return sd
        except ImportError as exc:
            raise AudioIOError("sounddevice is required for microphone input") from exc

    @staticmethod
    def _rms(frame: np.ndarray) -> float:
        if not frame.size:
            return 0.0
        return float(np.sqrt(np.mean(frame * frame, dtype=np.float64)))

    def _noise_floor(self, stream, frame_samples: int) -> float:
        count = max(1, int(self.config.calibration_seconds * 1000 / self.config.frame_ms))
        levels = []
        for _ in range(count):
            frame, _ = stream.read(frame_samples)
            levels.append(self._rms(np.asarray(frame[:, 0], dtype=np.float32)))
        return float(np.percentile(levels, 75)) if levels else 0.0

    def listen_until_silence(
        self,
        output_path: str = "data/audio/user_input.wav",
        status_callback=None,
    ) -> str | None:
        sd = self._sounddevice()
        cfg = self.config
        frame_samples = max(1, int(cfg.sample_rate * cfg.frame_ms / 1000))
        silence_limit = max(1, int(cfg.silence_seconds * 1000 / cfg.frame_ms))
        min_active = max(1, int(cfg.min_speech_seconds * 1000 / cfg.frame_ms))
        max_frames = max(1, int(cfg.max_record_seconds * 1000 / cfg.frame_ms))
        pre_roll = deque(maxlen=max(1, int(cfg.pre_roll_seconds * 1000 / cfg.frame_ms)))

        recorded = []
        speaking = False
        silence_frames = 0
        active_frames = 0

        if status_callback:
            status_callback("listening")

        with sd.InputStream(
            samplerate=cfg.sample_rate,
            channels=cfg.channels,
            dtype=cfg.dtype,
            blocksize=frame_samples,
        ) as stream:
            noise = self._noise_floor(stream, frame_samples)
            start_threshold = max(cfg.start_floor, noise * cfg.start_multiplier)
            stop_threshold = max(cfg.stop_floor, noise * cfg.stop_multiplier)

            for _ in range(max_frames):
                frame, _ = stream.read(frame_samples)
                mono = np.asarray(frame[:, 0], dtype=np.float32)
                level = self._rms(mono)

                if not speaking:
                    pre_roll.append(mono.copy())
                    if level >= start_threshold:
                        speaking = True
                        recorded.extend(pre_roll)
                        pre_roll.clear()
                        recorded.append(mono.copy())
                        active_frames = 1
                        if status_callback:
                            status_callback("speaking")
                    continue

                recorded.append(mono.copy())
                if level >= stop_threshold:
                    active_frames += 1
                    silence_frames = 0
                else:
                    silence_frames += 1

                if silence_frames >= silence_limit:
                    break

        if not speaking or active_frames < min_active:
            if status_callback:
                status_callback("no_speech")
            return None

        audio = np.concatenate(recorded)
        self.write_wav(audio, output_path, cfg.sample_rate)
        if status_callback:
            status_callback("recorded")
        return output_path

    @staticmethod
    def write_wav(audio: np.ndarray, path: str, sample_rate: int):
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        pcm16 = (np.clip(audio, -1.0, 1.0) * 32767.0).astype(np.int16)
        with wave.open(str(destination), "wb") as wav:
            wav.setnchannels(1)
            wav.setsampwidth(2)
            wav.setframerate(sample_rate)
            wav.writeframes(pcm16.tobytes())


class AudioPlayer:
    @staticmethod
    def _sounddevice():
        try:
            import sounddevice as sd
            return sd
        except ImportError as exc:
            raise AudioIOError("sounddevice is required for audio playback") from exc

    @classmethod
    def output_devices(cls) -> list[dict[str, object]]:
        sd = cls._sounddevice()
        devices = []
        for index, device in enumerate(sd.query_devices()):
            if int(device.get("max_output_channels", 0)) <= 0:
                continue
            devices.append(
                {
                    "index": index,
                    "name": str(device.get("name", "")),
                    "channels": int(device.get("max_output_channels", 0)),
                    "default_samplerate": float(device.get("default_samplerate", 0.0)),
                }
            )
        return devices

    @staticmethod
    def _device(value: str | int | None):
        if value is None or value == "":
            return None
        if isinstance(value, int):
            return value
        text = value.strip()
        return int(text) if text.isdigit() else text

    @staticmethod
    def _read_wav(path: str):
        with wave.open(path, "rb") as wav:
            channels = wav.getnchannels()
            sample_rate = wav.getframerate()
            if wav.getsampwidth() != 2:
                raise AudioIOError("Only 16-bit PCM WAV playback is supported")
            raw = wav.readframes(wav.getnframes())

        audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32767.0
        return audio.reshape(-1, channels), sample_rate, channels

    def play_wav(
        self,
        path: str,
        device: str | int | None = None,
        mirror_device: str | int | None = None,
    ):
        sd = self._sounddevice()
        audio, sample_rate, channels = self._read_wav(path)
        primary = self._device(device)
        mirror = self._device(mirror_device)

        if mirror is None or mirror == primary:
            sd.play(audio, samplerate=sample_rate, device=primary)
            sd.wait()
            return

        block = 2048
        with sd.OutputStream(
            samplerate=sample_rate,
            channels=channels,
            dtype="float32",
            device=primary,
        ) as main_stream, sd.OutputStream(
            samplerate=sample_rate,
            channels=channels,
            dtype="float32",
            device=mirror,
        ) as mirror_stream:
            for offset in range(0, len(audio), block):
                chunk = audio[offset:offset + block]
                main_stream.write(chunk)
                mirror_stream.write(chunk)
