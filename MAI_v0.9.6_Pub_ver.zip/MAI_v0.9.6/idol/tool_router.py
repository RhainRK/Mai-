from __future__ import annotations

import re


class ToolRouter:
    def route(self, text: str) -> tuple[str, ...]:
        value = text.casefold()
        names: list[str] = []

        if re.search(r"\b(chess|fen|checkmate|opening|stockfish)\b", value):
            names.append("chess.")

        if re.search(r"\b(teach|learn|lesson|practice|skill)\b", value):
            names.append("learning.")

        if re.search(r"\b(goal|goals|plan this|work on|next step|complete step)\b", value):
            names.append("goals.")

        continuity_explicit = re.search(r"\bremember this for mai\b", value)
        continuity_decision = re.search(
            r"\b(decide|decided|decision|from now on|change direction|changed my mind|settled)\b",
            value,
        )
        continuity_domain = re.search(
            r"\b(mai|music|song|album|visual|artistic|creative|debut|sound|style|concept|"
            r"character|brand|voice|performance|interview|concert)\b",
            value,
        )
        if continuity_explicit or (continuity_decision and continuity_domain):
            names.append("continuity.")

        return tuple(dict.fromkeys(names))

    def needs_tools(self, text: str) -> bool:
        return bool(self.route(text))
