import asyncio
from uuid import uuid4

from config import settings
from .audio_io import AudioConfig, AudioPlayer
from .behavior import BehaviorProfile
from .career import CareerStore
from .context import TurnContextBuilder
from .continuity import ContinuityStore
from .coordinator import TurnCoordinator
from .chess_skill import ChessSkill, ChessUnavailable
from .goals import GoalManager
from .identity import IdentityStore
from .learning import LearningStore
from .llm import LLMError, OllamaBackend, OpenAICompatibleBackend
from .model_selection import require_available, resolve_ollama_model
from .memory import MemoryStore
from .planner import Planner
from .avatar import VNyanAvatarBridge
from .realtime_voice import LiveVoiceSession
from .replies import ReplyGuard
from .realtime import RealtimeSession
from .relationship import RelationshipState
from .state import EmotionalState
from .stt import STTConfig
from .tasks import StepStatus, TaskStore
from .telemetry import TraceJournal
from .tools.audit import ToolAuditLog
from .tools.chess_tools import register_chess_tools
from .tools.continuity_tools import register_continuity_tools
from .tools.goal_tools import register_goal_tools
from .tools.learning_tools import register_learning_tools
from .tools.registry import ToolRegistry
from .tools.runtime import ToolRuntime
from .tool_router import ToolRouter
from .voice import SingingRequest, UnifiedVoice
from .voice_profile import VoiceProfile


class IdolAgent:
    def __init__(self):
        self.identity = IdentityStore(settings.identity_path)
        self.persona = self.identity.persona()
        self.behavior = BehaviorProfile(settings.persona_profile_path)
        self.state = EmotionalState()
        self.goals = GoalManager()
        self.planner = Planner()

        db_path = str(settings.database_path)
        self.memory = MemoryStore(db_path)
        self.continuity = ContinuityStore(
            db_path,
            self.memory.embedder,
            settings.continuity_candidate_limit,
        )
        self.learning = LearningStore(db_path)
        self.tasks = TaskStore(db_path)
        self.career = CareerStore(db_path)
        self.career.seed_identity(self.identity)

        self.relationship = RelationshipState.from_dict(
            self.memory.load_state("relationship")
        )
        creator = self.identity.creator()
        if creator.get("local_operator_is_creator"):
            self.relationship.bind_subject(
                subject_id=str(creator.get("subject_id", "creator:local")),
                display_name=str(creator.get("name", "")),
                role="creator",
            )

        self.tool_router = ToolRouter()
        self.active_model = ""
        self.llm = self._create_llm()
        self.voice = UnifiedVoice(
            VoiceProfile(),
            settings.voice_tts_backend,
            settings.voice_tts_url,
            settings.voice_tts_model,
            settings.request_timeout,
            str(settings.diffsinger_root),
            settings.windows_voice_name,
            settings.windows_voice_rate,
            settings.windows_voice_volume,
            settings.elevenlabs_api_key,
            settings.elevenlabs_voice_id,
            settings.elevenlabs_model,
            settings.elevenlabs_base_url,
            settings.elevenlabs_sample_rate,
            settings.elevenlabs_stability,
            settings.elevenlabs_similarity_boost,
            settings.elevenlabs_style,
            settings.elevenlabs_speed,
            settings.elevenlabs_use_speaker_boost,
        )
        self.audio_player = AudioPlayer()
        self.avatar = VNyanAvatarBridge(
            settings.avatar_enabled,
            settings.avatar_audio_device,
            settings.avatar_vnyan_url,
            settings.avatar_events,
            settings.avatar_timeout,
            settings.avatar_autonomy,
            settings.avatar_idle_min_seconds,
            settings.avatar_idle_max_seconds,
        )

        try:
            self.chess = ChessSkill(
                str(settings.stockfish_path)
                if settings.stockfish_path
                else "",
                settings.chess_engine_time,
            )
        except ChessUnavailable:
            self.chess = None

        self.tool_audit = ToolAuditLog(db_path)
        self.tools = ToolRegistry(self.tool_audit)

        register_learning_tools(self.tools, self.learning)
        register_continuity_tools(self.tools, self.continuity)
        register_goal_tools(self.tools, self.tasks)
        register_chess_tools(self.tools, self.chess)

        self.runtime = ToolRuntime(
            self.llm,
            self.tools,
            settings.max_tool_steps,
        )
        self.reply_guard = ReplyGuard(
            self.llm,
            settings.reply_recovery_attempts,
        )
        self.trace_journal = TraceJournal(
            db_path,
            settings.trace_retention,
        )
        self.context_builder = TurnContextBuilder(
            persona=self.persona,
            state=self.state,
            memory=self.memory,
            relationship=self.relationship,
            goals=self.goals,
            planner=self.planner,
            learning=self.learning,
            tasks=self.tasks,
            tools=self.tools,
            behavior=self.behavior,
            identity=self.identity,
            career=self.career,
            continuity=self.continuity,
            short_term_turns=settings.short_term_turns,
            memory_recall_limit=settings.memory_recall_limit,
            context_data_char_limit=settings.context_data_char_limit,
            input_context_char_limit=settings.input_context_char_limit,
            context_compression_threshold=settings.context_compression_threshold,
        )
        self.coordinator = TurnCoordinator(
            llm=self.llm,
            runtime=self.runtime,
            reply_guard=self.reply_guard,
            tool_router=self.tool_router,
            context_builder=self.context_builder,
            state=self.state,
            relationship=self.relationship,
            memory=self.memory,
            trace_journal=self.trace_journal,
            model_name=self.active_model,
            session_id=settings.session_id,
            memory_consolidation_turns=settings.memory_consolidation_turns,
        )

    def _create_llm(self):
        if settings.llm_backend == "ollama":
            selection = resolve_ollama_model(
                settings.ollama_url,
                settings.ollama_model,
                settings.ollama_preferred_model,
                settings.ollama_fallback_model,
            )
            self.active_model = require_available(selection)
            return OllamaBackend(
                settings.ollama_url,
                self.active_model,
                settings.request_timeout,
                settings.ollama_keep_alive,
                settings.ollama_num_ctx,
                settings.chat_temperature,
                settings.tool_temperature,
                settings.top_p,
                settings.max_output_tokens,
            )

        if settings.llm_backend == "openai_compatible":
            self.active_model = settings.api_model
            return OpenAICompatibleBackend(
                settings.api_base_url,
                settings.api_key,
                settings.api_model,
                settings.request_timeout,
                settings.chat_temperature,
                settings.tool_temperature,
                settings.top_p,
                settings.max_output_tokens,
            )

        raise ValueError(f"Unknown LLM backend: {settings.llm_backend}")

    def _messages_for_model(
        self,
        text: str,
        task_override: str | None = None,
        tool_prefixes: tuple[str, ...] | None = None,
        public_mode: bool = False,
    ) -> list[dict]:
        """Compatibility helper for non-conversation task execution."""
        if tool_prefixes is None and task_override is not None:
            route = tuple(
                dict.fromkeys(
                    f"{name.split('.', 1)[0]}."
                    for name in self.tools.names()
                )
            )
        else:
            route = tuple(tool_prefixes or ())
        retrieved = self.context_builder.retrieve(
            text,
            public_mode=public_mode,
            task_override=task_override,
        )
        prepared = self.context_builder.prepare(
            text,
            route,
            retrieved,
            public_mode=public_mode,
        )
        return prepared.messages

    def respond(self, text: str, public_mode: bool = False) -> str:
        reply = self.coordinator.respond(text, public_mode=public_mode)
        avatar = getattr(self, "avatar", None)
        if not public_mode and avatar is not None:
            avatar.sync_state(self.state.to_dict(), reply)
        return reply

    def interview(self, question: str) -> str:
        """Answer as MAI in a public-safe interview context."""
        return self.coordinator.respond(question, public_mode=True)

    def work(
        self,
        goal_id: str | None = None,
        cycles: int = 1,
    ) -> list[dict]:
        cycles = max(
            1,
            min(cycles, settings.max_work_cycles),
        )

        goal = (
            self.tasks.get(goal_id)
            if goal_id
            else self.tasks.current()
        )
        if goal is None:
            return []

        reports = []

        for _ in range(cycles):
            goal = self.tasks.get(goal["id"])
            if goal["status"] != "active":
                break

            running = next(
                (
                    step
                    for step in goal["steps"]
                    if step["status"] == StepStatus.RUNNING.value
                ),
                None,
            )
            step = running or self.tasks.claim_next(goal["id"])

            if step is None:
                break

            focus = (
                f"Goal {goal['id']}: {goal['title']}\n"
                f"Outcome: {goal['outcome']}\n"
                f"Current step {step['id']}: {step['title']}\n"
                "Advance this step now. Use tools when useful. "
                "Call goals.complete_step only after a concrete result. "
                "If blocked, call goals.fail_step."
            )

            work_messages = self._messages_for_model(
                focus,
                task_override=focus,
            )
            try:
                work_candidate = self.runtime.run(work_messages)
            except LLMError:
                self.reply_guard.note_backend_failure()
                work_candidate = ""
            reply = self.reply_guard.ensure(
                work_messages,
                work_candidate,
            )

            refreshed = self.tasks.step(
                goal["id"],
                step["id"],
            )
            reports.append(
                {
                    "goal_id": goal["id"],
                    "step_id": step["id"],
                    "step": step["title"],
                    "status": refreshed["status"],
                    "reply": reply,
                }
            )

            if refreshed["status"] == StepStatus.RUNNING.value:
                break

        return reports

    def teach(self, skill: str, content: str):
        return self.learning.teach(skill, content)

    def skills(self):
        return self.learning.list_skills()

    def skill(self, name: str):
        return self.learning.skill(name)

    def record_practice(
        self,
        skill: str,
        task: str,
        result: str,
        score: float | None,
        feedback: str = "",
    ):
        return self.learning.record_practice(
            skill,
            task,
            result,
            score,
            feedback,
        )

    def recent_actions(self, limit: int = 30):
        return self.tool_audit.recent(limit)

    def available_tools(self):
        return self.tools.names()

    def state_dict(self):
        return {
            "emotion": self.state.to_dict(),
            "relationship": self.relationship.to_dict(),
        }

    def profile(self):
        return self.memory.get_profile()

    def memories(self):
        return self.memory.recent_memories()

    def identity_info(self):
        return self.identity.summary()

    def creator_info(self):
        return {
            **self.identity.creator(),
            "relationship": self.relationship.to_dict(),
        }

    def canon(self, public_only: bool = False):
        return self.career.canon("public" if public_only else "internal")

    def timeline(self, limit: int = 20, public_only: bool = False):
        return self.career.timeline(limit, "public" if public_only else "internal")

    def record_career_event(
        self,
        event_type: str,
        title: str,
        summary: str,
        **kwargs,
    ):
        return self.career.record_event(event_type, title, summary, **kwargs)


    def continuity_current(self, memory_type: str | None = None, limit: int = 100):
        return self.continuity.current(memory_type, limit=limit)

    def continuity_history(self, key: str, memory_type: str | None = None):
        return self.continuity.history(key, memory_type=memory_type)

    def set_continuity(
        self,
        memory_type: str,
        key: str,
        content: str,
        *,
        reason: str = "",
        visibility: str = "private",
        confidence: float = 0.95,
        importance: float = 0.9,
        source: str = "creator_cli",
    ):
        return self.continuity.set_current(
            memory_type,
            key,
            content,
            reason=reason,
            visibility=visibility,
            confidence=confidence,
            importance=importance,
            source=source,
        )

    def continuity_stats(self):
        return self.continuity.stats()

    def memory_map(self):
        return {
            "working": {"recent_messages": len(self.memory.recent_messages(self.context_builder.short_term_turns))},
            "conversational": self.memory.stats(),
            "continuity": self.continuity.stats(),
            "relationship": self.relationship.to_dict(),
            "career": self.career.stats(),
            "canon": {"facts": len(self.career.canon("internal"))},
        }

    def reset_session(self):
        self.memory.consolidate_session(self.coordinator.session_id, minimum=1)
        self.memory.clear_session()
        self.coordinator.session_id = f'{settings.session_id}:{uuid4().hex}'

    def speak(
        self,
        text: str,
        output_path: str = "data/audio/mai_reply.wav",
    ):
        return self.voice.speak(
            text,
            output_path,
        )

    def voices(self):
        return self.voice.voices()

    def audio_devices(self):
        return self.audio_player.output_devices()

    def play_voice(self, path: str, text: str = ""):
        mirror = (
            settings.avatar_audio_device
            if settings.avatar_enabled and settings.avatar_audio_device
            else None
        )
        self.avatar.speaking_started(text, self.state.to_dict())
        try:
            self.audio_player.play_wav(
                path,
                device=settings.audio_output_device or None,
                mirror_device=mirror,
            )
        finally:
            self.avatar.speaking_finished()

    def avatar_status(self):
        return self.avatar.status()

    def avatar_test(self):
        return self.avatar.test()

    def avatar_idle_test(self):
        return self.avatar.idle_test()

    def avatar_expression(self, name: str, intensity: float = 0.7):
        return self.avatar.expression(name, intensity)

    def avatar_look(self, x: float, y: float, hold_ms: int = 1400):
        return self.avatar.look(x, y, hold_ms)

    def sing_ds(
        self,
        ds_path: str,
        output_dir: str = "data/audio/singing",
        title: str = "mai_render",
    ):
        return self.voice.sing(
            SingingRequest(
                ds_path,
                settings.diffsinger_experiment,
                output_dir,
                title,
            )
        )


    def needs_tools(self, text: str) -> bool:
        return self.tool_router.needs_tools(text)

    def stream_respond(self, text: str):
        chunks = []
        for chunk in self.coordinator.stream_respond(text):
            chunks.append(chunk)
            yield chunk
        avatar = getattr(self, "avatar", None)
        if avatar is not None:
            avatar.sync_state(self.state.to_dict(), "".join(chunks))

    def metrics(self):
        metrics = self.llm.last_metrics.as_dict()
        metrics["reply_reliability"] = self.reply_guard.stats()
        metrics["turn_trace"] = self.coordinator.last_trace_summary()
        return metrics

    def trace(self, trace_id: str | None = None):
        if trace_id:
            return self.trace_journal.get(trace_id)
        if self.coordinator.last_trace is None:
            return None
        return self.coordinator.last_trace.as_dict()

    def traces(self, limit: int = 20):
        return self.trace_journal.recent(limit)

    def trace_stats(self):
        return self.trace_journal.stats()

    def memory_stats(self):
        return self.memory.stats()

    def forget_memory(self, memory_id: int):
        return self.memory.forget_memory(memory_id)

    async def astream_respond(self, text: str, cancel_event):
        chunks = []
        async for chunk in self.coordinator.astream_respond(text, cancel_event):
            chunks.append(chunk)
            yield chunk
        avatar = getattr(self, "avatar", None)
        if avatar is not None and not cancel_event.is_set():
            await asyncio.to_thread(
                avatar.sync_state,
                self.state.to_dict(),
                "".join(chunks),
            )

    def create_realtime_session(self):
        backend = settings.voice_tts_backend
        if backend == "auto":
            backend = (
                "elevenlabs"
                if settings.elevenlabs_api_key and settings.elevenlabs_voice_id
                else "windows"
            )
        if backend not in {"http", "elevenlabs"}:
            raise RuntimeError(
                "Realtime mode needs the ElevenLabs or HTTP streaming TTS backend. "
                "Use /voice-loop for Windows speech."
            )
        return RealtimeSession(self, settings)

    def create_live_voice_session(self):
        return LiveVoiceSession(
            self,
            AudioConfig(
                sample_rate=settings.mic_sample_rate,
                silence_seconds=settings.mic_silence_seconds,
            ),
            STTConfig(
                model_size=settings.stt_model_size,
                device=settings.stt_device,
                compute_type=settings.stt_compute_type,
                language=settings.stt_language,
                beam_size=settings.stt_beam_size,
            ),
        )

    def close(self):
        self.memory.consolidate_session(self.coordinator.session_id, minimum=1)
        self.memory.save_state(
            "relationship",
            self.relationship.to_dict(),
        )
        if self.chess:
            self.chess.close()
        self.trace_journal.close()
        self.tool_audit.close()
        self.tasks.close()
        self.learning.close()
        self.career.close()
        self.continuity.close()
        self.memory.close()
        self.llm.close()
        self.voice.close()
        self.avatar.close()
