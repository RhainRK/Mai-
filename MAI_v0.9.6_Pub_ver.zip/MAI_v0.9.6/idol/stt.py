from dataclasses import dataclass
from pathlib import Path


class SpeechRecognitionError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class STTConfig:
    model_size: str = "base.en"
    device: str = "cpu"
    compute_type: str = "int8"
    language: str | None = "en"
    beam_size: int = 3


class FasterWhisperSTT:
    def __init__(self, config: STTConfig | None = None):
        self.config = config or STTConfig()
        self._model = None
        self.runtime = None

    def _resolve(self):
        device = self.config.device
        if device == "auto":
            try:
                import ctranslate2
                device = "cuda" if ctranslate2.get_cuda_device_count() else "cpu"
            except Exception:
                device = "cpu"
        model = self.config.model_size
        if model == "auto":
            model = "turbo" if device == "cuda" else "base.en"
        compute_type = self.config.compute_type
        if compute_type == "auto":
            compute_type = "float16" if device == "cuda" else "int8"
        return model, device, compute_type

    def _load(self):
        if self._model is not None:
            return
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise SpeechRecognitionError("Install voice support first") from exc
        model, device, compute_type = self._resolve()
        try:
            self._model = WhisperModel(model, device=device, compute_type=compute_type)
            self.runtime = (model, device, compute_type)
        except Exception as exc:
            if self.config.device == "auto" and device == "cuda":
                try:
                    self._model = WhisperModel(model, device="cpu", compute_type="int8")
                    self.runtime = (model, "cpu", "int8")
                    return
                except Exception:
                    pass
            raise SpeechRecognitionError(f"Whisper failed to load: {exc}") from exc

    def transcribe(self, audio_path: str) -> str:
        if not Path(audio_path).exists():
            raise SpeechRecognitionError(f"Audio file not found: {audio_path}")
        self._load()
        segments, _ = self._model.transcribe(
            audio_path,
            language=self.config.language,
            beam_size=self.config.beam_size,
            vad_filter=True,
            vad_parameters={"min_silence_duration_ms": 450},
            condition_on_previous_text=False,
        )
        return " ".join(
            segment.text.strip() for segment in segments if segment.text.strip()
        ).strip()
