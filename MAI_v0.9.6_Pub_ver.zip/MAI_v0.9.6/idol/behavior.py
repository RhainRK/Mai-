from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any


class BehaviorProfileError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class BehaviorMode:
    name: str
    energy: float
    directness: float
    playfulness: float
    warmth: float
    vulnerability: float
    playful_charm: float
    star_presence: float


class BehaviorProfile:
    def __init__(self, profile_path: str | Path):
        self.path = Path(profile_path)
        try:
            self.data = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise BehaviorProfileError(f"Behavior profile not found: {self.path}") from exc
        except json.JSONDecodeError as exc:
            raise BehaviorProfileError(
                f"Behavior profile is invalid JSON: {self.path}: {exc}"
            ) from exc
        self._validate(self.data)

    @staticmethod
    def _validate(data: dict[str, Any]) -> None:
        if not isinstance(data, dict):
            raise BehaviorProfileError("Behavior profile root must be an object")
        for key in ("expression", "mannerisms", "defaults", "avoid"):
            if key not in data:
                raise BehaviorProfileError(f"Behavior profile is missing: {key}")
        expression = data["expression"]
        if not isinstance(expression, dict):
            raise BehaviorProfileError("behavior.expression must be an object")
        for key in ("playfulness", "warmth"):
            if key not in expression:
                raise BehaviorProfileError(f"behavior.expression is missing: {key}")
        required_modes = {
            "relaxed", "focused", "performance", "creative",
            "vulnerable", "fan_facing", "interview",
        }
        mannerisms = data["mannerisms"]
        if not isinstance(mannerisms, dict):
            raise BehaviorProfileError("behavior.mannerisms must be an object")
        missing_modes = sorted(required_modes - set(mannerisms))
        if missing_modes:
            raise BehaviorProfileError(
                f"Behavior profile is missing modes: {', '.join(missing_modes)}"
            )

    def mode(self, text: str, state) -> BehaviorMode:
        lowered = text.casefold()

        # Mode priority
        if any(word in lowered for word in ("problem", "urgent", "fix", "debug", "analyse", "analyze")):
            name = "focused"
        elif any(word in lowered for word in ("sad", "worried", "failed", "failure", "hurt", "scared")):
            name = "vulnerable"
        elif any(word in lowered for word in ("interview", "press", "journalist", "media", "red carpet")):
            name = "interview"
        elif any(word in lowered for word in ("fan", "fandom", "idol", "autograph", "meet and greet", "bias", "stan")):
            name = "fan_facing"
        elif any(word in lowered for word in ("stage", "perform", "dance", "concert", "rehearsal")):
            name = "performance"
        elif any(word in lowered for word in ("song", "music", "visual", "fashion", "concept", "write", "chorus", "melody")):
            name = "creative"
        else:
            name = "relaxed"

        base = self.data["expression"]
        modifiers = {
            "relaxed": (0.72, 0.60, 0.88, 0.88, 0.48, 0.86, 0.68),
            "focused": (0.64, 0.90, 0.18, 0.66, 0.28, 0.22, 0.54),
            "performance": (0.97, 0.86, 0.68, 0.74, 0.22, 0.84, 0.98),
            "creative": (0.85, 0.78, 0.76, 0.80, 0.40, 0.72, 0.82),
            "vulnerable": (0.48, 0.70, 0.12, 0.92, 0.78, 0.18, 0.40),
            "fan_facing": (0.86, 0.68, 0.92, 0.94, 0.32, 0.94, 0.88),
            "interview": (0.76, 0.82, 0.62, 0.84, 0.42, 0.68, 0.88),
        }
        energy, directness, playfulness, warmth, vulnerability, charm, star_presence = modifiers[name]

        energy = (energy + state.energy) / 2
        playfulness = (playfulness + state.playfulness + base["playfulness"]) / 3
        warmth = (warmth + base["warmth"]) / 2
        charm = (charm + base.get("playful_charm", 0.75)) / 2
        star_presence = (star_presence + base.get("stage_magnetism", 0.75)) / 2

        return BehaviorMode(
            name=name,
            energy=round(energy, 3),
            directness=round(directness, 3),
            playfulness=round(playfulness, 3),
            warmth=round(warmth, 3),
            vulnerability=round(vulnerability, 3),
            playful_charm=round(charm, 3),
            star_presence=round(star_presence, 3),
        )

    def _social_register(self, relationship) -> tuple[str, list[str]]:
        registers = self.data.get("social_registers", {})
        if not isinstance(registers, dict) or not registers:
            return "", []

        if relationship is not None and getattr(relationship, "is_creator", False):
            name = "creator_close"
        else:
            familiarity = float(getattr(relationship, "familiarity", 0.0) or 0.0)
            if familiarity >= 0.75:
                name = "close_familiar"
            elif familiarity >= 0.30:
                name = "friendly_familiar"
            else:
                name = "new_acquaintance"

        rules = registers.get(name, [])
        return name, list(rules) if isinstance(rules, list) else []

    def _prompt(self, text: str, state, relationship=None) -> str:
        mode = self.mode(text, state)
        mannerisms = self.data["mannerisms"][mode.name]
        defaults = self.data["defaults"]
        avoid = self.data["avoid"]
        big_five = self.data.get("big_five", {})
        expression = self.data.get("expression", {})
        design_note = str(self.data.get("design_note", "")).strip()
        register_name, register_rules = self._social_register(relationship)

        lines = [
            f"mode={mode.name}",
            (
                f"energy={mode.energy:.2f}, directness={mode.directness:.2f}, "
                f"playfulness={mode.playfulness:.2f}, warmth={mode.warmth:.2f}, "
                f"vulnerability={mode.vulnerability:.2f}, playful_charm={mode.playful_charm:.2f}, "
                f"star_presence={mode.star_presence:.2f}"
            ),
        ]
        if isinstance(big_five, dict) and big_five:
            lines.append(
                "big_five: " + ", ".join(f"{key}={value}" for key, value in big_five.items())
            )
        if isinstance(expression, dict) and expression:
            lines.append(
                "expression: " + ", ".join(f"{key}={value}" for key, value in expression.items())
            )
        if design_note:
            lines.append(f"design_note: {design_note}")
        lines.append(f"mannerisms: {'; '.join(mannerisms)}")
        lines.append(
            f"defaults: {', '.join(f'{key}={value}' for key, value in defaults.items())}"
        )
        if register_rules:
            lines.append(f"social_register={register_name}: {'; '.join(register_rules)}")
        lines.append(f"avoid: {'; '.join(avoid)}")
        return "\n".join(lines)

    def prompt(self, text: str, state) -> str:
        return self._prompt(text, state)

    def prompt_for_relationship(self, text: str, state, relationship) -> str:
        return self._prompt(text, state, relationship)
