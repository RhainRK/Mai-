from __future__ import annotations

import base64
from dataclasses import dataclass
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import wave

import httpx

from .voice_profile import VoiceProfile
from .elevenlabs_voice import ElevenLabsSpeechEngine


class VoiceError(RuntimeError):
    pass


class WindowsSpeechEngine:
    def __init__(
        self,
        profile: VoiceProfile,
        voice_name: str = "",
        rate: int = 1,
        volume: int = 100,
        timeout: float = 60.0,
    ):
        self.profile = profile
        self.voice_name = voice_name.strip()
        self.rate = max(-10, min(10, int(rate)))
        self.volume = max(0, min(100, int(volume)))
        self.timeout = max(1.0, float(timeout))

    @staticmethod
    def _encoded(script: str) -> str:
        return base64.b64encode(script.encode("utf-16le")).decode("ascii")

    @staticmethod
    def _ps_string(value: str) -> str:
        return "'" + value.replace("'", "''") + "'"

    def _script(self, text: str, destination: Path) -> str:
        text64 = base64.b64encode(text.encode("utf-8")).decode("ascii")
        path = self._ps_string(str(destination.resolve()))
        voice = self._ps_string(self.voice_name)
        return f"""
Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {{
    $name = {voice}
    if ($name.Length -gt 0) {{
        $s.SelectVoice($name)
    }} else {{
        try {{
            $s.SelectVoiceByHints(
                [System.Speech.Synthesis.VoiceGender]::Female,
                [System.Speech.Synthesis.VoiceAge]::Adult
            )
        }} catch {{}}
    }}
    $s.Rate = {self.rate}
    $s.Volume = {self.volume}
    $s.SetOutputToWaveFile({path})
    $text = [System.Text.Encoding]::UTF8.GetString(
        [System.Convert]::FromBase64String('{text64}')
    )
    $s.Speak($text)
}} finally {{
    $s.Dispose()
}}
""".strip()

    def synthesize(self, text: str, output_path: str) -> str:
        if platform.system() != "Windows":
            raise VoiceError("Windows speech output requires Windows")
        destination = Path(output_path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        script = self._script(text, destination)
        try:
            result = subprocess.run(
                [
                    "powershell.exe",
                    "-NoProfile",
                    "-NonInteractive",
                    "-EncodedCommand",
                    self._encoded(script),
                ],
                capture_output=True,
                text=True,
                check=False,
                timeout=self.timeout,
            )
        except subprocess.TimeoutExpired as exc:
            raise VoiceError(
                f"Windows speech synthesis timed out after {self.timeout:.0f}s"
            ) from exc
        if result.returncode:
            message = (result.stderr or result.stdout).strip()
            raise VoiceError(message[-1200:] or "Windows speech synthesis failed")
        if not destination.exists() or destination.stat().st_size < 44:
            raise VoiceError("Windows speech synthesis produced no audio")
        return str(destination)

    @classmethod
    def voices(cls) -> list[str]:
        if platform.system() != "Windows":
            return []
        script = """
Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {
    $s.GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name }
} finally {
    $s.Dispose()
}
""".strip()
        try:
            result = subprocess.run(
                [
                    "powershell.exe",
                    "-NoProfile",
                    "-NonInteractive",
                    "-EncodedCommand",
                    cls._encoded(script),
                ],
                capture_output=True,
                text=True,
                check=False,
                timeout=30.0,
            )
        except (subprocess.TimeoutExpired, OSError):
            return []
        if result.returncode:
            return []
        return [line.strip() for line in result.stdout.splitlines() if line.strip()]

    def close(self):
        return None


class HttpSpeechEngine:
    def __init__(self, profile: VoiceProfile, base_url: str, model: str, timeout: float):
        self.profile = profile
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout
        self.session = httpx.Client(timeout=self.timeout)

    def synthesize(self, text: str, output_path: str) -> str:
        destination = Path(output_path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "model": self.model,
            "input": text,
            "voice": self.profile.tts_voice_name,
            "response_format": "wav",
            "speed": self.profile.speech_speed,
        }
        temp_path: Path | None = None
        try:
            with self.session.stream(
                "POST",
                f"{self.base_url}/audio/speech",
                json=payload,
            ) as response:
                response.raise_for_status()
                with tempfile.NamedTemporaryFile(
                    dir=destination.parent,
                    suffix=".wav",
                    delete=False,
                ) as handle:
                    temp_path = Path(handle.name)
                    for chunk in response.iter_bytes(chunk_size=64 * 1024):
                        if chunk:
                            handle.write(chunk)

            if temp_path.stat().st_size < 44:
                raise VoiceError("TTS returned an invalid WAV file")
            try:
                with wave.open(str(temp_path), "rb") as wav_file:
                    if wav_file.getsampwidth() != 2:
                        raise VoiceError("TTS WAV must use 16-bit PCM audio")
                    if wav_file.getnchannels() < 1 or wav_file.getframerate() <= 0:
                        raise VoiceError("TTS returned an invalid WAV format")
            except wave.Error as exc:
                raise VoiceError("TTS returned an invalid WAV file") from exc
            temp_path.replace(destination)
            temp_path = None
            return str(destination)
        except httpx.HTTPError as exc:
            raise VoiceError(f"TTS request failed: {exc}") from exc
        finally:
            if temp_path is not None:
                temp_path.unlink(missing_ok=True)

    def close(self):
        self.session.close()


@dataclass(frozen=True, slots=True)
class SingingRequest:
    ds_path: str
    experiment: str
    output_dir: str = "data/audio/singing"
    title: str = "mai_render"


class SingingEngine:
    def __init__(self, root: str):
        self.root = Path(root)

    def synthesize(self, request: SingingRequest) -> str:
        ds_path = Path(request.ds_path).resolve()
        output_dir = Path(request.output_dir).resolve()
        output_dir.mkdir(parents=True, exist_ok=True)
        if not self.root.exists():
            raise VoiceError(f"DiffSinger directory not found: {self.root}")
        if not ds_path.exists():
            raise VoiceError(f"DS file not found: {ds_path}")
        result = subprocess.run(
            [
                sys.executable,
                "main.py",
                str(ds_path),
                "--exp",
                request.experiment,
                "--out",
                str(output_dir),
                "--title",
                request.title,
            ],
            cwd=self.root,
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode:
            raise VoiceError((result.stderr or result.stdout)[-1200:])
        candidates = sorted(
            output_dir.glob(f"{request.title}*.wav"),
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
        if not candidates:
            raise VoiceError("DiffSinger produced no WAV output")
        return str(candidates[0])


class UnifiedVoice:
    def __init__(
        self,
        profile: VoiceProfile,
        backend: str,
        tts_url: str,
        tts_model: str,
        timeout: float,
        diffsinger_root: str,
        windows_voice_name: str = "",
        windows_rate: int = 1,
        windows_volume: int = 100,
        elevenlabs_api_key: str = "",
        elevenlabs_voice_id: str = "",
        elevenlabs_model: str = "eleven_v3_conversational",
        elevenlabs_base_url: str = "https://api.elevenlabs.io/v1",
        elevenlabs_sample_rate: int = 24000,
        elevenlabs_stability: float = 0.55,
        elevenlabs_similarity_boost: float = 0.80,
        elevenlabs_style: float = 0.18,
        elevenlabs_speed: float = 1.0,
        elevenlabs_use_speaker_boost: bool = True,
    ):
        self.profile = profile
        self.profile.save()
        if backend == "auto":
            backend = "elevenlabs" if elevenlabs_api_key.strip() and elevenlabs_voice_id.strip() else "windows"
        if backend == "windows":
            self.speech = WindowsSpeechEngine(
                profile,
                windows_voice_name,
                windows_rate,
                windows_volume,
                timeout,
            )
        elif backend == "http":
            self.speech = HttpSpeechEngine(profile, tts_url, tts_model, timeout)
        elif backend == "elevenlabs":
            self.speech = ElevenLabsSpeechEngine(
                elevenlabs_api_key,
                elevenlabs_voice_id,
                elevenlabs_model,
                elevenlabs_base_url,
                elevenlabs_sample_rate,
                elevenlabs_stability,
                elevenlabs_similarity_boost,
                elevenlabs_style,
                elevenlabs_speed,
                elevenlabs_use_speaker_boost,
                timeout,
            )
        else:
            raise VoiceError(f"Unknown TTS backend: {backend}")
        self.singing = SingingEngine(diffsinger_root)

    def speak(self, text: str, output_path: str) -> str:
        return self.speech.synthesize(text, output_path)

    def voices(self) -> list[str]:
        if isinstance(self.speech, WindowsSpeechEngine):
            return self.speech.voices()
        if isinstance(self.speech, ElevenLabsSpeechEngine):
            return [f"MAI / ElevenLabs ({self.speech.voice_id})"]
        return [self.profile.tts_voice_name]

    def sing(self, request: SingingRequest) -> str:
        return self.singing.synthesize(request)

    def close(self):
        self.speech.close()
