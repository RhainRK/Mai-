from __future__ import annotations

from pathlib import Path


class ChessUnavailable(RuntimeError):
    pass


class ChessSkill:
    def __init__(
        self,
        stockfish_path: str = "",
        engine_time: float = 0.25,
    ):
        try:
            import chess
        except ImportError as exc:
            raise ChessUnavailable(
                "Install python-chess to enable chess"
            ) from exc

        self.chess = chess
        self.board = chess.Board()
        self.stockfish_path = stockfish_path
        self.engine_time = engine_time
        self.engine = None
        self.san_history: list[str] = []

    def engine_available(self) -> bool:
        return bool(
            self.stockfish_path
            and Path(self.stockfish_path).exists()
        )

    def new_game(self) -> dict:
        self.board.reset()
        self.san_history.clear()
        return self.state()

    def reset(self):
        self.new_game()

    def board_text(self) -> str:
        return str(self.board)

    def fen(self) -> str:
        return self.board.fen()

    def _turn_name(self) -> str:
        return "white" if self.board.turn == self.chess.WHITE else "black"

    def _result_text(self) -> str | None:
        outcome = self.board.outcome(claim_draw=True)
        if outcome is None:
            return None
        return f"{outcome.result()} ({outcome.termination.name.lower()})"

    def legal_moves_san(self, limit: int = 80) -> list[str]:
        moves = []
        for move in self.board.legal_moves:
            moves.append(self.board.san(move))
            if len(moves) >= limit:
                break
        return moves

    def state(self) -> dict:
        return {
            "board": self.board_text(),
            "fen": self.fen(),
            "turn": self._turn_name(),
            "fullmove_number": self.board.fullmove_number,
            "game_over": self.board.is_game_over(claim_draw=True),
            "result": self._result_text(),
            "legal_moves": self.legal_moves_san(),
            "history": list(self.san_history[-20:]),
        }

    def _parse_move(self, text: str):
        text = text.strip()

        try:
            return self.board.parse_san(text)
        except ValueError:
            pass

        try:
            return self.board.parse_uci(text)
        except ValueError as exc:
            raise ValueError(
                f"Illegal or invalid move in the current position: {text}"
            ) from exc

    def play(self, text: str) -> dict:
        if self.board.is_game_over(claim_draw=True):
            raise ValueError(
                "The current game is already over. Start a new game first."
            )

        move = self._parse_move(text)
        san = self.board.san(move)
        played_by = self._turn_name()
        self.board.push(move)
        self.san_history.append(san)

        return {
            "played_by": played_by,
            "san": san,
            "uci": move.uci(),
            "next_turn": self._turn_name(),
            "game_over": self.board.is_game_over(claim_draw=True),
            "result": self._result_text(),
            "fen": self.fen(),
        }

    def push(self, text: str) -> str:
        return self.play(text)["san"]

    def _engine(self):
        if self.engine is not None:
            return self.engine

        if not self.engine_available():
            raise ChessUnavailable(
                "Set MAI_STOCKFISH_PATH to enable engine analysis"
            )

        import chess.engine

        self.engine = chess.engine.SimpleEngine.popen_uci(
            str(Path(self.stockfish_path))
        )
        return self.engine

    def hint(self) -> dict:
        if self.board.is_game_over(claim_draw=True):
            raise ValueError("The game is over")

        engine = self._engine()
        result = engine.play(
            self.board,
            self.chess.engine.Limit(time=self.engine_time),
        )
        return {
            "san": self.board.san(result.move),
            "uci": result.move.uci(),
        }

    def analyse(self) -> dict:
        if self.board.is_game_over(claim_draw=True):
            return {
                "score_cp": None,
                "line": [],
                "result": self._result_text(),
            }

        engine = self._engine()
        info = engine.analyse(
            self.board,
            self.chess.engine.Limit(time=self.engine_time),
        )

        score = info["score"].pov(
            self.board.turn
        ).score(mate_score=100000)

        temp = self.board.copy()
        line = []
        for move in (info.get("pv") or [])[:8]:
            line.append(temp.san(move))
            temp.push(move)

        return {
            "score_cp": score,
            "line": line,
        }

    def close(self):
        if self.engine is not None:
            self.engine.quit()
            self.engine = None
