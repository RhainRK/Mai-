from __future__ import annotations

from dataclasses import asdict, dataclass
import re
from threading import Lock
from typing import Iterable


_HIDDEN_TAGS = ("think", "analysis", "reasoning")
_OPEN_TAGS = tuple(f"<{name}>" for name in _HIDDEN_TAGS)
_CLOSE_TAGS = tuple(f"</{name}>" for name in _HIDDEN_TAGS)
_HIDDEN_BLOCK_RE = re.compile(
    r"<(think|analysis|reasoning)>.*?</\1>",
    flags=re.IGNORECASE | re.DOTALL,
)
_UNCLOSED_HIDDEN_RE = re.compile(
    r"<(think|analysis|reasoning)>.*$",
    flags=re.IGNORECASE | re.DOTALL,
)


FINAL_REPLY_RECOVERY = {
    "role": "system",
    "content": (
        "Your previous attempt did not produce a visible final reply. "
        "Answer the user's latest message directly now. Output only the final "
        "user-facing answer. Do not output chain-of-thought, scratchpad, analysis, "
        "reasoning tags, tool narration, or an empty response."
    ),
}


DETERMINISTIC_FAILURE_REPLY = (
    "I heard you, but my reply generator failed before I could produce a complete "
    "answer. Please send that message once more."
)


def sanitize_visible_text(text: str | None) -> str:
    """Remove common model-internal reasoning blocks from user-visible text."""
    if not text:
        return ""
    cleaned = _HIDDEN_BLOCK_RE.sub("", str(text))
    cleaned = _UNCLOSED_HIDDEN_RE.sub("", cleaned)
    return cleaned.strip()


def _longest_suffix_prefix(value: str, candidates: tuple[str, ...]) -> int:
    max_len = min(len(value), max(map(len, candidates), default=0) - 1)
    lower = value.casefold()
    for size in range(max_len, 0, -1):
        suffix = lower[-size:]
        if any(candidate.startswith(suffix) for candidate in candidates):
            return size
    return 0


class VisibleTextFilter:
    """Incrementally suppress hidden reasoning tags without breaking streaming."""

    def __init__(self):
        self._buffer = ""
        self._hidden = False

    @staticmethod
    def _first_tag(value: str, tags: tuple[str, ...]) -> tuple[int, str] | None:
        lower = value.casefold()
        matches = []
        for tag in tags:
            index = lower.find(tag)
            if index >= 0:
                matches.append((index, tag))
        if not matches:
            return None
        return min(matches, key=lambda item: item[0])

    def push(self, text: str | None) -> str:
        if not text:
            return ""
        self._buffer += str(text)
        visible: list[str] = []

        while self._buffer:
            if self._hidden:
                found = self._first_tag(self._buffer, _CLOSE_TAGS)
                if found is None:
                    keep = _longest_suffix_prefix(self._buffer, _CLOSE_TAGS)
                    self._buffer = self._buffer[-keep:] if keep else ""
                    break
                index, tag = found
                self._buffer = self._buffer[index + len(tag):]
                self._hidden = False
                continue

            found = self._first_tag(self._buffer, _OPEN_TAGS)
            if found is not None:
                index, tag = found
                if index:
                    visible.append(self._buffer[:index])
                self._buffer = self._buffer[index + len(tag):]
                self._hidden = True
                continue

            keep = _longest_suffix_prefix(self._buffer, _OPEN_TAGS)
            if keep:
                visible.append(self._buffer[:-keep])
                self._buffer = self._buffer[-keep:]
            else:
                visible.append(self._buffer)
                self._buffer = ""
            break

        return "".join(visible)

    def flush(self) -> str:
        if self._hidden:
            self._buffer = ""
            return ""
        tail = self._buffer
        self._buffer = ""
        if tail.casefold() in _OPEN_TAGS or any(
            tag.startswith(tail.casefold()) for tag in _OPEN_TAGS
        ):
            return ""
        return tail


def filter_visible_chunks(chunks: Iterable[str]) -> Iterable[str]:
    parser = VisibleTextFilter()
    for chunk in chunks:
        visible = parser.push(chunk)
        if visible:
            yield visible
    tail = parser.flush()
    if tail:
        yield tail


@dataclass(slots=True)
class ReplyReliabilityStats:
    recovery_attempts: int = 0
    recovered_replies: int = 0
    deterministic_fallbacks: int = 0
    backend_failures: int = 0


class ReplyGuard:
    """Enforces MAI's invariant: accepted turns end with a visible final reply."""

    def __init__(self, llm, recovery_attempts: int = 2):
        self.llm = llm
        self.recovery_attempts = max(1, int(recovery_attempts))
        self._stats = ReplyReliabilityStats()
        self._lock = Lock()

    def _increment(self, field: str):
        with self._lock:
            setattr(self._stats, field, getattr(self._stats, field) + 1)

    def note_backend_failure(self):
        self._increment("backend_failures")

    def ensure(self, messages: list[dict], candidate: str | None) -> str:
        visible = sanitize_visible_text(candidate)
        if visible:
            return visible
        return self.recover(messages)

    def recover(self, messages: list[dict]) -> str:
        recovery_messages = [*messages, FINAL_REPLY_RECOVERY]
        for _ in range(self.recovery_attempts):
            self._increment("recovery_attempts")
            try:
                response = self.llm.generate(recovery_messages, tools=None)
            except RuntimeError:
                self.note_backend_failure()
                continue
            visible = sanitize_visible_text(response.content)
            if visible:
                self._increment("recovered_replies")
                return visible

        self._increment("deterministic_fallbacks")
        return DETERMINISTIC_FAILURE_REPLY

    def stats(self) -> dict:
        with self._lock:
            return asdict(self._stats)
