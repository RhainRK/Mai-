__all__ = ["IdolAgent"]


def __getattr__(name: str):
    if name == "IdolAgent":
        from .agent import IdolAgent

        return IdolAgent
    raise AttributeError(name)
