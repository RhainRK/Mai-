from __future__ import annotations

import hashlib
import re

import numpy as np


class SemanticEmbedder:
    def __init__(self, model_name: str, fallback_dim: int = 256):
        self.model_name = model_name
        self.fallback_dim = fallback_dim
        self._model = None
        self._backend = None
        self.load_error: str | None = None

    @property
    def identity(self) -> str:
        self._load()
        return self.model_name if self._backend == "sentence_transformers" else f"hash-v1-{self.fallback_dim}"

    def _load(self):
        if self._backend is not None:
            return
        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(self.model_name)
            self._backend = "sentence_transformers"
        except Exception as exc:
            self._model = None
            self._backend = "hash"
            self.load_error = f"{type(exc).__name__}: {exc}"

    def encode(self, text: str) -> np.ndarray:
        self._load()
        if self._backend == "sentence_transformers":
            return np.asarray(
                self._model.encode(
                    text,
                    convert_to_numpy=True,
                    normalize_embeddings=True,
                    show_progress_bar=False,
                ),
                dtype=np.float32,
            )
        return self._hash_encode(text)

    def _hash_encode(self, text: str) -> np.ndarray:
        tokens = re.findall(r"[\w']+", text.casefold(), flags=re.UNICODE)
        vector = np.zeros(self.fallback_dim, dtype=np.float32)
        features = tokens + [f"{tokens[i]}::{tokens[i + 1]}" for i in range(len(tokens) - 1)]
        for feature in features:
            digest = hashlib.blake2b(feature.encode(), digest_size=8).digest()
            index = int.from_bytes(digest[:4], "big") % self.fallback_dim
            vector[index] += 1.0 if digest[4] & 1 else -1.0
        norm = float(np.linalg.norm(vector))
        if norm:
            vector /= norm
        return vector
