from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from typing import Any
from uuid import uuid4

from .llm import LLMError
from .replies import DETERMINISTIC_FAILURE_REPLY, sanitize_visible_text
from .telemetry import TraceJournal, TurnTrace


class TurnCoordinator:
    """Conversation turn orchestration boundary."""

    def __init__(
        self,
        *,
        llm,
        runtime,
        reply_guard,
        tool_router,
        context_builder,
        state,
        relationship,
        memory,
        trace_journal: TraceJournal,
        model_name: str,
        session_id: str = "local",
        memory_consolidation_turns: int = 6,
    ):
        self.llm = llm
        self.runtime = runtime
        self.reply_guard = reply_guard
        self.tool_router = tool_router
        self.context_builder = context_builder
        self.state = state
        self.relationship = relationship
        self.memory = memory
        self.trace_journal = trace_journal
        self.model_name = model_name
        self.session_id = f'{session_id}:{uuid4().hex}'
        self.memory_consolidation_turns = max(2, int(memory_consolidation_turns))
        self.last_trace: TurnTrace | None = None

    def _new_trace(self, text: str, public_mode: bool) -> TurnTrace:
        trace = TurnTrace.create(
            "public_interview" if public_mode else "private_chat",
            self.model_name,
            len(text),
        )
        self.last_trace = trace
        self.trace_journal.save(trace)
        return trace

    def _save(self, trace: TurnTrace) -> None:
        self.last_trace = trace
        self.trace_journal.save(trace)

    def _stage_done(
        self,
        trace: TurnTrace,
        status: str = "ok",
        details: dict[str, Any] | None = None,
    ) -> None:
        trace.end_stage(status, details)
        self._save(trace)

    def _observe_tool(self, trace: TurnTrace):
        def observer(call, result) -> None:
            trace.add_tool(call.name, result.success)
            self._save(trace)

        return observer

    def _commit_private_turn(self, text: str, reply: str) -> None:
        self.memory.add_message("user", text)
        self.memory.add_message("assistant", reply)
        self.memory.extract_and_store(text)
        observe = getattr(self.memory, "observe_turn", None)
        consolidate = getattr(self.memory, "consolidate_session", None)
        if callable(observe):
            observe(self.session_id, text, reply)
        if callable(consolidate):
            consolidate(self.session_id, self.memory_consolidation_turns)
        governor = getattr(self.context_builder, "governor", None)
        if governor is not None:
            governor.prune()
        self.memory.save_state("relationship", self.relationship.to_dict())

    def _prepare(self, text: str, public_mode: bool, trace: TurnTrace):
        trace.start_stage("RECEIVE")
        self.state.react_to_user_message(text)
        if not public_mode:
            self.relationship.update(text)
        self._stage_done(trace)

        trace.start_stage("CLASSIFY")
        route = () if public_mode else self.tool_router.route(text)
        trace.route = list(route)
        self._stage_done(
            trace,
            details={
                "tool_assisted": bool(route),
                "public_mode": bool(public_mode),
            },
        )

        trace.start_stage("RETRIEVE")
        retrieved = self.context_builder.retrieve(
            text,
            public_mode=public_mode,
        )
        trace.memory_ids = list(retrieved.memory_ids)
        trace.continuity_ids = list(getattr(retrieved, "continuity_ids", ()))
        trace.canon_keys = list(retrieved.canon_keys)
        trace.career_event_ids = list(retrieved.career_event_ids)
        self._stage_done(
            trace,
            details={
                "memory_count": len(trace.memory_ids),
                "continuity_count": len(trace.continuity_ids),
                "canon_count": len(trace.canon_keys),
                "career_event_count": len(trace.career_event_ids),
            },
        )

        trace.start_stage("PLAN")
        prepared = self.context_builder.prepare(
            text,
            route,
            retrieved,
            public_mode=public_mode,
        )
        trace.plan_strategy = prepared.plan.strategy
        system_chars = len(str(prepared.messages[0].get("content", ""))) if prepared.messages else 0
        recent_chars = (
            sum(len(str(message.get("content", ""))) for message in prepared.messages[1:-1])
            if len(prepared.messages) > 2
            else 0
        )
        self._stage_done(
            trace,
            details={
                "strategy": prepared.plan.strategy,
                "system_prompt_chars": system_chars,
                "recent_context_chars": recent_chars,
                "input_message_count": len(prepared.messages),
                "history_chars_saved": getattr(getattr(getattr(self.context_builder, 'governor', None), 'last_report', None), 'saved_chars', 0),
            },
        )
        return route, prepared

    def _finish(
        self,
        trace: TurnTrace,
        reply: str,
        *,
        error: str | None = None,
    ) -> None:
        visible = bool(reply.strip())
        deterministic_failure = reply.strip() == DETERMINISTIC_FAILURE_REPLY
        trace.finish(
            success=visible and not deterministic_failure,
            response_completed=visible,
            output_chars=len(reply),
            error=error or ("reply_generation_failed" if deterministic_failure else None),
            metrics=self.llm.last_metrics,
        )
        self._save(trace)

    def _fail_trace(self, trace: TurnTrace, exc: Exception) -> None:
        if trace._active_stage is not None:
            trace.end_stage("error", {"exception": type(exc).__name__})
        trace.finish(
            success=False,
            response_completed=False,
            error=f"{type(exc).__name__}: {exc}",
            metrics=self.llm.last_metrics,
        )
        self._save(trace)

    def respond(self, text: str, *, public_mode: bool = False) -> str:
        text = text.strip()
        if not text:
            return ""

        trace = self._new_trace(text, public_mode)
        try:
            route, prepared = self._prepare(text, public_mode, trace)

            trace.start_stage("ACT")
            backend_failed = False
            try:
                if route:
                    candidate = self.runtime.run(
                        prepared.messages,
                        route,
                        observer=self._observe_tool(trace),
                    )
                else:
                    candidate = self.llm.chat(prepared.messages)
            except LLMError:
                self.reply_guard.note_backend_failure()
                backend_failed = True
                candidate = ""
            self._stage_done(
                trace,
                "recovered" if backend_failed else "ok",
                {"backend_failed": backend_failed},
            )

            trace.start_stage("VERIFY")
            reply = self.reply_guard.ensure(prepared.messages, candidate)
            self._stage_done(
                trace,
                details={"visible_reply": bool(reply.strip())},
            )

            trace.start_stage("RESPOND")
            self._stage_done(trace, details={"output_chars": len(reply)})

            trace.start_stage("COMMIT")
            if public_mode:
                self._stage_done(trace, "skipped", {"reason": "public_mode"})
            else:
                self._commit_private_turn(text, reply)
                self._stage_done(trace)

            self._finish(trace, reply)
            return reply
        except Exception as exc:
            self._fail_trace(trace, exc)
            raise

    def stream_respond(self, text: str) -> Iterator[str]:
        text = text.strip()
        if not text:
            return

        trace = self._new_trace(text, False)
        try:
            route, prepared = self._prepare(text, False, trace)
            trace.start_stage("ACT")

            if route:
                backend_failed = False
                try:
                    candidate = self.runtime.run(
                        prepared.messages,
                        route,
                        observer=self._observe_tool(trace),
                    )
                except LLMError:
                    self.reply_guard.note_backend_failure()
                    backend_failed = True
                    candidate = ""
                self._stage_done(
                    trace,
                    "recovered" if backend_failed else "ok",
                    {"backend_failed": backend_failed, "streamed": False},
                )

                trace.start_stage("VERIFY")
                reply = self.reply_guard.ensure(prepared.messages, candidate)
                self._stage_done(trace, details={"visible_reply": bool(reply.strip())})

                trace.start_stage("RESPOND")
                yield reply
                self._stage_done(trace, details={"output_chars": len(reply)})
            else:
                chunks: list[str] = []
                backend_failed = False
                try:
                    for chunk in self.llm.stream_text(prepared.messages):
                        if chunk:
                            chunks.append(chunk)
                            yield chunk
                except LLMError:
                    self.reply_guard.note_backend_failure()
                    backend_failed = True

                partial = sanitize_visible_text("".join(chunks))
                self._stage_done(
                    trace,
                    "recovered" if backend_failed else "ok",
                    {
                        "backend_failed": backend_failed,
                        "streamed": True,
                        "partial_chars": len(partial),
                    },
                )

                trace.start_stage("VERIFY")
                if backend_failed:
                    reply = self.reply_guard.recover(prepared.messages)
                    if partial:
                        yield "\n\n" + reply
                    else:
                        yield reply
                else:
                    reply = self.reply_guard.ensure(prepared.messages, partial)
                    if not partial:
                        yield reply
                self._stage_done(trace, details={"visible_reply": bool(reply.strip())})

                trace.start_stage("RESPOND")
                self._stage_done(trace, details={"output_chars": len(reply)})

            trace.start_stage("COMMIT")
            self._commit_private_turn(text, reply)
            self._stage_done(trace)
            self._finish(
                trace,
                reply,
                error="stream_backend_failed" if backend_failed else None,
            )
        except Exception as exc:
            self._fail_trace(trace, exc)
            raise

    async def astream_respond(self, text: str, cancel_event) -> AsyncIterator[str]:
        text = text.strip()
        if not text:
            return

        trace = self._new_trace(text, False)
        try:
            route, prepared = self._prepare(text, False, trace)
            if cancel_event.is_set():
                trace.finish(
                    success=False,
                    response_completed=False,
                    error="cancelled_before_act",
                    metrics=self.llm.last_metrics,
                )
                self._save(trace)
                return

            trace.start_stage("ACT")
            backend_failed = False

            if route:
                # SQLite thread affinity
                try:
                    candidate = self.runtime.run(
                        prepared.messages,
                        route,
                        observer=self._observe_tool(trace),
                    )
                except LLMError:
                    self.reply_guard.note_backend_failure()
                    backend_failed = True
                    candidate = ""
                self._stage_done(
                    trace,
                    "recovered" if backend_failed else "ok",
                    {"backend_failed": backend_failed, "streamed": False},
                )

                if cancel_event.is_set():
                    trace.finish(
                        success=False,
                        response_completed=False,
                        error="cancelled_after_act",
                        metrics=self.llm.last_metrics,
                    )
                    self._save(trace)
                    return

                trace.start_stage("VERIFY")
                reply = self.reply_guard.ensure(prepared.messages, candidate)
                self._stage_done(trace, details={"visible_reply": bool(reply.strip())})
                trace.start_stage("RESPOND")
                if not cancel_event.is_set():
                    yield reply
                self._stage_done(trace, details={"output_chars": len(reply)})
            else:
                chunks: list[str] = []
                try:
                    async for chunk in self.llm.astream_text(
                        prepared.messages,
                        cancel_event,
                    ):
                        if cancel_event.is_set():
                            trace.end_stage("cancelled")
                            trace.finish(
                                success=False,
                                response_completed=False,
                                error="cancelled_during_stream",
                                metrics=self.llm.last_metrics,
                            )
                            self._save(trace)
                            return
                        if chunk:
                            chunks.append(chunk)
                            yield chunk
                except LLMError:
                    self.reply_guard.note_backend_failure()
                    backend_failed = True

                partial = sanitize_visible_text("".join(chunks))
                self._stage_done(
                    trace,
                    "recovered" if backend_failed else "ok",
                    {
                        "backend_failed": backend_failed,
                        "streamed": True,
                        "partial_chars": len(partial),
                    },
                )

                if cancel_event.is_set():
                    trace.finish(
                        success=False,
                        response_completed=False,
                        error="cancelled_after_stream",
                        metrics=self.llm.last_metrics,
                    )
                    self._save(trace)
                    return

                trace.start_stage("VERIFY")
                if backend_failed:
                    reply = self.reply_guard.recover(prepared.messages)
                    if not cancel_event.is_set():
                        yield ("\n\n" if partial else "") + reply
                else:
                    reply = self.reply_guard.ensure(prepared.messages, partial)
                    if not partial and not cancel_event.is_set():
                        yield reply
                self._stage_done(trace, details={"visible_reply": bool(reply.strip())})
                trace.start_stage("RESPOND")
                self._stage_done(trace, details={"output_chars": len(reply)})

            if cancel_event.is_set():
                trace.finish(
                    success=False,
                    response_completed=False,
                    error="cancelled_before_commit",
                    metrics=self.llm.last_metrics,
                )
                self._save(trace)
                return

            trace.start_stage("COMMIT")
            self._commit_private_turn(text, reply)
            self._stage_done(trace)
            self._finish(
                trace,
                reply,
                error="stream_backend_failed" if backend_failed else None,
            )
        except Exception as exc:
            self._fail_trace(trace, exc)
            raise

    def last_trace_summary(self) -> dict[str, Any] | None:
        return self.last_trace.summary() if self.last_trace else None
