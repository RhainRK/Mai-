from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
import json
from time import perf_counter
from typing import Any
from uuid import uuid4

from .telemetry import TurnMetrics
from .replies import VisibleTextFilter, sanitize_visible_text
from .tools.base import ToolCall, ToolResult


class LLMError(RuntimeError):
    pass


def _parse_tool_arguments(value: Any) -> tuple[dict[str, Any], str | None]:
    """Normalize model tool arguments without letting malformed JSON abort the turn."""
    if value is None or value == "":
        return {}, None
    if isinstance(value, dict):
        return dict(value), None
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            return {}, "Malformed JSON tool arguments; regenerate the tool call with valid JSON."
        if isinstance(parsed, dict):
            return dict(parsed), None
        return {}, "Tool arguments must be a JSON object."
    try:
        return dict(value), None
    except (TypeError, ValueError):
        return {}, "Tool arguments must be a JSON object."


@dataclass(slots=True)
class LLMResponse:
    content: str
    tool_calls: list[ToolCall]
    raw_message: dict[str, Any]


class LLMBackend(ABC):
    def __init__(self):
        self.last_metrics = TurnMetrics()

    @abstractmethod
    def generate(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
    ) -> LLMResponse:
        raise NotImplementedError

    def chat(self, messages: list[dict]) -> str:
        return self.generate(messages).content.strip()

    def stream_text(self, messages: list[dict]):
        yield self.chat(messages)

    async def astream_text(
        self,
        messages: list[dict],
        cancel_event,
    ):
        raise NotImplementedError

    @abstractmethod
    def assistant_tool_message(self, response: LLMResponse) -> dict:
        raise NotImplementedError

    @abstractmethod
    def tool_result_message(
        self,
        call: ToolCall,
        result: ToolResult,
    ) -> dict:
        raise NotImplementedError

    def close(self):
        pass


class OllamaBackend(LLMBackend):
    def __init__(
        self,
        base_url: str,
        model: str,
        timeout: float,
        keep_alive: str,
        num_ctx: int = 0,
        chat_temperature: float = 0.72,
        tool_temperature: float = 0.2,
        top_p: float = 0.9,
        max_output_tokens: int = 512,
    ):
        super().__init__()
        self.base_url = base_url
        self.model = model
        self.timeout = timeout
        self.keep_alive = keep_alive
        self.num_ctx = num_ctx
        self.chat_temperature = chat_temperature
        self.tool_temperature = tool_temperature
        self.top_p = top_p
        self.max_output_tokens = max_output_tokens
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                from ollama import Client
            except ImportError as exc:
                raise LLMError(
                    "Install the ollama package for the Ollama backend"
                ) from exc
            self._client = Client(
                host=self.base_url,
                timeout=self.timeout,
            )
        return self._client

    def _options(self, tools: bool = False) -> dict:
        options = {
            "temperature": self.tool_temperature if tools else self.chat_temperature,
            "top_p": self.top_p,
            "num_predict": self.max_output_tokens,
        }
        if self.num_ctx > 0:
            options["num_ctx"] = self.num_ctx
        return options

    def _update_metrics(self, response, wall_seconds: float):
        prompt = getattr(response, "prompt_eval_count", None)
        output = getattr(response, "eval_count", None)
        duration = getattr(response, "eval_duration", None)
        rate = None
        if output and duration:
            rate = float(output) / (float(duration) / 1_000_000_000)
        self.last_metrics = TurnMetrics(
            model=self.model,
            wall_seconds=wall_seconds,
            prompt_tokens=int(prompt) if prompt is not None else None,
            output_tokens=int(output) if output is not None else None,
            tokens_per_second=rate,
        )

    def generate(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
    ) -> LLMResponse:
        started = perf_counter()
        try:
            kwargs = {
                "model": self.model,
                "messages": messages,
                "stream": False,
                "keep_alive": self.keep_alive,
                "think": False,
                "options": self._options(bool(tools)),
            }
            if tools:
                kwargs["tools"] = tools

            response = self._get_client().chat(**kwargs)
            self._update_metrics(response, perf_counter() - started)
            message = response.message
            calls = []
            for item in message.tool_calls or []:
                function = item.function
                arguments, parse_error = _parse_tool_arguments(function.arguments)
                calls.append(
                    ToolCall(
                        call_id=str(getattr(item, "id", None) or uuid4()),
                        name=function.name,
                        arguments=arguments,
                        parse_error=parse_error,
                    )
                )
            raw = (
                message.model_dump(exclude_none=True)
                if hasattr(message, "model_dump")
                else dict(message)
            )
            return LLMResponse(
                content=sanitize_visible_text(message.content or ""),
                tool_calls=calls,
                raw_message=raw,
            )
        except LLMError:
            raise
        except Exception as exc:
            raise LLMError(f"Ollama request failed: {exc}") from exc

    def stream_text(self, messages: list[dict]):
        started = perf_counter()
        last = None
        try:
            stream = self._get_client().chat(
                model=self.model,
                messages=messages,
                stream=True,
                keep_alive=self.keep_alive,
                think=False,
                options=self._options(False),
            )
            visible_filter = VisibleTextFilter()
            for chunk in stream:
                last = chunk
                text = visible_filter.push(chunk.message.content or "")
                if text:
                    yield text
            tail = visible_filter.flush()
            if tail:
                yield tail
            if last is not None:
                self._update_metrics(last, perf_counter() - started)
        except Exception as exc:
            raise LLMError(f"Ollama stream failed: {exc}") from exc

    async def astream_text(
        self,
        messages: list[dict],
        cancel_event,
    ):
        started = perf_counter()
        client = None
        try:
            try:
                from ollama import AsyncClient
            except ImportError as exc:
                raise LLMError(
                    "Install the ollama package for the Ollama backend"
                ) from exc

            client = AsyncClient(
                host=self.base_url,
                timeout=self.timeout,
            )
            last = None
            stream = await client.chat(
                model=self.model,
                messages=messages,
                stream=True,
                keep_alive=self.keep_alive,
                think=False,
                options=self._options(False),
            )

            visible_filter = VisibleTextFilter()
            async for chunk in stream:
                last = chunk
                if cancel_event.is_set():
                    aclose = getattr(stream, "aclose", None)
                    if aclose is not None:
                        await aclose()
                    return
                text = visible_filter.push(chunk.message.content or "")
                if text:
                    yield text

            tail = visible_filter.flush()
            if tail and not cancel_event.is_set():
                yield tail
            if last is not None:
                self._update_metrics(last, perf_counter() - started)
        except LLMError:
            raise
        except Exception as exc:
            raise LLMError(f"Ollama async stream failed: {exc}") from exc
        finally:
            if client is not None:
                await client.close()

    def close(self):
        if self._client is not None:
            self._client.close()
            self._client = None

    def assistant_tool_message(self, response: LLMResponse) -> dict:
        return response.raw_message

    def tool_result_message(
        self,
        call: ToolCall,
        result: ToolResult,
    ) -> dict:
        return {
            "role": "tool",
            "tool_name": call.name,
            "content": json.dumps(
                result.as_message_payload(),
                ensure_ascii=False,
                default=str,
            ),
        }


class OpenAICompatibleBackend(LLMBackend):
    def __init__(
        self,
        base_url: str,
        api_key: str,
        model: str,
        timeout: float,
        chat_temperature: float = 0.72,
        tool_temperature: float = 0.2,
        top_p: float = 0.9,
        max_output_tokens: int = 512,
    ):
        super().__init__()
        self.base_url = base_url
        self.api_key = api_key or "local"
        self.model = model
        self.timeout = timeout
        self.chat_temperature = chat_temperature
        self.tool_temperature = tool_temperature
        self.top_p = top_p
        self.max_output_tokens = max_output_tokens
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                from openai import OpenAI
            except ImportError as exc:
                raise LLMError(
                    "Install the openai package for this backend"
                ) from exc
            self._client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
                timeout=self.timeout,
            )
        return self._client

    def generate(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
    ) -> LLMResponse:
        kwargs = {
            "model": self.model,
            "messages": messages,
            "temperature": self.tool_temperature if tools else self.chat_temperature,
            "top_p": self.top_p,
            "max_tokens": self.max_output_tokens,
        }
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"

        started = perf_counter()
        try:
            response = self._get_client().chat.completions.create(**kwargs)
            message = response.choices[0].message
            usage = getattr(response, "usage", None)
            output = getattr(usage, "completion_tokens", None) if usage else None
            prompt = getattr(usage, "prompt_tokens", None) if usage else None
            self.last_metrics = TurnMetrics(
                model=self.model,
                wall_seconds=perf_counter() - started,
                prompt_tokens=prompt,
                output_tokens=output,
            )
            calls = []
            for item in message.tool_calls or []:
                arguments, parse_error = _parse_tool_arguments(item.function.arguments)
                calls.append(
                    ToolCall(
                        call_id=item.id,
                        name=item.function.name,
                        arguments=arguments,
                        parse_error=parse_error,
                    )
                )
            return LLMResponse(
                content=sanitize_visible_text(message.content or ""),
                tool_calls=calls,
                raw_message=message.model_dump(exclude_none=True),
            )
        except LLMError:
            raise
        except Exception as exc:
            raise LLMError(f"LLM request failed: {exc}") from exc

    def stream_text(self, messages: list[dict]):
        started = perf_counter()
        try:
            stream = self._get_client().chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.chat_temperature,
                top_p=self.top_p,
                max_tokens=self.max_output_tokens,
                stream=True,
            )
            visible_filter = VisibleTextFilter()
            for chunk in stream:
                delta = chunk.choices[0].delta
                text = visible_filter.push(delta.content or "")
                if text:
                    yield text
            tail = visible_filter.flush()
            if tail:
                yield tail
            self.last_metrics = TurnMetrics(
                model=self.model,
                wall_seconds=perf_counter() - started,
            )
        except Exception as exc:
            raise LLMError(f"LLM stream failed: {exc}") from exc

    async def astream_text(
        self,
        messages: list[dict],
        cancel_event,
    ):
        started = perf_counter()
        client = None
        try:
            try:
                from openai import AsyncOpenAI
            except ImportError as exc:
                raise LLMError(
                    "Install the openai package for this backend"
                ) from exc

            client = AsyncOpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
                timeout=self.timeout,
            )
            stream = await client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.chat_temperature,
                top_p=self.top_p,
                max_tokens=self.max_output_tokens,
                stream=True,
            )

            visible_filter = VisibleTextFilter()
            async for chunk in stream:
                if cancel_event.is_set():
                    await stream.close()
                    return
                delta = chunk.choices[0].delta
                text = visible_filter.push(delta.content or "")
                if text:
                    yield text

            tail = visible_filter.flush()
            if tail and not cancel_event.is_set():
                yield tail
            self.last_metrics = TurnMetrics(
                model=self.model,
                wall_seconds=perf_counter() - started,
            )
        except LLMError:
            raise
        except Exception as exc:
            raise LLMError(f"LLM async stream failed: {exc}") from exc
        finally:
            if client is not None:
                await client.close()

    def close(self):
        if self._client is not None:
            self._client.close()
            self._client = None

    def assistant_tool_message(self, response: LLMResponse) -> dict:
        return response.raw_message

    def tool_result_message(
        self,
        call: ToolCall,
        result: ToolResult,
    ) -> dict:
        return {
            "role": "tool",
            "tool_call_id": call.call_id,
            "content": json.dumps(
                result.as_message_payload(),
                ensure_ascii=False,
                default=str,
            ),
        }
