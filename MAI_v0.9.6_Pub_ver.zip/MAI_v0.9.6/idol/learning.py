from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import re
import sqlite3

from .database import close_database, connect_database


@dataclass(frozen=True, slots=True)
class Lesson:
    skill: str
    content: str
    confidence: float = 0.9


class LearningStore:
    def __init__(self, db_path: str):
        self.conn = connect_database(db_path, timeout=5.0)
        self._setup()

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def _setup(self):
        with self.conn:
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS skills (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    mastery REAL NOT NULL DEFAULT 0.0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS lessons (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    skill_id INTEGER NOT NULL,
                    content TEXT NOT NULL,
                    confidence REAL NOT NULL DEFAULT 0.9,
                    created_at TEXT NOT NULL,
                    UNIQUE(skill_id, content),
                    FOREIGN KEY(skill_id) REFERENCES skills(id)
                );
                CREATE TABLE IF NOT EXISTS practice (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    skill_id INTEGER NOT NULL,
                    task TEXT NOT NULL,
                    result TEXT NOT NULL,
                    score REAL,
                    feedback TEXT,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(skill_id) REFERENCES skills(id)
                );
                """
            )

    def _skill_id(self, name: str) -> int:
        name = name.strip().casefold()
        now = self._now()
        with self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO skills(name, mastery, created_at, updated_at) VALUES (?, 0, ?, ?)",
                (name, now, now),
            )
        row = self.conn.execute(
            "SELECT id FROM skills WHERE name=? COLLATE NOCASE",
            (name,),
        ).fetchone()
        return int(row["id"])

    def teach(self, skill: str, content: str, confidence: float = 0.9) -> Lesson:
        skill = skill.strip().casefold()
        content = content.strip()
        if not skill or not content:
            raise ValueError("Skill and lesson are required")
        skill_id = self._skill_id(skill)
        with self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO lessons(skill_id, content, confidence, created_at) VALUES (?, ?, ?, ?)",
                (skill_id, content, confidence, self._now()),
            )
            self.conn.execute(
                "UPDATE skills SET updated_at=? WHERE id=?",
                (self._now(), skill_id),
            )
        return Lesson(skill, content, confidence)

    def record_practice(
        self,
        skill: str,
        task: str,
        result: str,
        score: float | None,
        feedback: str = "",
    ):
        skill_id = self._skill_id(skill)
        with self.conn:
            self.conn.execute(
                "INSERT INTO practice(skill_id, task, result, score, feedback, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (skill_id, task, result, score, feedback, self._now()),
            )
            if score is not None:
                old = float(
                    self.conn.execute(
                        "SELECT mastery FROM skills WHERE id=?",
                        (skill_id,),
                    ).fetchone()["mastery"]
                )
                mastery = max(0.0, min(1.0, old * 0.85 + score * 0.15))
                self.conn.execute(
                    "UPDATE skills SET mastery=?, updated_at=? WHERE id=?",
                    (mastery, self._now(), skill_id),
                )

    def list_skills(self) -> list[dict]:
        rows = self.conn.execute(
            "SELECT name, mastery, updated_at FROM skills ORDER BY mastery DESC, name"
        ).fetchall()
        return [dict(row) for row in rows]

    def skill(self, name: str) -> dict | None:
        row = self.conn.execute(
            "SELECT id, name, mastery, updated_at FROM skills WHERE name=? COLLATE NOCASE",
            (name.strip(),),
        ).fetchone()
        if row is None:
            return None
        lessons = self.conn.execute(
            "SELECT content, confidence, created_at FROM lessons WHERE skill_id=? ORDER BY id DESC LIMIT 30",
            (row["id"],),
        ).fetchall()
        practice = self.conn.execute(
            "SELECT task, result, score, feedback, created_at FROM practice WHERE skill_id=? ORDER BY id DESC LIMIT 10",
            (row["id"],),
        ).fetchall()
        return {
            "name": row["name"],
            "mastery": float(row["mastery"]),
            "updated_at": row["updated_at"],
            "lessons": [dict(item) for item in lessons],
            "practice": [dict(item) for item in practice],
        }

    def context(self, query: str, limit: int = 8) -> str:
        tokens = {x for x in re.findall(r"[\w']+", query.casefold()) if len(x) > 2}
        rows = self.conn.execute(
            """
            SELECT s.name, s.mastery, l.content, l.confidence
            FROM lessons l
            JOIN skills s ON s.id=l.skill_id
            ORDER BY l.id DESC
            LIMIT 300
            """
        ).fetchall()
        ranked = []
        for row in rows:
            text = f"{row['name']} {row['content']}".casefold()
            overlap = sum(token in text for token in tokens)
            if overlap or row["name"].casefold() in query.casefold():
                ranked.append((overlap + float(row["confidence"]), row))
        ranked.sort(key=lambda item: item[0], reverse=True)
        if not ranked:
            return "None."
        return "\n".join(
            f"- {row['name']} (mastery {float(row['mastery']):.2f}): {row['content']}"
            for _, row in ranked[:limit]
        )

    def parse_teaching(self, text: str) -> Lesson | None:
        for pattern in (
            r"\bteach you ([^:]{2,50}):\s*(.+)",
            r"\blearn this for ([^:]{2,50}):\s*(.+)",
            r"\bfor ([^:]{2,50}), remember this:\s*(.+)",
        ):
            match = re.search(pattern, text, flags=re.IGNORECASE)
            if match:
                return Lesson(match.group(1).strip(), match.group(2).strip())
        return None

    def close(self):
        close_database(self.conn)
