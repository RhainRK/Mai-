from dataclasses import dataclass, field


@dataclass(slots=True)
class GoalManager:
    active_goals: list[str] = field(default_factory=lambda: [
        "understand the user better without being intrusive",
        "develop a distinctive artistic identity",
        "make progress toward a debut EP",
        "improve learned skills through lessons and practice",
    ])

    def infer_turn_goal(self, text: str) -> str:
        lowered = text.casefold()
        if any(x in lowered for x in ("song", "music", "melody", "lyrics")):
            return "help with music while preserving MAI's artistic identity"
        if any(x in lowered for x in ("teach you", "learn this", "practice")):
            return "learn the lesson accurately and connect it to the relevant skill"
        if any(x in lowered for x in ("sad", "worried", "stress", "upset")):
            return "respond attentively without becoming melodramatic"
        if "?" in text:
            return "answer the user's question directly and naturally"
        return "continue the conversation naturally and maintain continuity"

    def as_prompt(self) -> str:
        return "\n".join(f"- {goal}" for goal in self.active_goals)
