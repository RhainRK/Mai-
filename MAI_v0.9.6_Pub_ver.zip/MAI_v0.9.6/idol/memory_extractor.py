from __future__ import annotations

import re


class StructuredMemoryExtractor:
    def extract(self, text: str) -> dict:
        profile = []
        memories = []

        patterns = [
            (r"\bmy name is ([A-Za-z][A-Za-z\-']{1,40})\b", "name", 0.95),
            (r"\bi study ([^.!,]{2,100})", "studies", 0.82),
            (r"\bi(?:'m| am) studying ([^.!,]{2,100})", "studies", 0.82),
            (r"\bi like ([^.!,]{2,140})", "likes", 0.72),
            (r"\bi love ([^.!,]{2,140})", "likes", 0.78),
            (r"\bi dislike ([^.!,]{2,140})", "dislikes", 0.72),
            (r"\bi hate ([^.!,]{2,140})", "dislikes", 0.78),
        ]

        for pattern, key, confidence in patterns:
            match = re.search(pattern, text, flags=re.IGNORECASE)
            if match:
                profile.append(
                    {
                        "key": key,
                        "value": match.group(1).strip(),
                        "confidence": confidence,
                    }
                )

        explicit = re.search(
            r"\bremember(?: that)? (.+)",
            text,
            flags=re.IGNORECASE,
        )
        if explicit:
            memories.append(
                {
                    "kind": "explicit",
                    "content": explicit.group(1).strip(),
                    "importance": 0.95,
                }
            )

        goal = re.search(
            r"\b(?:my goal is to|i plan to) ([^.?!]{4,180})",
            text,
            flags=re.IGNORECASE,
        )
        if goal:
            memories.append(
                {
                    "kind": "user_goal",
                    "content": goal.group(1).strip(),
                    "importance": 0.82,
                }
            )

        return {
            "profile": profile,
            "memories": memories,
        }
