from __future__ import annotations

import httpx


class StreamingTTS:
    def __init__(
        self,
        base_url: str,
        model: str,
        voice: str,
        sample_rate: int = 24000,
        timeout: float = 180.0,
    ):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.voice = voice
        self.sample_rate = sample_rate
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(timeout, connect=10.0),
        )

    async def stream(self, text: str, cancel_event):
        payload = {
            "model": self.model,
            "input": text,
            "voice": self.voice,
            "response_format": "pcm",
            "stream": True,
        }

        async with self.client.stream(
            "POST",
            f"{self.base_url}/audio/speech",
            json=payload,
        ) as response:
            response.raise_for_status()

            rate = response.headers.get("X-Sample-Rate")
            if rate:
                try:
                    actual_rate = int(rate)
                except ValueError:
                    actual_rate = self.sample_rate
                if actual_rate != self.sample_rate:
                    raise RuntimeError(
                        f"TTS returned {actual_rate} Hz PCM, but realtime output is configured "
                        f"for {self.sample_rate} Hz. Set MAI_REALTIME_OUTPUT_RATE to match."
                    )

            async for chunk in response.aiter_bytes(8192):
                if cancel_event.is_set():
                    return
                if chunk:
                    yield chunk

    async def close(self):
        await self.client.aclose()
