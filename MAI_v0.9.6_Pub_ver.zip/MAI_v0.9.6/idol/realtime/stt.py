from __future__ import annotations

import asyncio
import json
from urllib.parse import urlencode

from .events import TranscriptEvent, TranscriptKind


class WhisperLiveKitClient:
    def __init__(
        self,
        url: str,
        language: str | None = None,
        token: str = "",
    ):
        self.url = url.rstrip("/")
        self.language = language
        self.token = token
        self.websocket = None
        self.events: asyncio.Queue[TranscriptEvent] = asyncio.Queue()
        self.receiver = None
        self.last_committed = ""

    async def connect(self):
        try:
            import websockets
        except ImportError as exc:
            raise RuntimeError(
                "Install websockets to use WhisperLiveKit streaming"
            ) from exc

        params = {"mode": "full"}
        if self.language:
            params["language"] = self.language
        if self.token:
            params["token"] = self.token

        endpoint = f"{self.url}/asr?{urlencode(params)}"
        self.websocket = await websockets.connect(
            endpoint,
            max_size=8 * 1024 * 1024,
            ping_interval=20,
            ping_timeout=20,
        )
        self.receiver = asyncio.create_task(self._receive())

    async def send(self, pcm: bytes):
        if self.websocket is None:
            raise RuntimeError("STT is not connected")
        await self.websocket.send(pcm)

    async def _receive(self):
        async for raw in self.websocket:
            if isinstance(raw, bytes):
                continue

            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                continue

            if data.get("type") in {"config", "ready_to_stop"}:
                continue

            if data.get("type") == "error" or data.get("status") == "error":
                raise RuntimeError(
                    data.get("error") or "WhisperLiveKit error"
                )

            committed, partial = self._extract(data)

            if committed and committed != self.last_committed:
                if self.last_committed and committed.startswith(self.last_committed):
                    final_text = committed[len(self.last_committed):].strip()
                else:
                    final_text = committed
                self.last_committed = committed
                if final_text:
                    await self.events.put(
                        TranscriptEvent(
                            TranscriptKind.FINAL,
                            final_text,
                        )
                    )
            elif partial:
                await self.events.put(
                    TranscriptEvent(
                        TranscriptKind.PARTIAL,
                        partial,
                    )
                )

    @staticmethod
    def _extract(data: dict) -> tuple[str, str]:
        lines = data.get("lines") or []
        texts = [
            item.get("text", "").strip()
            for item in lines
            if isinstance(item, dict)
            and item.get("text")
            and item.get("speaker") != -2
        ]
        committed = " ".join(texts).strip()

        partial = ""
        for key in (
            "buffer_transcription",
            "partial",
            "text",
            "buffer",
        ):
            value = data.get(key)
            if isinstance(value, str) and value.strip():
                partial = value.strip()
                break

        if committed and partial.startswith(committed):
            partial = partial[len(committed):].strip()

        return committed, partial

    async def next_event(self) -> TranscriptEvent:
        """Return the next transcript event or receiver failure."""
        if self.receiver is None:
            raise RuntimeError("STT is not connected")

        if self.receiver.done():
            exc = self.receiver.exception()
            if exc is not None:
                raise RuntimeError(f"Streaming STT receiver failed: {exc}") from exc
            raise RuntimeError("Streaming STT connection closed")

        event_task = asyncio.create_task(self.events.get())
        try:
            done, _ = await asyncio.wait(
                {event_task, self.receiver},
                return_when=asyncio.FIRST_COMPLETED,
            )

            # Event-before-close ordering
            if event_task in done:
                return event_task.result()

            exc = self.receiver.exception()
            if exc is not None:
                raise RuntimeError(f"Streaming STT receiver failed: {exc}") from exc
            raise RuntimeError("Streaming STT connection closed")
        finally:
            if not event_task.done():
                event_task.cancel()
                await asyncio.gather(event_task, return_exceptions=True)

    async def close(self):
        if self.receiver is not None:
            self.receiver.cancel()
            await asyncio.gather(
                self.receiver,
                return_exceptions=True,
            )
            self.receiver = None

        if self.websocket is not None:
            await self.websocket.close()
            self.websocket = None
