from __future__ import annotations

import httpx


class ElevenLabsStreamingTTS:
    def __init__(
        self,
        api_key: str,
        voice_id: str,
        model: str,
        sample_rate: int = 24000,
        base_url: str = "https://api.elevenlabs.io/v1",
        stability: float = 0.55,
        similarity_boost: float = 0.80,
        style: float = 0.18,
        speed: float = 1.0,
        use_speaker_boost: bool = True,
        timeout: float = 180.0,
    ):
        if not api_key.strip() or not voice_id.strip():
            raise RuntimeError("ElevenLabs API key and voice ID are required for realtime voice")
        self.api_key = api_key.strip()
        self.voice_id = voice_id.strip()
        self.model = model.strip()
        self.sample_rate = int(sample_rate)
        self.base_url = base_url.rstrip("/")
        self.voice_settings = {
            "stability": float(stability),
            "similarity_boost": float(similarity_boost),
            "style": float(style),
            "use_speaker_boost": bool(use_speaker_boost),
            "speed": float(speed),
        }
        self.client = httpx.AsyncClient(timeout=httpx.Timeout(timeout, connect=10.0))

    async def stream(self, text: str, cancel_event):
        url = f"{self.base_url}/text-to-speech/{self.voice_id}/stream"
        headers = {
            "xi-api-key": self.api_key,
            "Accept": "application/octet-stream",
            "Content-Type": "application/json",
        }
        payload = {
            "text": text,
            "model_id": self.model,
            "voice_settings": self.voice_settings,
        }
        async with self.client.stream(
            "POST",
            url,
            params={"output_format": f"pcm_{self.sample_rate}"},
            headers=headers,
            json=payload,
        ) as response:
            response.raise_for_status()
            async for chunk in response.aiter_bytes(8192):
                if cancel_event.is_set():
                    return
                if chunk:
                    yield chunk

    async def close(self):
        await self.client.aclose()
