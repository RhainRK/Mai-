from __future__ import annotations

import asyncio
from difflib import SequenceMatcher
import re

from .audio import DuplexAudio, DuplexConfig
from .chunking import SentenceChunker
from .events import TranscriptKind
from .stt import WhisperLiveKitClient
from .tts import StreamingTTS
from .elevenlabs_tts import ElevenLabsStreamingTTS


class RealtimeSession:
    def __init__(self, agent, settings):
        self.agent = agent
        self.settings = settings
        self.audio = DuplexAudio(
            DuplexConfig(
                input_rate=settings.realtime_input_rate,
                output_rate=settings.realtime_output_rate,
                block_ms=settings.realtime_block_ms,
                aec=settings.realtime_aec,
                barge_in_probability=settings.realtime_barge_in_probability,
                output_device=settings.audio_output_device or None,
                mirror_output_device=(
                    settings.avatar_audio_device
                    if settings.avatar_enabled and settings.avatar_audio_device
                    else None
                ),
            )
        )
        self.stt = WhisperLiveKitClient(
            settings.realtime_stt_url,
            settings.stt_language,
            settings.realtime_stt_token,
        )
        backend = settings.voice_tts_backend
        if backend == "auto":
            backend = (
                "elevenlabs"
                if settings.elevenlabs_api_key and settings.elevenlabs_voice_id
                else "http"
            )
        if backend == "elevenlabs":
            self.tts = ElevenLabsStreamingTTS(
                settings.elevenlabs_api_key,
                settings.elevenlabs_voice_id,
                settings.elevenlabs_model,
                settings.realtime_output_rate,
                settings.elevenlabs_base_url,
                settings.elevenlabs_stability,
                settings.elevenlabs_similarity_boost,
                settings.elevenlabs_style,
                settings.elevenlabs_speed,
                settings.elevenlabs_use_speaker_boost,
                settings.request_timeout,
            )
        else:
            self.tts = StreamingTTS(
                settings.voice_tts_url,
                settings.voice_tts_model,
                "mai",
                settings.realtime_output_rate,
                settings.request_timeout,
            )
        self.cancel_event = asyncio.Event()
        self.response_task = None
        self.spoken_text = ""
        self.partial_text = ""
        self.closed = False
        self.avatar_speaking = False

    async def run(self):
        sender = None
        try:
            await self.stt.connect()
            self.audio.start()
            sender = asyncio.create_task(self._audio_sender())

            print('Realtime mode. Say "goodbye MAI" to stop.')
            while not self.closed:
                event_task = asyncio.create_task(self.stt.next_event())
                try:
                    done, _ = await asyncio.wait(
                        {event_task, sender},
                        return_when=asyncio.FIRST_COMPLETED,
                    )
                    if sender in done:
                        exc = sender.exception()
                        if exc is not None:
                            raise RuntimeError(f"Realtime microphone sender failed: {exc}") from exc
                        raise RuntimeError("Realtime microphone sender stopped unexpectedly")
                    event = event_task.result()
                finally:
                    if not event_task.done():
                        event_task.cancel()
                        await asyncio.gather(event_task, return_exceptions=True)

                if event.kind == TranscriptKind.PARTIAL:
                    self.partial_text = event.text
                    if self._should_interrupt(event.text):
                        await self.interrupt()
                    continue

                text = event.text.strip()
                self.partial_text = ""

                if not text:
                    continue

                if self._is_exit(text):
                    self.closed = True
                    break

                if self._looks_like_echo(text):
                    continue

                await self.interrupt()
                print(f"You > {text}")
                self.response_task = asyncio.create_task(self._respond(text))
        finally:
            if sender is not None:
                sender.cancel()
                await asyncio.gather(sender, return_exceptions=True)
            await self.interrupt()
            self.audio.close()
            await self.stt.close()
            await self.tts.close()

    async def _audio_sender(self):
        while not self.closed:
            chunk = await self.audio.read()
            await self.stt.send(chunk)

    async def _respond(self, text: str):
        self.cancel_event = asyncio.Event()
        self.spoken_text = ""

        chunker = SentenceChunker(
            self.settings.realtime_tts_min_chars,
            self.settings.realtime_tts_max_chars,
        )
        print("MAI > ", end="", flush=True)

        try:
            async for token in self.agent.astream_respond(
                text,
                self.cancel_event,
            ):
                if self.cancel_event.is_set():
                    return

                print(token, end="", flush=True)

                for sentence in chunker.push(token):
                    await self._speak_text(sentence)

            tail = chunker.flush()
            if tail and not self.cancel_event.is_set():
                await self._speak_text(tail)

            print()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            print(f"\nRealtime error: {exc}")
        finally:
            if self.avatar_speaking:
                await asyncio.to_thread(self.agent.avatar.speaking_finished)
                self.avatar_speaking = False

    async def _speak_text(self, text: str):
        if not self.avatar_speaking:
            await asyncio.to_thread(
                self.agent.avatar.speaking_started,
                text,
                self.agent.state.to_dict(),
            )
            self.avatar_speaking = True
        self.spoken_text = (
            f"{self.spoken_text} {text}"
        ).strip()

        async for pcm in self.tts.stream(
            text,
            self.cancel_event,
        ):
            if self.cancel_event.is_set():
                return
            self.audio.write(pcm)

    async def interrupt(self):
        self.cancel_event.set()
        self.audio.stop_playback()
        if self.avatar_speaking:
            await asyncio.to_thread(self.agent.avatar.speaking_finished)
            self.avatar_speaking = False

        if self.response_task is not None:
            if not self.response_task.done():
                self.response_task.cancel()
                await asyncio.gather(
                    self.response_task,
                    return_exceptions=True,
                )
            self.response_task = None

    def _should_interrupt(self, text: str) -> bool:
        if not self.audio.playing:
            return False

        if self._looks_like_echo(text):
            return False

        if self.audio.processor is not None:
            return (
                self.audio.speech_probability()
                >= self.settings.realtime_barge_in_probability
                and len(text.strip()) >= 2
            )

        return len(text.strip()) >= self.settings.realtime_barge_in_chars

    def _looks_like_echo(self, text: str) -> bool:
        if not self.spoken_text or not text:
            return False

        a = self._normalize(text)
        b = self._normalize(self.spoken_text)

        if not a or not b:
            return False

        if a in b:
            return True

        ratio = SequenceMatcher(None, a, b[-max(len(a) * 3, 80):]).ratio()
        return ratio >= self.settings.realtime_echo_similarity

    @staticmethod
    def _normalize(text: str) -> str:
        cleaned = re.sub(r"[_\W]+", " ", text.casefold(), flags=re.UNICODE)
        return " ".join(cleaned.split())

    @staticmethod
    def _is_exit(text: str) -> bool:
        normalized = RealtimeSession._normalize(text)
        return normalized in {
            "goodbye mai",
            "bye mai",
            "stop listening",
            "exit voice mode",
        }
