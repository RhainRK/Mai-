from __future__ import annotations

import asyncio
from collections import deque
from dataclasses import dataclass
from threading import Lock

import numpy as np


@dataclass(frozen=True, slots=True)
class DuplexConfig:
    input_rate: int = 16000
    output_rate: int = 24000
    block_ms: int = 20
    aec: bool = True
    noise_suppression: bool = True
    auto_gain: bool = True
    barge_in_probability: float = 0.72
    output_device: str | int | None = None
    mirror_output_device: str | int | None = None


def resample_int16(data: np.ndarray, source_rate: int, target_rate: int) -> np.ndarray:
    if source_rate == target_rate or data.size == 0:
        return data.astype(np.int16, copy=False)

    target_size = max(1, round(data.size * target_rate / source_rate))
    old = np.linspace(0.0, 1.0, data.size, endpoint=False)
    new = np.linspace(0.0, 1.0, target_size, endpoint=False)
    result = np.interp(new, old, data.astype(np.float32))
    return np.clip(result, -32768, 32767).astype(np.int16)


class DuplexAudio:
    def __init__(self, config: DuplexConfig | None = None):
        self.config = config or DuplexConfig()
        self.loop: asyncio.AbstractEventLoop | None = None
        self.input_queue: asyncio.Queue[bytes] = asyncio.Queue(maxsize=100)
        self.output_queue: deque[bytes] = deque()
        self.output_buffer = bytearray()
        self.output_lock = Lock()
        self.playing = False
        self.input_stream = None
        self.output_stream = None
        self.mirror_output_stream = None
        self.mirror_output_queue: deque[bytes] = deque()
        self.mirror_output_buffer = bytearray()
        self.mirror_output_lock = Lock()
        self.processor = self._processor()
        self.far_reference = deque(maxlen=64)

    def _processor(self):
        if not self.config.aec:
            return None
        try:
            from pywebrtc_audio import AudioProcessor
        except ImportError:
            return None

        return AudioProcessor(
            sample_rate=self.config.input_rate,
            num_channels=1,
            echo_cancellation=True,
            noise_suppression=self.config.noise_suppression,
            auto_gain_control=self.config.auto_gain,
            ns_level=1,
            stream_delay_ms=self.config.block_ms * 2,
        )

    def start(self):
        import sounddevice as sd

        self.loop = asyncio.get_running_loop()
        input_frames = self.config.input_rate * self.config.block_ms // 1000
        output_frames = self.config.output_rate * self.config.block_ms // 1000

        def input_callback(indata, frames, time_info, status):
            near = np.frombuffer(indata, dtype=np.int16).copy()

            if self.processor is not None:
                far = self._far_for(near.size)
                near = self.processor.process(near, far)

            payload = near.tobytes()
            if self.loop is not None:
                self.loop.call_soon_threadsafe(self._put_input, payload)

        def next_payload(queue, buffer, lock, needed):
            with lock:
                while len(buffer) < needed and queue:
                    buffer.extend(queue.popleft())
                payload = bytes(buffer[:needed])
                del buffer[:needed]
            if len(payload) < needed:
                payload += b"\x00" * (needed - len(payload))
            return payload

        def output_callback(outdata, frames, time_info, status):
            needed = frames * 2
            payload = next_payload(
                self.output_queue,
                self.output_buffer,
                self.output_lock,
                needed,
            )
            outdata[:] = payload
            self.playing = any(payload)

            pcm = np.frombuffer(payload, dtype=np.int16)
            reference = resample_int16(
                pcm,
                self.config.output_rate,
                self.config.input_rate,
            )
            self.far_reference.append(reference)

        def mirror_callback(outdata, frames, time_info, status):
            needed = frames * 2
            outdata[:] = next_payload(
                self.mirror_output_queue,
                self.mirror_output_buffer,
                self.mirror_output_lock,
                needed,
            )

        self.input_stream = sd.RawInputStream(
            samplerate=self.config.input_rate,
            channels=1,
            dtype="int16",
            blocksize=input_frames,
            latency="low",
            callback=input_callback,
        )
        self.output_stream = sd.RawOutputStream(
            samplerate=self.config.output_rate,
            channels=1,
            dtype="int16",
            blocksize=output_frames,
            latency="low",
            device=self.config.output_device,
            callback=output_callback,
        )

        mirror = self.config.mirror_output_device
        if mirror is not None and mirror != self.config.output_device:
            self.mirror_output_stream = sd.RawOutputStream(
                samplerate=self.config.output_rate,
                channels=1,
                dtype="int16",
                blocksize=output_frames,
                latency="low",
                device=mirror,
                callback=mirror_callback,
            )

        self.input_stream.start()
        self.output_stream.start()
        if self.mirror_output_stream is not None:
            self.mirror_output_stream.start()

    def _put_input(self, payload: bytes):
        if self.input_queue.full():
            try:
                self.input_queue.get_nowait()
            except asyncio.QueueEmpty:
                pass
        self.input_queue.put_nowait(payload)

    def _far_for(self, samples: int) -> np.ndarray:
        if not self.far_reference:
            return np.zeros(samples, dtype=np.int16)

        chunks = list(self.far_reference)
        data = np.concatenate(chunks) if chunks else np.zeros(0, dtype=np.int16)

        if data.size < samples:
            data = np.pad(data, (samples - data.size, 0))

        return data[-samples:].astype(np.int16, copy=False)

    def write(self, payload: bytes):
        if not payload:
            return
        with self.output_lock:
            self.output_queue.append(payload)
        if self.mirror_output_stream is not None:
            with self.mirror_output_lock:
                self.mirror_output_queue.append(payload)

    def stop_playback(self):
        with self.output_lock:
            self.output_queue.clear()
            self.output_buffer.clear()
        with self.mirror_output_lock:
            self.mirror_output_queue.clear()
            self.mirror_output_buffer.clear()
        self.playing = False

    async def read(self) -> bytes:
        return await self.input_queue.get()

    def speech_probability(self) -> float:
        if self.processor is None:
            return 0.0
        try:
            return float(self.processor.speech_probability)
        except Exception:
            return 0.0

    def close(self):
        self.stop_playback()

        for stream in (
            self.input_stream,
            self.output_stream,
            self.mirror_output_stream,
        ):
            if stream is None:
                continue
            try:
                stream.stop()
            except Exception:
                pass
            try:
                stream.close()
            except Exception:
                pass
