from dataclasses import dataclass
from enum import Enum


class TranscriptKind(str, Enum):
    PARTIAL = "partial"
    FINAL = "final"


@dataclass(frozen=True, slots=True)
class TranscriptEvent:
    kind: TranscriptKind
    text: str


@dataclass(frozen=True, slots=True)
class TextChunk:
    text: str
    final: bool = False
