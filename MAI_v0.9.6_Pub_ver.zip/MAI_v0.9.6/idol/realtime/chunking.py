from __future__ import annotations

import re


class SentenceChunker:
    def __init__(self, min_chars: int = 36, max_chars: int = 180):
        self.min_chars = min_chars
        self.max_chars = max_chars
        self.buffer = ""

    def push(self, text: str) -> list[str]:
        self.buffer += text
        chunks = []

        while True:
            boundary = self._boundary()
            if boundary is None:
                break

            chunk = self.buffer[:boundary].strip()
            self.buffer = self.buffer[boundary:].lstrip()

            if chunk:
                chunks.append(chunk)

        return chunks

    def flush(self) -> str:
        chunk = self.buffer.strip()
        self.buffer = ""
        return chunk

    def _boundary(self) -> int | None:
        if len(self.buffer) >= self.max_chars:
            split = self.buffer.rfind(" ", 0, self.max_chars)
            return split if split > self.min_chars else self.max_chars

        if len(self.buffer) < self.min_chars:
            return None

        match = re.search(r'[.!?](?:["\')\]]+)?\s', self.buffer)
        if match:
            return match.end()

        match = re.search(r"[,;:]\s", self.buffer)
        if match and match.end() >= self.min_chars * 2:
            return match.end()

        return None
