from __future__ import annotations

from pathlib import Path
import tempfile
import wave

import httpx


class ElevenLabsError(RuntimeError):
    pass


class ElevenLabsSpeechEngine:
    def __init__(
        self,
        api_key: str,
        voice_id: str,
        model: str = "eleven_v3_conversational",
        base_url: str = "https://api.elevenlabs.io/v1",
        sample_rate: int = 24000,
        stability: float = 0.55,
        similarity_boost: float = 0.80,
        style: float = 0.18,
        speed: float = 1.0,
        use_speaker_boost: bool = True,
        timeout: float = 180.0,
    ):
        self.api_key = api_key.strip()
        self.voice_id = voice_id.strip()
        self.model = model.strip()
        self.base_url = base_url.rstrip("/")
        self.sample_rate = int(sample_rate)
        self.stability = float(stability)
        self.similarity_boost = float(similarity_boost)
        self.style = float(style)
        self.speed = float(speed)
        self.use_speaker_boost = bool(use_speaker_boost)
        self.client = httpx.Client(timeout=timeout)

        if not self.api_key:
            raise ElevenLabsError("MAI_ELEVENLABS_API_KEY is not configured")
        if not self.voice_id:
            raise ElevenLabsError(
                "MAI_ELEVENLABS_VOICE_ID is not configured. Run design_mai_voice.py first."
            )
        if self.sample_rate not in {16000, 22050, 24000, 44100}:
            raise ElevenLabsError("Unsupported ElevenLabs PCM sample rate")

    @property
    def output_format(self) -> str:
        return f"pcm_{self.sample_rate}"

    def payload(self, text: str) -> dict:
        return {
            "text": text,
            "model_id": self.model,
            "voice_settings": {
                "stability": self.stability,
                "similarity_boost": self.similarity_boost,
                "style": self.style,
                "use_speaker_boost": self.use_speaker_boost,
                "speed": self.speed,
            },
        }

    def _headers(self) -> dict[str, str]:
        return {
            "xi-api-key": self.api_key,
            "Accept": "application/octet-stream",
            "Content-Type": "application/json",
        }

    def synthesize(self, text: str, output_path: str) -> str:
        destination = Path(output_path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        temp_path: Path | None = None
        url = f"{self.base_url}/text-to-speech/{self.voice_id}/stream"
        try:
            with tempfile.NamedTemporaryFile(
                dir=destination.parent,
                suffix=".pcm",
                delete=False,
            ) as handle:
                temp_path = Path(handle.name)
                with self.client.stream(
                    "POST",
                    url,
                    params={"output_format": self.output_format},
                    headers=self._headers(),
                    json=self.payload(text),
                ) as response:
                    # Error responses are still streaming in httpx. Read the body
                    # before raise_for_status() so the API detail remains available.
                    if response.is_error:
                        response.read()
                    response.raise_for_status()
                    for chunk in response.iter_bytes(8192):
                        if chunk:
                            handle.write(chunk)

            raw = temp_path.read_bytes()
            if len(raw) < 2 or len(raw) % 2:
                raise ElevenLabsError("ElevenLabs returned invalid PCM audio")
            with wave.open(str(destination), "wb") as wav:
                wav.setnchannels(1)
                wav.setsampwidth(2)
                wav.setframerate(self.sample_rate)
                wav.writeframes(raw)
            return str(destination)
        except httpx.HTTPStatusError as exc:
            detail = exc.response.text.strip()[:800]
            raise ElevenLabsError(
                f"ElevenLabs TTS failed ({exc.response.status_code}): {detail}"
            ) from exc
        except httpx.HTTPError as exc:
            raise ElevenLabsError(f"ElevenLabs TTS request failed: {exc}") from exc
        finally:
            if temp_path is not None:
                temp_path.unlink(missing_ok=True)

    def close(self):
        self.client.close()
