from dataclasses import asdict, dataclass
from math import exp
from time import time


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


@dataclass(slots=True)
class EmotionalState:
    energy: float = 0.70
    confidence: float = 0.72
    stress: float = 0.18
    curiosity: float = 0.78
    playfulness: float = 0.68
    focus: float = 0.65
    last_update: float = 0.0

    def __post_init__(self):
        if not self.last_update:
            self.last_update = time()

    def drift_toward_baseline(self):
        now = time()
        elapsed = max(0.0, (now - self.last_update) / 3600.0)
        strength = 1.0 - exp(-elapsed / 8.0)

        baseline = {
            "energy": 0.70,
            "confidence": 0.72,
            "stress": 0.18,
            "curiosity": 0.78,
            "playfulness": 0.68,
            "focus": 0.65,
        }

        for key, target in baseline.items():
            current = getattr(self, key)
            setattr(
                self,
                key,
                clamp(current + (target - current) * strength),
            )

        self.last_update = now

    def react_to_user_message(self, text: str):
        lowered = text.casefold()

        if any(
            word in lowered
            for word in ("music", "song", "idol", "dance", "stage")
        ):
            self.energy = clamp(self.energy + 0.03)
            self.curiosity = clamp(self.curiosity + 0.04)
            self.focus = clamp(self.focus + 0.03)

        if any(
            word in lowered
            for word in ("amazing", "proud", "good job", "well done")
        ):
            self.confidence = clamp(self.confidence + 0.03)
            self.playfulness = clamp(self.playfulness + 0.02)

        if any(
            word in lowered
            for word in ("problem", "worried", "stress", "urgent")
        ):
            self.playfulness = clamp(self.playfulness - 0.05)
            self.focus = clamp(self.focus + 0.05)

        if "?" in text:
            self.curiosity = clamp(self.curiosity + 0.01)

        self.last_update = time()

    def as_prompt(self) -> str:
        return (
            f"energy={self.energy:.2f}, "
            f"confidence={self.confidence:.2f}, "
            f"stress={self.stress:.2f}, "
            f"curiosity={self.curiosity:.2f}, "
            f"playfulness={self.playfulness:.2f}, "
            f"focus={self.focus:.2f}"
        )

    def to_dict(self):
        return asdict(self)
