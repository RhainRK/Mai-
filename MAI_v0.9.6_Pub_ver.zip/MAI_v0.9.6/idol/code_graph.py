from __future__ import annotations

import ast
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import sqlite3
import tokenize


@dataclass(slots=True)
class CodeNode:
    node_id: str
    kind: str
    name: str
    path: str
    line: int


class CodeGraph:
    def __init__(self, db_path: str | Path):
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(db_path))
        self.conn.row_factory = sqlite3.Row
        with self.conn:
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS code_files (
                    path TEXT PRIMARY KEY, digest TEXT NOT NULL, indexed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS code_nodes (
                    node_id TEXT PRIMARY KEY, kind TEXT NOT NULL, name TEXT NOT NULL,
                    path TEXT NOT NULL, line INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS code_edges (
                    source TEXT NOT NULL, relation TEXT NOT NULL, target TEXT NOT NULL,
                    path TEXT NOT NULL, UNIQUE(source, relation, target, path)
                );
                CREATE INDEX IF NOT EXISTS idx_code_nodes_name ON code_nodes(name);
                CREATE INDEX IF NOT EXISTS idx_code_edges_source ON code_edges(source);
                """
            )

    @staticmethod
    def _id(path: str, kind: str, name: str) -> str:
        return hashlib.sha1(f"{path}\0{kind}\0{name}".encode()).hexdigest()[:20]

    def index(self, root: str | Path) -> dict[str, int]:
        root = Path(root).resolve()
        if not root.is_dir():
            raise ValueError('Code root must be an existing directory')
        seen = set()
        changed = nodes = edges = 0
        for file_path in root.rglob("*.py"):
            if file_path.is_symlink() or any(part.startswith(".") or part in {"__pycache__", "site-packages", "venv", "node_modules"} for part in file_path.relative_to(root).parts):
                continue
            relative = file_path.relative_to(root).as_posix()
            seen.add(relative)
            try:
                with tokenize.open(file_path) as handle:
                    source = handle.read()
            except (OSError, UnicodeError, SyntaxError):
                continue
            digest = hashlib.sha256(source.encode()).hexdigest()
            known = self.conn.execute("SELECT digest FROM code_files WHERE path=?", (relative,)).fetchone()
            if known and known["digest"] == digest:
                continue
            try:
                tree = ast.parse(source, filename=relative)
            except SyntaxError:
                with self.conn:
                    self.conn.execute('DELETE FROM code_nodes WHERE path=?', (relative,))
                    self.conn.execute('DELETE FROM code_edges WHERE path=?', (relative,))
                    self.conn.execute('DELETE FROM code_files WHERE path=?', (relative,))
                continue
            file_node = self._id(relative, "module", relative)
            node_rows = [(file_node, "module", relative, relative, 1)]
            edge_rows: list[tuple[str, str, str, str]] = []
            for item in ast.walk(tree):
                if isinstance(item, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                    kind = "class" if isinstance(item, ast.ClassDef) else "function"
                    node_id = self._id(relative, kind, f"{item.name}:{item.lineno}")
                    node_rows.append((node_id, kind, item.name, relative, item.lineno))
                    edge_rows.append((file_node, "defines", node_id, relative))
                elif isinstance(item, ast.Import):
                    edge_rows.extend((file_node, "imports", alias.name, relative) for alias in item.names)
                elif isinstance(item, ast.ImportFrom) and item.module:
                    edge_rows.append((file_node, "imports", item.module, relative))
                elif isinstance(item, ast.Call):
                    target = self._call_name(item.func)
                    if target:
                        edge_rows.append((file_node, "calls", target, relative))
            with self.conn:
                self.conn.execute("DELETE FROM code_nodes WHERE path=?", (relative,))
                self.conn.execute("DELETE FROM code_edges WHERE path=?", (relative,))
                self.conn.executemany("INSERT INTO code_nodes VALUES (?, ?, ?, ?, ?)", node_rows)
                self.conn.executemany(
                    "INSERT OR IGNORE INTO code_edges VALUES (?, ?, ?, ?)", edge_rows
                )
                self.conn.execute(
                    "INSERT OR REPLACE INTO code_files(path, digest) VALUES (?, ?)",
                    (relative, digest),
                )
            changed += 1
            nodes += len(node_rows)
            edges += len(edge_rows)
        stale = {row[0] for row in self.conn.execute('SELECT path FROM code_files')} - seen
        with self.conn:
            for path in stale:
                for table in ('code_files', 'code_nodes', 'code_edges'):
                    self.conn.execute(f'DELETE FROM {table} WHERE path=?', (path,))
        return {"changed_files": changed, "nodes_written": nodes, "edges_written": edges, 'removed_files': len(stale)}

    @staticmethod
    def _call_name(node: ast.AST) -> str:
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            prefix = CodeGraph._call_name(node.value)
            return f"{prefix}.{node.attr}" if prefix else node.attr
        return ""

    def query(self, name: str, limit: int = 40) -> dict:
        pattern = f"%{name.casefold()}%"
        nodes = self.conn.execute(
            "SELECT * FROM code_nodes WHERE lower(name) LIKE ? ORDER BY path, line LIMIT ?",
            (pattern, max(1, min(limit, 200))),
        ).fetchall()
        ids = [row["node_id"] for row in nodes]
        edges = []
        if ids:
            marks = ",".join("?" for _ in ids)
            edges = self.conn.execute(
                f"SELECT * FROM code_edges WHERE source IN ({marks}) LIMIT ?",
                (*ids, max(1, min(limit * 3, 500))),
            ).fetchall()
        return {"nodes": [dict(row) for row in nodes], "edges": [dict(row) for row in edges]}

    def close(self) -> None:
        self.conn.close()

    def export_json(self, path: str | Path) -> None:
        nodes = [dict(row) for row in self.conn.execute("SELECT * FROM code_nodes")]
        edges = [dict(row) for row in self.conn.execute("SELECT * FROM code_edges")]
        Path(path).write_text(json.dumps({"nodes": nodes, "edges": edges}, indent=2), encoding="utf-8")
