from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
from typing import Any

import numpy as np

from config import settings
from .database import close_database, connect_database
from .embeddings import SemanticEmbedder
from .memory_extractor import StructuredMemoryExtractor


class MemoryStore:
    def __init__(self, db_path: str):
        self.conn = connect_database(db_path, timeout=5.0)
        self.embedder = SemanticEmbedder(settings.embedding_model)
        self.extractor = StructuredMemoryExtractor()
        self.fts_enabled = False
        self._setup()

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _content_hash(kind: str, content: str) -> str:
        normalized = " ".join(content.casefold().split())
        return hashlib.sha256(f"{kind}\0{normalized}".encode()).hexdigest()

    @staticmethod
    def _fts_query(text: str) -> str:
        tokens = re.findall(r"[\w']+", text.casefold(), flags=re.UNICODE)
        tokens = [token.replace("'", "") for token in tokens if len(token) > 1]
        return " OR ".join(f'"{token}"' for token in tokens[:16])

    @staticmethod
    def _recency_score(created_at: str) -> float:
        try:
            created = datetime.fromisoformat(created_at)
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            age_days = max(0.0, (datetime.now(timezone.utc) - created).total_seconds() / 86400.0)
            return math.exp(-age_days / 90.0)
        except (TypeError, ValueError):
            return 0.0

    def _setup(self):
        with self.conn:
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    kind TEXT NOT NULL,
                    content TEXT NOT NULL,
                    importance REAL NOT NULL DEFAULT 0.5,
                    embedding BLOB,
                    created_at TEXT NOT NULL,
                    last_accessed TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS profile_facts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key TEXT NOT NULL,
                    value TEXT NOT NULL,
                    confidence REAL NOT NULL DEFAULT 0.7,
                    updated_at TEXT NOT NULL,
                    UNIQUE(key, value)
                );
                CREATE TABLE IF NOT EXISTS app_state (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS memory_observations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    user_text TEXT NOT NULL,
                    assistant_text TEXT NOT NULL,
                    topics_json TEXT NOT NULL DEFAULT '[]',
                    importance REAL NOT NULL DEFAULT 0.5,
                    created_at TEXT NOT NULL,
                    consolidated INTEGER NOT NULL DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS memory_episodes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL UNIQUE,
                    summary TEXT NOT NULL,
                    observation_count INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS memory_links (
                    source_id INTEGER NOT NULL,
                    relation TEXT NOT NULL,
                    target_id INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(source_id, relation, target_id)
                );
                """
            )
            columns = {row[1] for row in self.conn.execute("PRAGMA table_info(memories)")}
            if "content_hash" not in columns:
                self.conn.execute("ALTER TABLE memories ADD COLUMN content_hash TEXT")
            if "embedding_model" not in columns:
                self.conn.execute("ALTER TABLE memories ADD COLUMN embedding_model TEXT")
            if "access_count" not in columns:
                self.conn.execute("ALTER TABLE memories ADD COLUMN access_count INTEGER NOT NULL DEFAULT 0")
            if 'active' not in columns:
                self.conn.execute('ALTER TABLE memories ADD COLUMN active INTEGER NOT NULL DEFAULT 1')
            if 'pinned' not in columns:
                self.conn.execute('ALTER TABLE memories ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0')
            self.conn.execute("UPDATE memories SET active=0 WHERE id IN (SELECT target_id FROM memory_links WHERE relation='supersedes')")
            self.conn.execute('CREATE INDEX IF NOT EXISTS idx_observation_pending ON memory_observations(session_id, consolidated, id)')

            old_profile = self.conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='user_profile'"
            ).fetchone()
            if old_profile:
                rows = self.conn.execute(
                    "SELECT key, value, confidence, updated_at FROM user_profile"
                ).fetchall()
                self.conn.executemany(
                    "INSERT OR IGNORE INTO profile_facts(key, value, confidence, updated_at) VALUES (?, ?, ?, ?)",
                    [(row[0], row[1], row[2], row[3]) for row in rows],
                )

            rows = self.conn.execute(
                "SELECT id, kind, content FROM memories WHERE content_hash IS NULL"
            ).fetchall()
            self.conn.executemany(
                "UPDATE memories SET content_hash=? WHERE id=?",
                [(self._content_hash(row["kind"], row["content"]), row["id"]) for row in rows],
            )
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_memories_hash ON memories(content_hash)"
            )
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_memories_importance ON memories(importance DESC, id DESC)"
            )
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_memories_access ON memories(last_accessed DESC)"
            )
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_profile_key ON profile_facts(key)"
            )

        self._setup_fts()

    def _setup_fts(self):
        try:
            with self.conn:
                self.conn.executescript(
                    """
                    CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
                        content,
                        content='memories',
                        content_rowid='id'
                    );
                    CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
                        INSERT INTO memories_fts(rowid, content) VALUES (new.id, new.content);
                    END;
                    CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
                        INSERT INTO memories_fts(memories_fts, rowid, content) VALUES('delete', old.id, old.content);
                    END;
                    CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE OF content ON memories BEGIN
                        INSERT INTO memories_fts(memories_fts, rowid, content) VALUES('delete', old.id, old.content);
                        INSERT INTO memories_fts(rowid, content) VALUES (new.id, new.content);
                    END;
                    """
                )
                memory_count = self.conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
                fts_count = self.conn.execute("SELECT COUNT(*) FROM memories_fts").fetchone()[0]
                if memory_count != fts_count:
                    self.conn.execute("INSERT INTO memories_fts(memories_fts) VALUES('rebuild')")
            self.fts_enabled = True
        except sqlite3.OperationalError:
            self.fts_enabled = False

    def add_message(self, role: str, content: str):
        with self.conn:
            self.conn.execute(
                "INSERT INTO messages(role, content, created_at) VALUES (?, ?, ?)",
                (role, content.strip(), self._now()),
            )

    def recent_messages(self, limit: int = 14) -> list[dict]:
        rows = self.conn.execute(
            "SELECT role, content FROM messages ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(row) for row in reversed(rows)]

    def clear_session(self):
        with self.conn:
            self.conn.execute("DELETE FROM messages")

    def add_memory(self, content: str, kind: str = "episodic", importance: float = 0.5):
        content = content.strip()
        if not content:
            return None
        importance = max(0.0, min(float(importance), 1.0))
        digest = self._content_hash(kind, content)
        existing = self.conn.execute(
            "SELECT id FROM memories WHERE content_hash=? AND active=1 LIMIT 1",
            (digest,),
        ).fetchone()
        if existing:
            with self.conn:
                self.conn.execute(
                    "UPDATE memories SET importance=MAX(importance, ?), last_accessed=? WHERE id=?",
                    (importance, self._now(), existing["id"]),
                )
            return int(existing["id"])

        vector = self.embedder.encode(content).astype(np.float32, copy=False)
        now = self._now()
        with self.conn:
            cursor = self.conn.execute(
                """
                INSERT INTO memories(
                    kind, content, importance, embedding, created_at, last_accessed,
                    content_hash, embedding_model, access_count
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
                """,
                (
                    kind,
                    content,
                    importance,
                    vector.tobytes(),
                    now,
                    now,
                    digest,
                    self.embedder.identity,
                ),
            )
        return int(cursor.lastrowid)

    def add_profile_fact(self, key: str, value: str, confidence: float = 0.75):
        key, value = key.strip(), value.strip()
        if not key or not value:
            return
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO profile_facts(key, value, confidence, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(key, value) DO UPDATE SET
                    confidence=MAX(confidence, excluded.confidence),
                    updated_at=excluded.updated_at
                """,
                (key, value, confidence, self._now()),
            )

    def get_profile(self, limit: int = 40) -> list[dict]:
        rows = self.conn.execute(
            """
            SELECT key, value, confidence
            FROM profile_facts
            ORDER BY confidence DESC, updated_at DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]

    def _embedding_for(self, row: sqlite3.Row) -> np.ndarray:
        if row["embedding"] and row["embedding_model"] == self.embedder.identity:
            return np.frombuffer(row["embedding"], dtype=np.float32)
        vector = self.embedder.encode(row["content"]).astype(np.float32, copy=False)
        with self.conn:
            self.conn.execute(
                "UPDATE memories SET embedding=?, embedding_model=? WHERE id=?",
                (vector.tobytes(), self.embedder.identity, row["id"]),
            )
        return vector

    def _candidate_rows(self, query: str) -> tuple[list[sqlite3.Row], dict[int, float]]:
        lexical: dict[int, float] = {}
        ids: set[int] = set()

        if self.fts_enabled:
            fts_query = self._fts_query(query)
            if fts_query:
                try:
                    rows = self.conn.execute(
                        """
                        SELECT rowid AS id, bm25(memories_fts) AS rank
                        FROM memories_fts
                        WHERE memories_fts MATCH ?
                        ORDER BY rank
                        LIMIT 100
                        """,
                        (fts_query,),
                    ).fetchall()
                    if rows:
                        ranks = [float(row["rank"]) for row in rows]
                        low, high = min(ranks), max(ranks)
                        span = max(high - low, 1e-9)
                        for row in rows:
                            memory_id = int(row["id"])
                            ids.add(memory_id)
                            lexical[memory_id] = 1.0 - ((float(row["rank"]) - low) / span)
                except sqlite3.OperationalError:
                    pass

        fallback_rows = self.conn.execute(
            """
            SELECT id
            FROM memories
            WHERE active=1
            ORDER BY importance DESC, last_accessed DESC, id DESC
            LIMIT ?
            """,
            (settings.memory_candidate_limit,),
        ).fetchall()
        ids.update(int(row["id"]) for row in fallback_rows)

        if not ids:
            return [], lexical

        placeholders = ",".join("?" for _ in ids)
        rows = self.conn.execute(
            f"""
            SELECT id, kind, content, importance, embedding, embedding_model,
                   created_at, last_accessed, access_count
            FROM memories
            WHERE active=1 AND id IN ({placeholders})
            """,
            tuple(ids),
        ).fetchall()
        return rows, lexical

    def recall(self, query: str, limit: int = 8) -> list[dict]:
        query = query.strip()
        if not query or limit <= 0:
            return []

        rows, lexical = self._candidate_rows(query)
        if not rows:
            return []

        query_vector = self.embedder.encode(query).astype(np.float32, copy=False)
        scored = []
        hash_backend = self.embedder.identity.startswith("hash-v1-")

        for row in rows:
            vector = self._embedding_for(row)
            if vector.shape != query_vector.shape:
                continue
            semantic = float(np.dot(vector, query_vector))
            semantic_unit = max(0.0, min((semantic + 1.0) / 2.0, 1.0))
            lexical_score = lexical.get(int(row["id"]), 0.0)
            importance = max(0.0, min(float(row["importance"]), 1.0))
            recency = self._recency_score(row["created_at"])

            if hash_backend:
                score = semantic_unit * 0.45 + lexical_score * 0.35 + importance * 0.15 + recency * 0.05
            else:
                score = semantic_unit * 0.68 + lexical_score * 0.17 + importance * 0.10 + recency * 0.05

            scored.append((score, semantic, lexical_score, row))

        scored.sort(key=lambda item: item[0], reverse=True)
        selected = []
        seen = set()
        ids = []

        for score, semantic, lexical_score, row in scored:
            normalized = " ".join(row["content"].casefold().split())
            if normalized in seen:
                continue
            if semantic < 0.05 and lexical_score <= 0.0 and float(row["importance"]) < 0.9:
                continue
            seen.add(normalized)
            selected.append(
                {
                    "id": int(row["id"]),
                    "kind": row["kind"],
                    "content": row["content"],
                    "importance": float(row["importance"]),
                    "semantic_score": semantic,
                    "lexical_score": lexical_score,
                    "recall_score": float(score),
                    "created_at": row["created_at"],
                }
            )
            ids.append(int(row["id"]))
            if len(selected) >= limit:
                break

        if ids:
            now = self._now()
            with self.conn:
                self.conn.executemany(
                    "UPDATE memories SET last_accessed=?, access_count=access_count+1 WHERE id=?",
                    [(now, memory_id) for memory_id in ids],
                )
        return selected

    def recent_memories(self, limit: int = 20) -> list[dict]:
        rows = self.conn.execute(
            """
            SELECT id, kind, content, importance, created_at, last_accessed, access_count
            FROM memories
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]

    def forget_memory(self, memory_id: int) -> bool:
        with self.conn:
            self.conn.execute('DELETE FROM memory_links WHERE source_id=? OR target_id=?', (memory_id, memory_id))
            cursor = self.conn.execute("DELETE FROM memories WHERE id=?", (memory_id,))
        return cursor.rowcount > 0

    def observe_turn(self, session_id: str, user_text: str, assistant_text: str) -> int:
        tokens = re.findall(r"[a-z0-9_]+", user_text.casefold())
        topics = list(dict.fromkeys(token for token in tokens if len(token) > 4))[:10]
        importance = 0.82 if re.search(r"\b(remember|always|never|important|prefer)\b", user_text, re.I) else 0.52
        with self.conn:
            cursor = self.conn.execute(
                """
                INSERT INTO memory_observations(
                    session_id, user_text, assistant_text, topics_json, importance, created_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (session_id, user_text, assistant_text, json.dumps(topics), importance, self._now()),
            )
        return int(cursor.lastrowid)

    def consolidate_session(self, session_id: str, minimum: int = 6) -> int | None:
        rows = self.conn.execute(
            """
            SELECT id, user_text, assistant_text, importance
            FROM memory_observations
            WHERE session_id=? AND consolidated=0 ORDER BY id
            """,
            (session_id,),
        ).fetchall()
        if len(rows) < max(1, int(minimum)):
            return None
        highlights = sorted(rows, key=lambda row: float(row["importance"]), reverse=True)[:5]
        parts = [" ".join(str(row["user_text"]).split())[:240] for row in highlights]
        summary = "Session topics and user intent: " + " | ".join(parts)
        now = self._now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO memory_episodes(session_id, summary, observation_count, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(session_id) DO UPDATE SET
                    summary=excluded.summary,
                    observation_count=memory_episodes.observation_count + excluded.observation_count,
                    updated_at=excluded.updated_at
                """,
                (f'{session_id}:{rows[0]["id"]}:{rows[-1]["id"]}', summary, len(rows), now, now),
            )
            self.conn.executemany(
                "UPDATE memory_observations SET consolidated=1 WHERE id=?",
                [(int(row["id"]),) for row in rows],
            )
        return self.add_memory(summary, "episode_summary", 0.72)

    def supersede(self, old_memory_id: int, new_content: str, importance: float = 0.8) -> int:
        old = self.conn.execute('SELECT content FROM memories WHERE id=? AND active=1', (old_memory_id,)).fetchone()
        if old is None:
            raise ValueError('Active memory not found')
        if not new_content.strip():
            raise ValueError('Replacement memory is empty')
        if ' '.join(old['content'].casefold().split()) == ' '.join(new_content.casefold().split()):
            return old_memory_id
        new_id = self.add_memory(new_content, "semantic", importance)
        if new_id is None:
            raise ValueError("Replacement memory is empty")
        with self.conn:
            self.conn.execute('UPDATE memories SET active=0 WHERE id=?', (old_memory_id,))
            self.conn.execute(
                "INSERT OR IGNORE INTO memory_links VALUES (?, 'supersedes', ?, ?)",
                (new_id, int(old_memory_id), self._now()),
            )
        return new_id

    def pin_memory(self, memory_id: int, pinned: bool = True) -> bool:
        with self.conn:
            cursor = self.conn.execute(
                "UPDATE memories SET pinned=? WHERE id=? AND active=1",
                (int(pinned), int(memory_id)),
            )
        return cursor.rowcount > 0

    def stats(self) -> dict:
        messages = self.conn.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
        memories = self.conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        profile = self.conn.execute("SELECT COUNT(*) FROM profile_facts").fetchone()[0]
        return {
            "messages": int(messages),
            "memories": int(memories),
            "profile_facts": int(profile),
            "embedding_backend": self.embedder.identity,
            "embedding_fallback_error": self.embedder.load_error,
            "fts5": self.fts_enabled,
            "observations": int(self.conn.execute("SELECT COUNT(*) FROM memory_observations").fetchone()[0]),
            "episodes": int(self.conn.execute("SELECT COUNT(*) FROM memory_episodes").fetchone()[0]),
            "context_cache": int(self.conn.execute("SELECT COUNT(*) FROM context_cache").fetchone()[0]) if self.conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='context_cache'").fetchone() else 0,
        }

    def extract_and_store(self, text: str) -> dict:
        data = self.extractor.extract(text)
        for fact in data.get("profile", []):
            self.add_profile_fact(fact["key"], fact["value"], fact.get("confidence", 0.75))
        for memory in data.get("memories", []):
            self.add_memory(
                memory["content"],
                memory.get("kind", "episodic"),
                memory.get("importance", 0.6),
            )
        return data

    def load_state(self, key: str, default: Any = None) -> Any:
        row = self.conn.execute(
            "SELECT value FROM app_state WHERE key=?",
            (key,),
        ).fetchone()
        return default if row is None else json.loads(row["value"])

    def save_state(self, key: str, value: Any):
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO app_state(key, value, updated_at)
                VALUES (?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    value=excluded.value,
                    updated_at=excluded.updated_at
                """,
                (key, json.dumps(value), self._now()),
            )

    def close(self):
        close_database(self.conn)
