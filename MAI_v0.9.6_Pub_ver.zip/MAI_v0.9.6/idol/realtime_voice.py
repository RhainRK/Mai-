from dataclasses import dataclass
import re
import time

from .audio_io import AudioConfig, MicrophoneRecorder
from .stt import FasterWhisperSTT, STTConfig

EXIT = object()


@dataclass(frozen=True, slots=True)
class LiveVoiceConfig:
    input_path: str = "data/audio/user_input.wav"
    output_path: str = "data/audio/mai_reply.wav"
    exit_phrases: tuple[str, ...] = (
        "goodbye mai",
        "bye mai",
        "stop listening",
        "exit voice mode",
    )


class LiveVoiceSession:
    def __init__(
        self,
        agent,
        audio_config: AudioConfig,
        stt_config: STTConfig,
        config: LiveVoiceConfig | None = None,
    ):
        self.agent = agent
        self.recorder = MicrophoneRecorder(audio_config)
        self.stt = FasterWhisperSTT(stt_config)
        self.config = config or LiveVoiceConfig()

    @staticmethod
    def _status(state: str):
        text = {
            "listening": "Listening...",
            "speaking": "I hear you...",
            "recorded": "Captured.",
            "no_speech": "No speech detected.",
        }.get(state)
        if text:
            print(text)

    def _is_exit(self, text: str) -> bool:
        normalized = re.sub(r"[^a-z0-9 ]+", "", text.casefold()).strip()
        return any(
            normalized == phrase or normalized.endswith(f" {phrase}")
            for phrase in self.config.exit_phrases
        )

    def capture_text(self) -> str | None:
        audio_path = self.recorder.listen_until_silence(
            self.config.input_path,
            self._status,
        )
        if audio_path is None:
            return None
        print("Transcribing...")
        user_text = self.stt.transcribe(audio_path).strip()
        return user_text or None

    def one_turn(self):
        user_text = self.capture_text()
        if not user_text:
            return None
        print(f"You > {user_text}")
        if self._is_exit(user_text):
            return EXIT
        started = time.perf_counter()
        print("MAI > ", end="", flush=True)
        chunks = []
        for chunk in self.agent.stream_respond(user_text):
            chunks.append(chunk)
            print(chunk, end="", flush=True)
        reply = "".join(chunks).strip()
        elapsed = time.perf_counter() - started
        print()
        metrics = self.agent.metrics()
        rate = metrics.get("tokens_per_second")
        if rate:
            print(f"[{elapsed:.1f}s | {rate:.1f} tok/s]")
        else:
            print(f"[{elapsed:.1f}s]")
        print("Speaking...")
        reply_path = self.agent.speak(reply, self.config.output_path)
        self.agent.play_voice(reply_path, reply)
        return reply

    def run(self):
        print('Voice mode. Say "goodbye MAI" to stop.')
        while self.one_turn() is not EXIT:
            pass
