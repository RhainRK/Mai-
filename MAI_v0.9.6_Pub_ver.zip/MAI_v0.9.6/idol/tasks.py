from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
import json
from pathlib import Path
import sqlite3
from .database import close_database, connect_database
from uuid import uuid4


class GoalStatus(str, Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class StepStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class TaskStore:
    def __init__(self, db_path: str | Path):
        self.conn = connect_database(db_path, timeout=5.0)
        self._setup()

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def _setup(self):
        with self.conn:
            self.conn.executescript(
                '''
                CREATE TABLE IF NOT EXISTS goals (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    outcome TEXT NOT NULL,
                    status TEXT NOT NULL,
                    priority INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS goal_steps (
                    id TEXT PRIMARY KEY,
                    goal_id TEXT NOT NULL,
                    position INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    status TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    result TEXT,
                    error TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    started_at TEXT,
                    completed_at TEXT,
                    UNIQUE(goal_id, position),
                    FOREIGN KEY(goal_id) REFERENCES goals(id)
                );

                CREATE TABLE IF NOT EXISTS goal_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    goal_id TEXT NOT NULL,
                    step_id TEXT,
                    event TEXT NOT NULL,
                    payload TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_goals_status
                ON goals(status, priority DESC, updated_at DESC);

                CREATE INDEX IF NOT EXISTS idx_goal_steps
                ON goal_steps(goal_id, position);
                '''
            )

    def create(
        self,
        title: str,
        outcome: str,
        steps: list[str],
        priority: int = 3,
    ) -> dict:
        title = title.strip()
        outcome = outcome.strip()
        clean_steps = [step.strip() for step in steps if step.strip()]

        if not title or not outcome:
            raise ValueError("Title and outcome are required")
        if not clean_steps:
            raise ValueError("At least one step is required")
        if not 1 <= priority <= 5:
            raise ValueError("Priority must be between 1 and 5")

        goal_id = str(uuid4())
        now = self._now()

        with self.conn:
            self.conn.execute(
                '''
                INSERT INTO goals(
                    id, title, outcome, status, priority, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ''',
                (
                    goal_id,
                    title,
                    outcome,
                    GoalStatus.ACTIVE.value,
                    priority,
                    now,
                    now,
                ),
            )
            for position, step in enumerate(clean_steps, start=1):
                self.conn.execute(
                    '''
                    INSERT INTO goal_steps(
                        id,
                        goal_id,
                        position,
                        title,
                        status,
                        attempts,
                        created_at,
                        updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, 0, ?, ?)
                    ''',
                    (
                        str(uuid4()),
                        goal_id,
                        position,
                        step,
                        StepStatus.PENDING.value,
                        now,
                        now,
                    ),
                )
            self._event(goal_id, None, "created", {"steps": len(clean_steps)})

        return self.get(goal_id)

    def list(self, status: str = "active", limit: int = 20) -> list[dict]:
        if status == "all":
            rows = self.conn.execute(
                '''
                SELECT id
                FROM goals
                ORDER BY priority DESC, updated_at DESC
                LIMIT ?
                ''',
                (limit,),
            ).fetchall()
        else:
            rows = self.conn.execute(
                '''
                SELECT id
                FROM goals
                WHERE status=?
                ORDER BY priority DESC, updated_at DESC
                LIMIT ?
                ''',
                (status, limit),
            ).fetchall()

        return [self.get(row["id"]) for row in rows]

    def current(self) -> dict | None:
        row = self.conn.execute(
            '''
            SELECT id
            FROM goals
            WHERE status=?
            ORDER BY priority DESC, updated_at DESC
            LIMIT 1
            ''',
            (GoalStatus.ACTIVE.value,),
        ).fetchone()
        return self.get(row["id"]) if row else None

    def get(self, goal_id: str) -> dict:
        goal = self.conn.execute(
            '''
            SELECT id, title, outcome, status, priority, created_at, updated_at
            FROM goals
            WHERE id=?
            ''',
            (goal_id,),
        ).fetchone()

        if goal is None:
            raise ValueError(f"Unknown goal: {goal_id}")

        steps = self.conn.execute(
            '''
            SELECT
                id,
                position,
                title,
                status,
                attempts,
                result,
                error,
                started_at,
                completed_at
            FROM goal_steps
            WHERE goal_id=?
            ORDER BY position
            ''',
            (goal_id,),
        ).fetchall()

        return {
            **dict(goal),
            "steps": [dict(step) for step in steps],
        }

    def step(self, goal_id: str, step_id: str) -> dict:
        row = self.conn.execute(
            '''
            SELECT
                id,
                goal_id,
                position,
                title,
                status,
                attempts,
                result,
                error,
                started_at,
                completed_at
            FROM goal_steps
            WHERE id=? AND goal_id=?
            ''',
            (step_id, goal_id),
        ).fetchone()

        if row is None:
            raise ValueError(f"Unknown step: {step_id}")

        return dict(row)

    def claim_next(self, goal_id: str) -> dict | None:
        now = self._now()

        with self.conn:
            goal = self.conn.execute(
                "SELECT status FROM goals WHERE id=?",
                (goal_id,),
            ).fetchone()

            if goal is None:
                raise ValueError(f"Unknown goal: {goal_id}")
            if goal["status"] != GoalStatus.ACTIVE.value:
                raise ValueError("Goal is not active")

            running = self.conn.execute(
                '''
                SELECT id
                FROM goal_steps
                WHERE goal_id=? AND status=?
                ORDER BY position
                LIMIT 1
                ''',
                (goal_id, StepStatus.RUNNING.value),
            ).fetchone()

            if running is not None:
                return self.step(goal_id, running["id"])

            step = self.conn.execute(
                '''
                SELECT id
                FROM goal_steps
                WHERE goal_id=? AND status=?
                ORDER BY position
                LIMIT 1
                ''',
                (goal_id, StepStatus.PENDING.value),
            ).fetchone()

            if step is None:
                self._finish_if_done(goal_id)
                return None

            self.conn.execute(
                '''
                UPDATE goal_steps
                SET status=?,
                    attempts=attempts+1,
                    updated_at=?,
                    started_at=COALESCE(started_at, ?),
                    error=NULL
                WHERE id=? AND status=?
                ''',
                (
                    StepStatus.RUNNING.value,
                    now,
                    now,
                    step["id"],
                    StepStatus.PENDING.value,
                ),
            )
            self.conn.execute(
                "UPDATE goals SET updated_at=? WHERE id=?",
                (now, goal_id),
            )
            self._event(goal_id, step["id"], "claimed", None)

        return self.step(goal_id, step["id"])

    def complete(self, goal_id: str, step_id: str, result: str) -> dict:
        result = result.strip()
        if not result:
            raise ValueError("A concrete result is required")

        now = self._now()

        with self.conn:
            row = self.conn.execute(
                '''
                SELECT status
                FROM goal_steps
                WHERE id=? AND goal_id=?
                ''',
                (step_id, goal_id),
            ).fetchone()

            if row is None:
                raise ValueError(f"Unknown step: {step_id}")
            if row["status"] != StepStatus.RUNNING.value:
                raise ValueError("Step must be running before completion")

            self.conn.execute(
                '''
                UPDATE goal_steps
                SET status=?,
                    result=?,
                    error=NULL,
                    updated_at=?,
                    completed_at=?
                WHERE id=? AND goal_id=?
                ''',
                (
                    StepStatus.COMPLETED.value,
                    result,
                    now,
                    now,
                    step_id,
                    goal_id,
                ),
            )
            self.conn.execute(
                "UPDATE goals SET updated_at=? WHERE id=?",
                (now, goal_id),
            )
            self._event(
                goal_id,
                step_id,
                "completed",
                {"result": result},
            )
            self._finish_if_done(goal_id)

        return self.get(goal_id)

    def fail(
        self,
        goal_id: str,
        step_id: str,
        error: str,
        retry: bool,
    ) -> dict:
        error = error.strip()
        if not error:
            raise ValueError("Failure reason is required")

        now = self._now()
        status = (
            StepStatus.PENDING.value
            if retry
            else StepStatus.FAILED.value
        )

        with self.conn:
            row = self.conn.execute(
                '''
                SELECT status
                FROM goal_steps
                WHERE id=? AND goal_id=?
                ''',
                (step_id, goal_id),
            ).fetchone()

            if row is None:
                raise ValueError(f"Unknown step: {step_id}")
            if row["status"] != StepStatus.RUNNING.value:
                raise ValueError("Step must be running before failure")

            self.conn.execute(
                '''
                UPDATE goal_steps
                SET status=?,
                    error=?,
                    updated_at=?
                WHERE id=? AND goal_id=?
                ''',
                (
                    status,
                    error,
                    now,
                    step_id,
                    goal_id,
                ),
            )
            self.conn.execute(
                "UPDATE goals SET updated_at=? WHERE id=?",
                (now, goal_id),
            )
            self._event(
                goal_id,
                step_id,
                "retry" if retry else "failed",
                {"error": error},
            )
            self._finish_if_done(goal_id)

        return self.get(goal_id)

    def set_status(self, goal_id: str, status: str) -> dict:
        allowed = {
            GoalStatus.ACTIVE.value,
            GoalStatus.PAUSED.value,
            GoalStatus.CANCELLED.value,
        }
        if status not in allowed:
            raise ValueError(f"Invalid goal status: {status}")

        with self.conn:
            result = self.conn.execute(
                '''
                UPDATE goals
                SET status=?, updated_at=?
                WHERE id=?
                ''',
                (status, self._now(), goal_id),
            )
            if result.rowcount != 1:
                raise ValueError(f"Unknown goal: {goal_id}")
            self._event(goal_id, None, "status", {"status": status})

        return self.get(goal_id)

    def context(self, limit: int = 3) -> str:
        goals = self.list(GoalStatus.ACTIVE.value, limit)
        if not goals:
            return "None."

        lines = []
        for goal in goals:
            done = sum(
                step["status"] == StepStatus.COMPLETED.value
                for step in goal["steps"]
            )
            lines.append(
                f"- {goal['id']}: {goal['title']} "
                f"({done}/{len(goal['steps'])} steps)"
            )
        return "\n".join(lines)

    def events(self, goal_id: str, limit: int = 40) -> list[dict]:
        rows = self.conn.execute(
            '''
            SELECT id, step_id, event, payload, created_at
            FROM goal_events
            WHERE goal_id=?
            ORDER BY id DESC
            LIMIT ?
            ''',
            (goal_id, limit),
        ).fetchall()

        result = []
        for row in rows:
            item = dict(row)
            item["payload"] = (
                json.loads(item["payload"])
                if item["payload"]
                else None
            )
            result.append(item)
        return result

    def _finish_if_done(self, goal_id: str):
        failed = self.conn.execute(
            '''
            SELECT COUNT(*) AS count
            FROM goal_steps
            WHERE goal_id=? AND status=?
            ''',
            (goal_id, StepStatus.FAILED.value),
        ).fetchone()["count"]

        open_steps = self.conn.execute(
            '''
            SELECT COUNT(*) AS count
            FROM goal_steps
            WHERE goal_id=? AND status IN (?, ?)
            ''',
            (
                goal_id,
                StepStatus.PENDING.value,
                StepStatus.RUNNING.value,
            ),
        ).fetchone()["count"]

        if failed:
            status = GoalStatus.FAILED.value
        elif open_steps == 0:
            status = GoalStatus.COMPLETED.value
        else:
            return

        self.conn.execute(
            '''
            UPDATE goals
            SET status=?, updated_at=?
            WHERE id=?
            ''',
            (status, self._now(), goal_id),
        )
        self._event(goal_id, None, status, None)

    def _event(
        self,
        goal_id: str,
        step_id: str | None,
        event: str,
        payload: dict | None,
    ):
        self.conn.execute(
            '''
            INSERT INTO goal_events(
                goal_id, step_id, event, payload, created_at
            )
            VALUES (?, ?, ?, ?, ?)
            ''',
            (
                goal_id,
                step_id,
                event,
                json.dumps(payload) if payload else None,
                self._now(),
            ),
        )

    def close(self):
        close_database(self.conn)
