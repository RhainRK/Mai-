from dataclasses import asdict, dataclass


def clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


@dataclass(slots=True)
class RelationshipState:
    subject_id: str = "local:user"
    display_name: str = ""
    role: str = "user"
    familiarity: float = 0.10
    trust: float = 0.10
    warmth: float = 0.30
    respect: float = 0.50
    interaction_count: int = 0

    @classmethod
    def from_dict(cls, data: dict | None):
        if not data:
            return cls()
        allowed = cls.__dataclass_fields__
        return cls(**{key: value for key, value in data.items() if key in allowed})

    def bind_subject(self, *, subject_id: str, display_name: str, role: str) -> None:
        """Bind the private relationship to trusted runtime identity."""
        if subject_id:
            self.subject_id = subject_id
        if display_name:
            self.display_name = display_name
        if role:
            self.role = role

    @property
    def is_creator(self) -> bool:
        return self.role.casefold() == "creator"

    def update(self, user_text: str):
        self.interaction_count += 1
        self.familiarity = clamp(self.familiarity + 0.01)
        text = user_text.casefold()
        if any(term in text for term in ("thank", "appreciate", "proud", "remember")):
            self.warmth = clamp(self.warmth + 0.015)
            self.trust = clamp(self.trust + 0.01)
        if any(term in text for term in ("help me", "what do you think", "advice")):
            self.trust = clamp(self.trust + 0.005)
        if any(term in text for term in ("idiot", "stupid", "shut up")):
            self.warmth = clamp(self.warmth - 0.04)

    def as_prompt(self) -> str:
        identity = (
            f"subject_id={self.subject_id}, display_name={self.display_name or 'unknown'}, "
            f"role={self.role}, current_private_operator_is_creator={str(self.is_creator).lower()}"
        )
        return (
            f"{identity}; familiarity={self.familiarity:.2f}, trust={self.trust:.2f}, "
            f"warmth={self.warmth:.2f}, respect={self.respect:.2f}, "
            f"interactions={self.interaction_count}"
        )

    def to_dict(self):
        return asdict(self)
