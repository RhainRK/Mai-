from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any, Callable

from pydantic import BaseModel, ConfigDict


class ToolArgs(BaseModel):
    model_config = ConfigDict(extra="forbid")


class EmptyArgs(ToolArgs):
    pass


class ToolPermission(str, Enum):
    READ = "read"
    STATE_WRITE = "state_write"
    EXTERNAL_PROCESS = "external_process"


@dataclass(frozen=True, slots=True)
class ToolCall:
    call_id: str
    name: str
    arguments: dict[str, Any]
    parse_error: str | None = None


@dataclass(frozen=True, slots=True)
class ToolResult:
    name: str
    success: bool
    output: Any = None
    error: str | None = None

    def as_message_payload(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ToolDefinition:
    name: str
    description: str
    args_model: type[ToolArgs]
    handler: Callable[[ToolArgs], Any]
    permission: ToolPermission = ToolPermission.READ
    enabled: Callable[[], bool] | None = None

    def available(self) -> bool:
        return self.enabled() if self.enabled else True

    def schema(self) -> dict[str, Any]:
        parameters = self.args_model.model_json_schema()
        parameters.pop("title", None)
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": parameters,
                "strict": True,
            },
        }
