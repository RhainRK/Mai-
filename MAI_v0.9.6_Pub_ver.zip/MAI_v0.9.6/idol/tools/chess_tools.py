from __future__ import annotations

from pydantic import Field

from .base import EmptyArgs, ToolArgs, ToolDefinition, ToolPermission


class MoveArgs(ToolArgs):
    move: str = Field(min_length=2, max_length=12)


def register_chess_tools(registry, chess_skill):
    if chess_skill is None:
        return

    registry.register(
        ToolDefinition(
            "chess.new_game",
            "Start a new standard chess game.",
            EmptyArgs,
            lambda _: chess_skill.new_game(),
            ToolPermission.STATE_WRITE,
        )
    )
    registry.register(
        ToolDefinition(
            "chess.get_state",
            "Read the current chess position and legal moves.",
            EmptyArgs,
            lambda _: chess_skill.state(),
            ToolPermission.READ,
        )
    )
    registry.register(
        ToolDefinition(
            "chess.play_move",
            "Play one legal SAN or UCI move.",
            MoveArgs,
            lambda args: chess_skill.play(args.move),
            ToolPermission.STATE_WRITE,
        )
    )
    registry.register(
        ToolDefinition(
            "chess.engine_hint",
            "Get an engine candidate move when analysis is requested.",
            EmptyArgs,
            lambda _: chess_skill.hint(),
            ToolPermission.EXTERNAL_PROCESS,
            chess_skill.engine_available,
        )
    )
    registry.register(
        ToolDefinition(
            "chess.engine_analyse",
            "Analyse the current position when analysis is requested.",
            EmptyArgs,
            lambda _: chess_skill.analyse(),
            ToolPermission.EXTERNAL_PROCESS,
            chess_skill.engine_available,
        )
    )
