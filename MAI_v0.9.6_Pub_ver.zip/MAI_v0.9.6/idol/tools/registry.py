from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from pydantic import ValidationError

from .audit import ToolAuditLog
from .base import ToolCall, ToolDefinition, ToolPermission, ToolResult


class ToolRegistry:
    def __init__(
        self,
        audit_log: ToolAuditLog,
        allowed_permissions: Iterable[ToolPermission] | None = None,
    ):
        self.audit_log = audit_log
        self.allowed_permissions = set(
            allowed_permissions if allowed_permissions is not None else (
                ToolPermission.READ,
                ToolPermission.STATE_WRITE,
                ToolPermission.EXTERNAL_PROCESS,
            )
        )
        self._tools: dict[str, ToolDefinition] = {}

    def register(self, tool: ToolDefinition):
        if tool.name in self._tools:
            raise ValueError(f"Tool already registered: {tool.name}")
        self._tools[tool.name] = tool

    def schemas(self, prefixes: tuple[str, ...] | None = None) -> list[dict[str, Any]]:
        return [
            tool.schema()
            for name, tool in self._tools.items()
            if tool.available()
            and (
                not prefixes
                or any(name.startswith(prefix) for prefix in prefixes)
            )
        ]

    def names(self, prefixes: tuple[str, ...] | None = None) -> list[str]:
        return [
            name
            for name, tool in self._tools.items()
            if tool.available()
            and (
                not prefixes
                or any(name.startswith(prefix) for prefix in prefixes)
            )
        ]

    def execute(self, call: ToolCall) -> ToolResult:
        if call.parse_error:
            return self._error(call, call.parse_error)

        tool = self._tools.get(call.name)
        if tool is None or not tool.available():
            return self._error(call, f"Unavailable tool: {call.name}")

        if tool.permission not in self.allowed_permissions:
            return self._error(
                call,
                f"Permission denied: {tool.permission.value}",
            )

        try:
            args = tool.args_model.model_validate(call.arguments)
            output = tool.handler(args)
            result = ToolResult(
                name=call.name,
                success=True,
                output=output,
            )
            self.audit_log.record(
                call.name,
                call.arguments,
                True,
                output=output,
            )
            return result
        except (ValidationError, ValueError, RuntimeError) as exc:
            return self._error(call, str(exc))
        except Exception as exc:
            return self._error(
                call,
                f"{type(exc).__name__}: {exc}",
            )

    def _error(self, call: ToolCall, error: str) -> ToolResult:
        result = ToolResult(
            name=call.name,
            success=False,
            error=error,
        )
        self.audit_log.record(
            call.name,
            call.arguments,
            False,
            error=error,
        )
        return result
