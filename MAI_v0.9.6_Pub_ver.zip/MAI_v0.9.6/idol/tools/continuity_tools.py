from __future__ import annotations

from typing import Literal

from pydantic import Field

from .base import ToolArgs, ToolDefinition, ToolPermission


class CommitContinuityArgs(ToolArgs):
    memory_type: Literal["semantic", "preference", "creative"]
    key: str = Field(min_length=3, max_length=120)
    content: str = Field(min_length=2, max_length=1200)
    reason: str = Field(default="", max_length=800)
    visibility: Literal["public", "private", "internal"] = "private"
    confidence: float = Field(default=0.9, ge=0.0, le=1.0)
    importance: float = Field(default=0.85, ge=0.0, le=1.0)


class ReadContinuityArgs(ToolArgs):
    memory_type: Literal["episodic", "semantic", "preference", "creative", "relationship", "working"] | None = None
    limit: int = Field(default=20, ge=1, le=100)


class ContinuityHistoryArgs(ToolArgs):
    key: str = Field(min_length=3, max_length=120)
    memory_type: Literal["episodic", "semantic", "preference", "creative", "relationship", "working"] | None = None


def register_continuity_tools(registry, continuity):
    registry.register(
        ToolDefinition(
            "continuity.commit",
            (
                "Commit a settled, durable MAI fact, preference, or creative decision. "
                "Use only after the user and MAI have clearly settled the point; do not store brainstorming, "
                "temporary possibilities, or unsupported claims. Reusing the same key supersedes the old value "
                "while preserving its history."
            ),
            CommitContinuityArgs,
            lambda args: continuity.set_current(
                args.memory_type,
                args.key,
                args.content,
                visibility=args.visibility,
                confidence=args.confidence,
                importance=args.importance,
                source="mai_tool",
                reason=args.reason,
            ),
            ToolPermission.STATE_WRITE,
        )
    )
    registry.register(
        ToolDefinition(
            "continuity.current",
            "Read MAI's current durable continuity records.",
            ReadContinuityArgs,
            lambda args: continuity.current(args.memory_type, limit=args.limit),
            ToolPermission.READ,
        )
    )
    registry.register(
        ToolDefinition(
            "continuity.history",
            "Read the version history for one MAI continuity key, including superseded decisions.",
            ContinuityHistoryArgs,
            lambda args: continuity.history(args.key, memory_type=args.memory_type),
            ToolPermission.READ,
        )
    )
