from __future__ import annotations

from pydantic import Field

from .base import EmptyArgs, ToolArgs, ToolDefinition, ToolPermission


class TeachArgs(ToolArgs):
    skill: str = Field(min_length=1, max_length=60)
    content: str = Field(min_length=2, max_length=1000)
    confidence: float = Field(ge=0.0, le=1.0)


class SkillArgs(ToolArgs):
    skill: str = Field(min_length=1, max_length=60)


class PracticeArgs(ToolArgs):
    skill: str = Field(min_length=1, max_length=60)
    task: str = Field(min_length=1, max_length=500)
    result: str = Field(min_length=1, max_length=1000)
    score: float | None
    feedback: str = Field(max_length=1000)


def register_learning_tools(registry, learning):
    registry.register(
        ToolDefinition(
            "learning.teach",
            "Store a durable lesson for a skill.",
            TeachArgs,
            lambda args: learning.teach(
                args.skill,
                args.content,
                args.confidence,
            ),
            ToolPermission.STATE_WRITE,
        )
    )
    registry.register(
        ToolDefinition(
            "learning.get_skill",
            "Read stored lessons, practice and mastery for a skill.",
            SkillArgs,
            lambda args: learning.skill(args.skill)
            or {
                "name": args.skill,
                "mastery": 0.0,
                "lessons": [],
                "practice": [],
            },
            ToolPermission.READ,
        )
    )
    registry.register(
        ToolDefinition(
            "learning.list_skills",
            "List learned skills and mastery estimates.",
            EmptyArgs,
            lambda _: learning.list_skills(),
            ToolPermission.READ,
        )
    )
    registry.register(
        ToolDefinition(
            "learning.record_practice",
            "Record an evaluated practice attempt.",
            PracticeArgs,
            lambda args: (
                learning.record_practice(
                    args.skill,
                    args.task,
                    args.result,
                    args.score,
                    args.feedback,
                )
                or {
                    "recorded": True,
                    "skill": args.skill,
                    "mastery": (
                        learning.skill(args.skill) or {"mastery": 0.0}
                    )["mastery"],
                }
            ),
            ToolPermission.STATE_WRITE,
        )
    )
