from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import re
import sqlite3
from typing import Any

from ..database import close_database, connect_database

_SECRET_KEY_RE = re.compile(
    r"(?:password|passwd|secret|token|api[_-]?key|authorization|cookie|session|private[_-]?key)",
    re.IGNORECASE,
)


def _redact_for_log(value: Any, *, key: str = "") -> Any:
    """Recursively redact common credential fields before persistence."""
    if key and _SECRET_KEY_RE.search(key):
        return "[REDACTED]"
    if isinstance(value, dict):
        return {str(k): _redact_for_log(v, key=str(k)) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_redact_for_log(item) for item in value]
    return value


class ToolAuditLog:
    def __init__(self, db_path: str):
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = connect_database(db_path, timeout=5.0)
        self._setup()

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def _setup(self):
        with self.conn:
            self.conn.execute(
                '''
                CREATE TABLE IF NOT EXISTS tool_runs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tool_name TEXT NOT NULL,
                    arguments_json TEXT NOT NULL,
                    success INTEGER NOT NULL,
                    output_json TEXT,
                    error TEXT,
                    created_at TEXT NOT NULL
                )
                '''
            )
            self.conn.execute(
                '''
                CREATE INDEX IF NOT EXISTS idx_tool_runs_created_at
                ON tool_runs(created_at DESC)
                '''
            )

    def record(
        self,
        tool_name: str,
        arguments: dict[str, Any],
        success: bool,
        output: Any = None,
        error: str | None = None,
    ):
        with self.conn:
            self.conn.execute(
                '''
                INSERT INTO tool_runs(
                    tool_name,
                    arguments_json,
                    success,
                    output_json,
                    error,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                ''',
                (
                    tool_name,
                    json.dumps(_redact_for_log(arguments), ensure_ascii=False, default=str),
                    int(success),
                    json.dumps(_redact_for_log(output), ensure_ascii=False, default=str)
                    if output is not None
                    else None,
                    error,
                    self._now(),
                ),
            )

    def recent(self, limit: int = 30) -> list[dict]:
        rows = self.conn.execute(
            '''
            SELECT
                id,
                tool_name,
                arguments_json,
                success,
                output_json,
                error,
                created_at
            FROM tool_runs
            ORDER BY id DESC
            LIMIT ?
            ''',
            (limit,),
        ).fetchall()

        result = []
        for row in rows:
            result.append(
                {
                    "id": row["id"],
                    "tool": row["tool_name"],
                    "arguments": json.loads(row["arguments_json"]),
                    "success": bool(row["success"]),
                    "output": json.loads(row["output_json"])
                    if row["output_json"]
                    else None,
                    "error": row["error"],
                    "created_at": row["created_at"],
                }
            )
        return result

    def close(self):
        close_database(self.conn)
