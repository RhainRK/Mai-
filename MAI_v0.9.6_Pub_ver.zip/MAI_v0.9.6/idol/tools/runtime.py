from __future__ import annotations

from ..llm import LLMError
from ..replies import sanitize_visible_text
from .registry import ToolRegistry
from .base import ToolResult


_FINAL_SYNTHESIS = {
    "role": "system",
    "content": (
        "Return the final user-facing answer now. Base it on the tool results above. "
        "Do not call more tools, do not describe hidden reasoning, and do not return an empty response."
    ),
}


class ToolRuntime:
    def __init__(
        self,
        llm,
        registry: ToolRegistry,
        max_steps: int = 8,
        fallback_to_chat: bool = True,
    ):
        self.llm = llm
        self.registry = registry
        self.max_steps = max_steps
        self.fallback_to_chat = fallback_to_chat

    def _synthesize_final(self, working: list[dict], original: list[dict]) -> str:
        try:
            response = self.llm.generate(
                [*working, _FINAL_SYNTHESIS],
                tools=None,
            )
            final = sanitize_visible_text(response.content)
        except LLMError:
            final = ""
        if final:
            return final
        if self.fallback_to_chat:
            try:
                fallback = sanitize_visible_text(self.llm.chat([*original, _FINAL_SYNTHESIS]))
            except LLMError:
                fallback = ""
            if fallback:
                return fallback
        return "I completed the tool step, but I couldn't produce a reliable final answer."

    def run(
        self,
        messages: list[dict],
        prefixes: tuple[str, ...] | None = None,
        observer=None,
    ) -> str:
        tools = self.registry.schemas(prefixes)

        if not tools:
            return sanitize_visible_text(self.llm.chat(messages))

        working = list(messages)
        used_tool = False

        for step in range(self.max_steps):
            try:
                response = self.llm.generate(working, tools=tools)
            except LLMError:
                if step == 0 and self.fallback_to_chat:
                    return sanitize_visible_text(self.llm.chat(messages))
                raise

            if not response.tool_calls:
                content = sanitize_visible_text(response.content)
                if content:
                    return content
                if used_tool:
                    return self._synthesize_final(working, messages)
                if self.fallback_to_chat:
                    fallback = sanitize_visible_text(self.llm.chat(messages))
                    if fallback:
                        return fallback
                return self._synthesize_final(working, messages)

            used_tool = True
            working.append(self.llm.assistant_tool_message(response))

            for call in response.tool_calls:
                allowed_names = {item['function']['name'] for item in tools}
                result = (
                    self.registry.execute(call) if call.name in allowed_names else
                    ToolResult(name=call.name, success=False, error='Tool not enabled for this turn')
                )
                if observer is not None:
                    try:
                        observer(call, result)
                    except Exception:
                        # Telemetry isolation
                        pass
                working.append(self.llm.tool_result_message(call, result))

        return self._synthesize_final(working, messages)
