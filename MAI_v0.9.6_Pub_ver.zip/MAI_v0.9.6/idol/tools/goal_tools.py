from __future__ import annotations

from typing import Literal

from pydantic import Field

from .base import ToolArgs, ToolDefinition, ToolPermission


class CreateGoalArgs(ToolArgs):
    title: str = Field(min_length=3, max_length=120)
    outcome: str = Field(min_length=3, max_length=500)
    steps: list[str] = Field(min_length=2, max_length=10)
    priority: int = Field(ge=1, le=5)


class GoalArgs(ToolArgs):
    goal_id: str = Field(min_length=8, max_length=64)


class ListGoalsArgs(ToolArgs):
    status: Literal[
        "active",
        "paused",
        "completed",
        "failed",
        "cancelled",
        "all",
    ]


class CompleteStepArgs(ToolArgs):
    goal_id: str = Field(min_length=8, max_length=64)
    step_id: str = Field(min_length=8, max_length=64)
    result: str = Field(min_length=1, max_length=2000)


class FailStepArgs(ToolArgs):
    goal_id: str = Field(min_length=8, max_length=64)
    step_id: str = Field(min_length=8, max_length=64)
    error: str = Field(min_length=1, max_length=1000)
    retry: bool


class GoalStatusArgs(ToolArgs):
    goal_id: str = Field(min_length=8, max_length=64)
    status: Literal[
        "active",
        "paused",
        "cancelled",
    ]


def register_goal_tools(registry, tasks):
    registry.register(
        ToolDefinition(
            "goals.create",
            "Create a durable multi-step goal.",
            CreateGoalArgs,
            lambda args: tasks.create(
                args.title,
                args.outcome,
                args.steps,
                args.priority,
            ),
            ToolPermission.STATE_WRITE,
        )
    )
    registry.register(
        ToolDefinition(
            "goals.list",
            "List durable goals.",
            ListGoalsArgs,
            lambda args: tasks.list(args.status),
            ToolPermission.READ,
        )
    )
    registry.register(
        ToolDefinition(
            "goals.get",
            "Read a goal and its steps.",
            GoalArgs,
            lambda args: tasks.get(args.goal_id),
            ToolPermission.READ,
        )
    )
    registry.register(
        ToolDefinition(
            "goals.next_step",
            "Claim the next pending step of an active goal.",
            GoalArgs,
            lambda args: tasks.claim_next(args.goal_id),
            ToolPermission.STATE_WRITE,
        )
    )
    registry.register(
        ToolDefinition(
            "goals.complete_step",
            "Mark a goal step complete with a concrete result.",
            CompleteStepArgs,
            lambda args: tasks.complete(
                args.goal_id,
                args.step_id,
                args.result,
            ),
            ToolPermission.STATE_WRITE,
        )
    )
    registry.register(
        ToolDefinition(
            "goals.fail_step",
            "Record a failed step or return it to pending.",
            FailStepArgs,
            lambda args: tasks.fail(
                args.goal_id,
                args.step_id,
                args.error,
                args.retry,
            ),
            ToolPermission.STATE_WRITE,
        )
    )
    registry.register(
        ToolDefinition(
            "goals.set_status",
            "Pause, resume, complete, fail or cancel a goal.",
            GoalStatusArgs,
            lambda args: tasks.set_status(
                args.goal_id,
                args.status,
            ),
            ToolPermission.STATE_WRITE,
        )
    )
