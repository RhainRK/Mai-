from __future__ import annotations

from datetime import datetime, timezone
import json
import re
import sqlite3
from typing import Any
from uuid import uuid4

from .database import close_database, connect_database


_TOKEN_RE = re.compile(r"[A-Za-z0-9']+")


class CareerStore:
    """Persistent artist canon and career history."""

    def __init__(self, db_path: str):
        self.conn = connect_database(db_path, timeout=30.0)
        self._setup()

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def _setup(self):
        with self.conn:
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS mai_canon (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    category TEXT NOT NULL DEFAULT 'identity',
                    visibility TEXT NOT NULL DEFAULT 'public',
                    locked INTEGER NOT NULL DEFAULT 1,
                    source TEXT NOT NULL DEFAULT 'creator',
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS career_events (
                    id TEXT PRIMARY KEY,
                    event_type TEXT NOT NULL,
                    title TEXT NOT NULL,
                    summary TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'confirmed',
                    visibility TEXT NOT NULL DEFAULT 'public',
                    occurred_at TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    tags_json TEXT NOT NULL DEFAULT '[]',
                    metadata_json TEXT NOT NULL DEFAULT '{}'
                );

                CREATE INDEX IF NOT EXISTS idx_career_events_time
                    ON career_events(occurred_at DESC, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_career_events_type
                    ON career_events(event_type, status);
                CREATE INDEX IF NOT EXISTS idx_mai_canon_visibility
                    ON mai_canon(visibility, category);
                """
            )

    def seed_identity(self, identity) -> None:
        """Synchronise authoritative identity canon into SQLite."""
        rows = identity.canon("internal")
        now = self._now()
        desired_keys = {
            str(item.get("key", "")).strip()
            for item in rows
            if str(item.get("key", "")).strip()
        }

        with self.conn:
            # Identity canon cleanup
            if desired_keys:
                placeholders = ",".join("?" for _ in desired_keys)
                self.conn.execute(
                    f"""
                    DELETE FROM mai_canon
                    WHERE source LIKE 'identity_file:%'
                      AND key NOT IN ({placeholders})
                    """,
                    tuple(sorted(desired_keys)),
                )
            else:
                self.conn.execute(
                    "DELETE FROM mai_canon WHERE source LIKE 'identity_file:%'"
                )

            for item in rows:
                key = str(item.get("key", "")).strip()
                value = str(item.get("value", "")).strip()
                if not key or not value:
                    continue
                original_source = str(item.get("source", "identity")).strip() or "identity"
                source = f"identity_file:{original_source}"
                self.conn.execute(
                    """
                    INSERT INTO mai_canon(
                        key, value, category, visibility, locked, source, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(key) DO UPDATE SET
                        value=excluded.value,
                        category=excluded.category,
                        visibility=excluded.visibility,
                        locked=excluded.locked,
                        source=excluded.source,
                        updated_at=excluded.updated_at
                    """,
                    (
                        key,
                        value,
                        str(item.get("category", "identity")),
                        str(item.get("visibility", "public")).casefold(),
                        int(bool(item.get("locked", True))),
                        source,
                        now,
                    ),
                )

    def set_canon(
        self,
        key: str,
        value: str,
        *,
        category: str = "identity",
        visibility: str = "public",
        locked: bool = True,
        source: str = "creator",
        overwrite: bool = False,
    ) -> dict[str, Any]:
        key, value = key.strip(), value.strip()
        if not key or not value:
            raise ValueError("Canon key and value are required")
        visibility = visibility.casefold()
        if visibility not in {"public", "private", "internal"}:
            raise ValueError("visibility must be public, private, or internal")

        existing = self.conn.execute(
            "SELECT * FROM mai_canon WHERE key=?", (key,)
        ).fetchone()
        if existing is not None and int(existing["locked"]) and overwrite:
            raise ValueError(f"Canon fact is locked: {key}")

        now = self._now()
        with self.conn:
            if overwrite:
                self.conn.execute(
                    """
                    INSERT INTO mai_canon(key, value, category, visibility, locked, source, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(key) DO UPDATE SET
                        value=excluded.value,
                        category=excluded.category,
                        visibility=excluded.visibility,
                        locked=excluded.locked,
                        source=excluded.source,
                        updated_at=excluded.updated_at
                    """,
                    (key, value, category, visibility, int(locked), source, now),
                )
            else:
                self.conn.execute(
                    """
                    INSERT OR IGNORE INTO mai_canon(
                        key, value, category, visibility, locked, source, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (key, value, category, visibility, int(locked), source, now),
                )
        return self.get_canon(key)

    def get_canon(self, key: str) -> dict[str, Any]:
        row = self.conn.execute("SELECT * FROM mai_canon WHERE key=?", (key,)).fetchone()
        if row is None:
            raise ValueError(f"Unknown canon key: {key}")
        result = dict(row)
        result["locked"] = bool(result["locked"])
        return result

    def canon(self, audience: str = "internal", limit: int = 100) -> list[dict[str, Any]]:
        if audience.casefold() == "public":
            rows = self.conn.execute(
                """
                SELECT * FROM mai_canon
                WHERE visibility='public'
                ORDER BY category, key
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM mai_canon ORDER BY category, key LIMIT ?", (limit,)
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["locked"] = bool(item["locked"])
            result.append(item)
        return result

    def record_event(
        self,
        event_type: str,
        title: str,
        summary: str,
        *,
        status: str = "confirmed",
        visibility: str = "public",
        occurred_at: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        event_type, title, summary = event_type.strip(), title.strip(), summary.strip()
        if not event_type or not title or not summary:
            raise ValueError("event_type, title, and summary are required")
        visibility = visibility.casefold()
        if visibility not in {"public", "private", "internal"}:
            raise ValueError("visibility must be public, private, or internal")
        event_id = f"evt_{uuid4().hex[:12]}"
        now = self._now()
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO career_events(
                    id, event_type, title, summary, status, visibility,
                    occurred_at, created_at, tags_json, metadata_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    event_id,
                    event_type,
                    title,
                    summary,
                    status,
                    visibility,
                    occurred_at or now,
                    now,
                    json.dumps(tags or [], ensure_ascii=False),
                    json.dumps(metadata or {}, ensure_ascii=False),
                ),
            )
        return self.get_event(event_id)

    def get_event(self, event_id: str) -> dict[str, Any]:
        row = self.conn.execute("SELECT * FROM career_events WHERE id=?", (event_id,)).fetchone()
        if row is None:
            raise ValueError(f"Unknown career event: {event_id}")
        return self._event_dict(row)

    @staticmethod
    def _event_dict(row: sqlite3.Row) -> dict[str, Any]:
        item = dict(row)
        item["tags"] = json.loads(item.pop("tags_json") or "[]")
        item["metadata"] = json.loads(item.pop("metadata_json") or "{}")
        return item

    def timeline(self, limit: int = 20, audience: str = "internal") -> list[dict[str, Any]]:
        if audience.casefold() == "public":
            rows = self.conn.execute(
                """
                SELECT * FROM career_events
                WHERE visibility='public' AND status='confirmed'
                ORDER BY occurred_at DESC, created_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        else:
            rows = self.conn.execute(
                """
                SELECT * FROM career_events
                ORDER BY occurred_at DESC, created_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [self._event_dict(row) for row in rows]

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return {token.casefold() for token in _TOKEN_RE.findall(text) if len(token) > 2}

    def context_with_refs(
        self,
        query: str,
        audience: str = "internal",
        event_limit: int = 6,
    ) -> tuple[str, list[str], list[str]]:
        """Return prompt context plus observable canon/event identifiers for tracing."""
        # Career canon projection
        canon_rows = [
            row
            for row in self.canon(audience, 100)
            if not str(row.get("source", "")).startswith("identity_file:")
        ][:30]
        canon_text = "\n".join(
            f"- {row['key']}: {row['value']}" for row in canon_rows
        ) or "None."

        events = self.timeline(60, audience)
        query_tokens = self._tokens(query)
        scored: list[tuple[int, str, dict[str, Any]]] = []
        for event in events:
            haystack = " ".join(
                [
                    event["event_type"],
                    event["title"],
                    event["summary"],
                    " ".join(event["tags"]),
                ]
            )
            overlap = len(query_tokens & self._tokens(haystack))
            scored.append((overlap, event["occurred_at"], event))
        scored.sort(key=lambda item: (item[0], item[1]), reverse=True)
        selected = [event for _, _, event in scored[:event_limit]]
        event_text = "\n".join(
            f"- [{event['occurred_at'][:10]} | {event['event_type']}] "
            f"{event['title']}: {event['summary']}"
            for event in selected
        ) or "None yet."
        context = f"ADDITIONAL CAREER CANON\n{canon_text}\n\nCAREER HISTORY\n{event_text}"
        return (
            context,
            [str(row["key"]) for row in canon_rows],
            [str(event["id"]) for event in selected],
        )

    def context(self, query: str, audience: str = "internal", event_limit: int = 6) -> str:
        context, _, _ = self.context_with_refs(query, audience, event_limit)
        return context

    def stats(self) -> dict[str, int]:
        canon = self.conn.execute("SELECT COUNT(*) FROM mai_canon").fetchone()[0]
        events = self.conn.execute("SELECT COUNT(*) FROM career_events").fetchone()[0]
        return {"canon_facts": int(canon), "career_events": int(events)}

    def close(self):
        close_database(self.conn)
