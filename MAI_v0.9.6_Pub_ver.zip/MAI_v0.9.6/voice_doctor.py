from __future__ import annotations

import importlib
import platform
import subprocess

from config import settings
from idol.version import __version__


def package(name: str) -> bool:
    try:
        importlib.import_module(name)
        return True
    except Exception:
        return False


def windows_speech() -> bool:
    if platform.system() != "Windows":
        return False
    script = (
        "Add-Type -AssemblyName System.Speech; "
        "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        "$n=$s.GetInstalledVoices().Count; $s.Dispose(); "
        "if($n -gt 0){exit 0}else{exit 1}"
    )
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True,
            text=True,
            check=False,
            timeout=30.0,
        )
    except (subprocess.TimeoutExpired, OSError):
        return False
    return result.returncode == 0


def main() -> int:
    print(f"MAI v{__version__} voice diagnostics")
    print(f"Platform: {platform.platform()}")
    print()
    sound = package("sounddevice")
    whisper = package("faster_whisper")
    windows = windows_speech()
    eleven = bool(settings.elevenlabs_api_key and settings.elevenlabs_voice_id)

    backend = settings.voice_tts_backend
    if backend == "auto":
        backend = "elevenlabs" if eleven else "windows"
    tts_ready = eleven if backend == "elevenlabs" else windows if backend == "windows" else True

    print(f"{'OK' if sound else 'MISSING':7} microphone  sounddevice")
    print(f"{'OK' if whisper else 'MISSING':7} STT         faster-whisper")
    if backend == "elevenlabs":
        print(f"{'OK' if eleven else 'MISSING':7} TTS         ElevenLabs / {settings.elevenlabs_model}")
    elif backend == "http":
        print(f"INFO    TTS         HTTP / {settings.voice_tts_model}")
    else:
        print(f"{'OK' if windows else 'MISSING':7} TTS         Windows speech")

    if sound:
        try:
            import sounddevice as sd
            devices = sd.query_devices()
            inputs = [d for d in devices if d.get("max_input_channels", 0) > 0]
            outputs = [d for d in devices if d.get("max_output_channels", 0) > 0]
            print(f"OK      devices     {len(inputs)} input / {len(outputs)} output")
        except Exception as exc:
            print(f"WARN    devices     {exc}")
    print()
    if sound and whisper and tts_ready:
        print("VOICE READY: run /voice-test, then /mic-test or /realtime.")
        return 0
    if backend == "elevenlabs" and not eleven:
        print("VOICE NOT READY: set MAI_ELEVENLABS_API_KEY and select a MAI voice.")
    else:
        print("VOICE NOT READY: run install_voice.bat and try again.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
