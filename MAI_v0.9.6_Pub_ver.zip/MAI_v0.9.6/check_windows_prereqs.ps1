$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot

Write-Host "MAI Windows prerequisite check"
Write-Host "=============================="
Write-Host ""

if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3.11 --version
    if ($LASTEXITCODE -eq 0) { Write-Host "OK      Python 3.11" }
    else { Write-Host "MISSING Python 3.11" }
} else {
    Write-Host "MISSING Python launcher / Python 3.11"
}

if (Get-Command git -ErrorAction SilentlyContinue) {
    Write-Host "OK      Git"
    git --version
} else {
    Write-Host "OPTION  Git not found (needed for later external repositories such as CosyVoice)"
}

if (Get-Command ollama -ErrorAction SilentlyContinue) {
    Write-Host "OK      Ollama"
    ollama --version
    ollama list
} else {
    Write-Host "MISSING Ollama"
}

Write-Host ""
if (Get-Command nvidia-smi -ErrorAction SilentlyContinue) {
    Write-Host "NVIDIA GPU detected:"
    nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader
} else {
    Write-Host "INFO    nvidia-smi not found. CPU mode is supported for the baseline build."
}
