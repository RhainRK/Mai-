@echo off
if not exist ".venv\Scripts\python.exe" exit /b 1
".venv\Scripts\python.exe" model_switch.py auto
pause
