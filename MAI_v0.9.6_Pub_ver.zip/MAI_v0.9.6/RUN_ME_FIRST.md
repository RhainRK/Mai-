# MAI v0.9.2 first run

## Fresh Windows install

Read `SETUP_WINDOWS_STEP_BY_STEP.md`. The supported baseline is Python 3.11, Ollama, and `qwen3.5:4b`.

Fast path:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup_windows.ps1
.\install_memory.bat
.\install_voice.bat
.\start_mai.bat
```

The setup script now explicitly creates `.venv` with Python 3.11 and pulls `qwen3.5:4b`.

## Upgrade / existing memory

1. Keep the previous MAI folder as a backup.
2. Extract v0.9.2 into a separate folder.
3. Copy your previous `.env` only if you know which local settings you want to preserve; compare it with the new `.env.example`.
4. MAI's default database is `data/idol_memory.sqlite3`. To keep existing MAI memories, copy the previous database into that path while both copies of MAI are closed.
5. Run `.\.venv\Scripts\python.exe doctor.py`.
6. Run `.\.venv\Scripts\python.exe smoke_test.py`.
7. Start with `.\start_mai.bat`.
8. Test ordinary conversation, then `/trace`, `/memory-map`, and `/continuity-stats`.

The continuity schema is migration-safe and is added alongside existing tables. It does not require deleting ordinary chat memory.

MAI automatically prefers `qwen3.5:4b` and retains `qwen3:4b` as a fallback. Manual Qwen3.6 profiles remain available for substantially larger hardware.

## Avatar

For the optional VRM talking-avatar setup, follow `AVATAR_SETUP.md` after MAI voice works.
