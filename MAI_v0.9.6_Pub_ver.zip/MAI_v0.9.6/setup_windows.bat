@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_windows.ps1"
if errorlevel 1 (
    echo.
    echo Setup did not complete successfully. Read the error above.
    pause
    exit /b 1
)
pause
