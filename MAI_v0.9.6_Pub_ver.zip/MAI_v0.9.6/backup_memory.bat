@echo off
if not exist "data\idol_memory.sqlite3" (
    echo No MAI memory database exists yet.
    pause
    exit /b 0
)
if not exist "backups" mkdir "backups"
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set stamp=%%i
copy /y "data\idol_memory.sqlite3" "backups\idol_memory_%stamp%.sqlite3" >nul
if errorlevel 1 (
    echo Backup failed.
    pause
    exit /b 1
)
echo Memory backed up to backups\idol_memory_%stamp%.sqlite3
pause
