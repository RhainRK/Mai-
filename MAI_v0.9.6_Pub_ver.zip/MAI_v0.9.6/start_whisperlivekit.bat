@echo off
cd /d "%~dp0"
if not exist ".venv-wlk\Scripts\wlk.exe" (
    echo WhisperLiveKit environment not found.
    echo Run install_whisperlivekit.ps1 first.
    pause
    exit /b 1
)
echo Starting WhisperLiveKit on ws://127.0.0.1:8000/asr
echo Keep this window open while using MAI realtime mode.
echo.
".venv-wlk\Scripts\wlk.exe" --host 127.0.0.1 --port 8000 --model base --language en --pcm-input
pause
