from __future__ import annotations

import importlib
import json
from pathlib import Path
import platform
import sys

from config import settings
from idol.database import database_health
from idol.identity import IdentityStore
from idol.model_selection import resolve_ollama_model
from idol.version import __version__


BASE_CORE = (
    "httpx",
    "numpy",
    "pydantic",
    "pydantic_settings",
)

OPTIONAL = {
    "semantic memory": "sentence_transformers",
    "chess": "chess",
    "microphone": "sounddevice",
    "speech recognition": "faster_whisper",
    "realtime STT": "websockets",
}


def mark(ok: bool) -> str:
    return "OK" if ok else "MISSING"


def package_check(name: str) -> bool:
    try:
        importlib.import_module(name)
        return True
    except Exception:
        return False


def _json_ok(path: Path) -> bool:
    try:
        json.loads(path.read_text(encoding="utf-8"))
        return True
    except (OSError, json.JSONDecodeError):
        return False


def main() -> int:
    print(f"MAI v{__version__} diagnostics")
    print(f"Python: {platform.python_version()}")
    python_supported = sys.version_info >= (3, 11)
    python_baseline = sys.version_info[:2] == (3, 11)
    print(f"{mark(python_supported):7} runtime   Python >= 3.11")
    if python_supported and not python_baseline:
        print("WARN    runtime   MAI Windows setup standardizes on Python 3.11 for ecosystem compatibility.")
    print(f"Platform: {platform.platform()}")
    print(f"Backend: {settings.llm_backend}")
    print()

    required = [*BASE_CORE]
    required.append("ollama" if settings.llm_backend == "ollama" else "openai")
    core_ok = True
    for package in required:
        ok = package_check(package)
        core_ok &= ok
        print(f"{mark(ok):7} core      {package}")

    print()
    for label, package in OPTIONAL.items():
        ok = package_check(package)
        print(f"{mark(ok):7} optional  {label}")

    backend_ok = False
    if settings.llm_backend == "ollama":
        try:
            from idol.model_selection import installed_ollama_models

            models = installed_ollama_models(settings.ollama_url)
            print(f"OK      service   Ollama {settings.ollama_url}")
            selection = resolve_ollama_model(
                settings.ollama_url,
                settings.ollama_model,
                settings.ollama_preferred_model,
                settings.ollama_fallback_model,
                installed=models,
            )
            backend_ok = selection.selected_available
            print(f"{mark(backend_ok):7} model     {selection.selected}")
            if settings.ollama_model.casefold() == "auto":
                print("INFO    model     auto selection")
            if not backend_ok:
                print(f"Run: ollama pull {selection.selected}")
            if not selection.preferred_available:
                print(f"OPTION  upgrade   ollama pull {settings.ollama_preferred_model}")
        except Exception as exc:
            print(f"MISSING service   Ollama {settings.ollama_url}")
            print(f"          {exc}")
    else:
        backend_ok = bool(settings.api_base_url and settings.api_model)
        print(f"{mark(backend_ok):7} service   OpenAI-compatible {settings.api_base_url}")
        print(f"INFO    model     {settings.api_model}")

    context = (
        "Ollama/model default"
        if settings.ollama_num_ctx <= 0
        else str(settings.ollama_num_ctx)
    )
    print(f"INFO    context   {context}")
    if settings.llm_backend == "ollama" and settings.ollama_num_ctx <= 0:
        print(
            "WARN    context   Ollama auto context is hardware-dependent; MAI budgets history, "
            "but set MAI_OLLAMA_NUM_CTX explicitly if ollama ps shows headroom."
        )
    print(
        f"INFO    budget    data={settings.context_data_char_limit} chars, "
        f"input={settings.input_context_char_limit} chars"
    )

    print()
    profile = Path(settings.persona_profile_path)
    profile_ok = profile.exists() and _json_ok(profile)
    print(f"{mark(profile_ok):7} data      persona profile")

    try:
        identity = IdentityStore(settings.identity_path)
        identity_ok = bool(identity.identity_id and identity.version)
    except Exception as exc:
        identity_ok = False
        print(f"MISSING data      identity ({exc})")
    else:
        print(f"{mark(identity_ok):7} data      identity v{identity.version}")

    db_parent = Path(settings.database_path).parent
    db_parent.mkdir(parents=True, exist_ok=True)
    print(f"OK      data      {db_parent}")

    db_ok = True
    try:
        health = database_health(settings.database_path)
        if health["exists"]:
            integrity_ok = health["quick_check"].casefold() == "ok"
            fk_ok = (
                health["foreign_keys_enabled"]
                and health["foreign_key_violations"] == 0
            )
            db_ok = integrity_ok and fk_ok
            print(f"{mark(integrity_ok):7} database  quick_check={health['quick_check']}")
            print(
                f"{mark(fk_ok):7} database  foreign_keys "
                f"violations={health['foreign_key_violations']}"
            )
        else:
            print("OK      database  not created yet")
    except Exception as exc:
        db_ok = False
        print(f"MISSING database  health check failed: {exc}")

    ready = python_supported and core_ok and backend_ok and profile_ok and identity_ok and db_ok

    print()
    if ready:
        print("READY: run python main.py")
        return 0

    print("NOT READY: fix the failed core item(s), then run doctor.py again.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
