# MAI v0.9.3b voice setup

## Preconfigured MAI voice

This build is preconfigured for ElevenLabs voice ID ``.

Run `SET_ELEVENLABS_KEY.bat` once and paste your ElevenLabs API key. The key is stored only in the local `.env` file. Then launch `start_mai.bat` and run `/voice-test`.

## Recommended voice: ElevenLabs

> Hotfix: v0.9.3b updates the Voice Design request to the current ElevenLabs Text-to-Voice v3 schema.


MAI v0.9.3b adds a first-class ElevenLabs backend and a guided original-voice designer. The voice is generated from MAI's own description rather than cloned from a real artist.

### 1. Create an ElevenLabs API key

Create an ElevenLabs account and API key. Copy `.env.example` to `.env`, then set:

```text
MAI_ELEVENLABS_API_KEY=your_key_here
```

Do not commit `.env`.

### 2. Generate MAI voice candidates

From the MAI folder:

```text
.\.venv\Scripts\python.exe design_mai_voice.py
```

The tool writes voice candidates to:

```text
data\voices\mai\previews\
```

Listen to the generated MP3 files and choose the voice that best fits MAI.

### 3. Select the permanent voice

For example, to select candidate 2:

```text
.\.venv\Scripts\python.exe select_mai_voice.py 2
```

This creates the voice in your ElevenLabs account and writes the resulting voice ID to `.env`. It also sets:

```text
MAI_VOICE_TTS_BACKEND=elevenlabs
```

### 4. Test it

Run:

```text
start_mai.bat
```

Then use:

```text
/voice-test
```

For continuous microphone conversation use `/voice-loop`. For the low-latency streaming pipeline, start WhisperLiveKit and use `/realtime`.

## Voice tuning

The recommended conversational defaults are:

```text
MAI_ELEVENLABS_MODEL=eleven_v3_conversational
MAI_ELEVENLABS_STABILITY=0.55
MAI_ELEVENLABS_SIMILARITY_BOOST=0.80
MAI_ELEVENLABS_STYLE=0.18
MAI_ELEVENLABS_SPEED=1.0
```

Lower stability slightly for more variation. Raise it if delivery becomes inconsistent. Keep style modest for normal conversation so MAI sounds natural rather than performed.

For a lower-latency voice, set:

```text
MAI_ELEVENLABS_MODEL=eleven_flash_v2_5
```

## Fallbacks

`MAI_VOICE_TTS_BACKEND=auto` uses ElevenLabs when both an API key and voice ID are configured and otherwise falls back to Windows speech. Existing `windows` and `http` backends remain supported.

## Voice identity

Use only MAI's original designed voice or a voice for which you have permission. Do not clone a real singer, celebrity or other person to make MAI sound like them.
