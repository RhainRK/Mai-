from __future__ import annotations

import json
import os
from pathlib import Path
import sys

import httpx


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "data" / "voices" / "mai" / "previews" / "manifest.json"


def load_env_value(name: str) -> str:
    value = os.getenv(name, "").strip()
    if value:
        return value
    env = ROOT / ".env"
    if env.exists():
        for raw in env.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, item = line.split("=", 1)
            if key.strip() == name:
                return item.strip().strip('"').strip("'")
    return ""


def set_env_value(name: str, value: str):
    env = ROOT / ".env"
    lines = env.read_text(encoding="utf-8").splitlines() if env.exists() else []
    prefix = f"{name}="
    replaced = False
    out = []
    for line in lines:
        if line.strip().startswith(prefix):
            out.append(f"{name}={value}")
            replaced = True
        else:
            out.append(line)
    if not replaced:
        out.append(f"{name}={value}")
    env.write_text("\n".join(out).rstrip() + "\n", encoding="utf-8")


def main():
    if len(sys.argv) != 2 or not sys.argv[1].isdigit():
        raise SystemExit("Use: python select_mai_voice.py <preview-number>")
    if not MANIFEST.exists():
        raise SystemExit("No previews found. Run design_mai_voice.py first.")

    api_key = load_env_value("MAI_ELEVENLABS_API_KEY")
    if not api_key:
        raise SystemExit("Set MAI_ELEVENLABS_API_KEY in .env first.")
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    number = int(sys.argv[1])
    preview = next((p for p in manifest["previews"] if p["index"] == number), None)
    if preview is None:
        raise SystemExit(f"Preview {number} does not exist.")

    response = httpx.post(
        "https://api.elevenlabs.io/v1/text-to-voice",
        headers={"xi-api-key": api_key, "Content-Type": "application/json"},
        json={
            "voice_name": "MAI",
            "voice_description": manifest["voice_description"],
            "generated_voice_id": preview["generated_voice_id"],
            "labels": {"character": "MAI", "type": "original-ai-artist"},
        },
        timeout=180.0,
    )
    response.raise_for_status()
    voice_id = response.json()["voice_id"]
    set_env_value("MAI_VOICE_TTS_BACKEND", "elevenlabs")
    set_env_value("MAI_ELEVENLABS_VOICE_ID", voice_id)
    print(f"MAI voice selected: {voice_id}")
    print(".env updated. Run start_mai.bat and use /voice-test.")


if __name__ == "__main__":
    main()
