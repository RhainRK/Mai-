@echo off
echo This deletes MAI's conversation history, memories, profile facts, learned skills, goals, and relationship state stored in this database.
choice /M "Factory reset MAI memory"
if errorlevel 2 exit /b 0
if exist "data\idol_memory.sqlite3" del /q "data\idol_memory.sqlite3"
if exist "data\idol_memory.sqlite3-wal" del /q "data\idol_memory.sqlite3-wal"
if exist "data\idol_memory.sqlite3-shm" del /q "data\idol_memory.sqlite3-shm"
echo Memory reset complete. MAI will create a fresh database next launch.
pause
