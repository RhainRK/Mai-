@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo MAI environment not found. Run setup_windows.ps1 first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -m pip install -r requirements-realtime.txt
if errorlevel 1 (
    echo Realtime client dependency installation failed.
    pause
    exit /b 1
)
echo.
echo Realtime client dependencies installed.
echo WhisperLiveKit itself should use its separate .venv-wlk environment.
echo Run install_whisperlivekit.ps1 when you are ready for realtime STT.
pause
