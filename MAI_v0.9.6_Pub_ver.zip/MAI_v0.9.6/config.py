from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


ROOT = Path(__file__).resolve().parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="MAI_",
        env_file=ROOT / ".env",
        extra="ignore",
    )

    llm_backend: Literal["ollama", "openai_compatible"] = "ollama"
    ollama_url: str = "http://127.0.0.1:11434"
    ollama_model: str = "auto"
    ollama_preferred_model: str = "qwen3.5:4b"
    ollama_fallback_model: str = "qwen3:4b"
    ollama_keep_alive: str = "30m"
    ollama_num_ctx: int = 0
    chat_temperature: float = Field(0.72, ge=0.0, le=2.0)
    tool_temperature: float = Field(0.2, ge=0.0, le=2.0)
    top_p: float = Field(0.9, gt=0.0, le=1.0)
    max_output_tokens: int = Field(512, ge=32, le=32768)

    api_base_url: str = "http://127.0.0.1:8000/v1"
    api_key: str = ""
    api_model: str = "your-model-name"

    request_timeout: float = Field(180.0, gt=0.0, le=3600.0)
    max_tool_steps: int = Field(8, ge=1, le=32)
    max_work_cycles: int = Field(4, ge=1, le=32)
    reply_recovery_attempts: int = Field(2, ge=1, le=5)
    trace_retention: int = Field(2000, ge=100, le=100000)
    # Prompt budgets
    context_data_char_limit: int = Field(4500, ge=1500, le=50000)
    input_context_char_limit: int = Field(14000, ge=6000, le=250000)
    context_compression_threshold: float = Field(0.72, ge=0.25, le=0.95)

    database_path: Path = ROOT / "data" / "idol_memory.sqlite3"
    persona_profile_path: Path = ROOT / "data" / "persona" / "mai_profile.json"
    identity_path: Path = ROOT / "data" / "persona" / "mai_identity.json"
    short_term_turns: int = Field(14, ge=2, le=100)
    memory_recall_limit: int = Field(8, ge=1, le=50)
    memory_consolidation_turns: int = Field(6, ge=2, le=100)
    session_id: str = "local"
    memory_candidate_limit: int = Field(600, ge=50, le=10000)
    continuity_recall_limit: int = Field(8, ge=1, le=50)
    continuity_candidate_limit: int = Field(400, ge=50, le=10000)
    embedding_model: str = (
        "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
    )

    voice_tts_backend: Literal["auto", "windows", "http", "elevenlabs"] = "auto"
    voice_tts_url: str = "http://127.0.0.1:8080/v1"
    voice_tts_model: str = "cosyvoice3"
    windows_voice_name: str = ""
    elevenlabs_api_key: str = ""
    elevenlabs_voice_id: str = ""
    elevenlabs_model: str = "eleven_v3_conversational"
    elevenlabs_base_url: str = "https://api.elevenlabs.io/v1"
    elevenlabs_sample_rate: int = Field(24000, ge=16000, le=44100)
    elevenlabs_stability: float = Field(0.55, ge=0.0, le=1.0)
    elevenlabs_similarity_boost: float = Field(0.80, ge=0.0, le=1.0)
    elevenlabs_style: float = Field(0.18, ge=0.0, le=1.0)
    elevenlabs_speed: float = Field(1.0, ge=0.7, le=1.2)
    elevenlabs_use_speaker_boost: bool = True
    windows_voice_rate: int = 1
    windows_voice_volume: int = 100

    audio_output_device: str = ""
    avatar_enabled: bool = False
    avatar_backend: Literal["vnyan"] = "vnyan"
    avatar_audio_device: str = ""
    avatar_vnyan_url: str = "http://127.0.0.1:8069"
    avatar_events: bool = True
    avatar_timeout: float = Field(2.0, gt=0.0, le=30.0)
    avatar_autonomy: bool = True
    avatar_idle_min_seconds: float = Field(2.8, ge=1.0, le=60.0)
    avatar_idle_max_seconds: float = Field(6.0, ge=1.0, le=120.0)

    diffsinger_root: Path = ROOT / "external" / "DiffSinger"
    diffsinger_experiment: str = "mai_acoustic"

    stt_model_size: str = "base.en"
    stt_device: str = "cpu"
    stt_compute_type: str = "int8"
    stt_language: str | None = "en"
    stt_beam_size: int = 3

    mic_sample_rate: int = Field(16000, ge=8000, le=192000)
    mic_silence_seconds: float = Field(0.85, ge=0.1, le=10.0)

    realtime_stt_url: str = "ws://127.0.0.1:8000"
    realtime_stt_token: str = ""
    realtime_input_rate: int = Field(16000, ge=8000, le=192000)
    realtime_output_rate: int = Field(24000, ge=8000, le=192000)
    realtime_block_ms: int = Field(20, ge=5, le=200)
    realtime_aec: bool = True
    realtime_barge_in_probability: float = Field(0.72, ge=0.0, le=1.0)
    realtime_barge_in_chars: int = 3
    realtime_echo_similarity: float = Field(0.72, ge=0.0, le=1.0)
    realtime_tts_min_chars: int = 36
    realtime_tts_max_chars: int = 180

    stockfish_path: Path | None = None
    chess_engine_time: float = Field(0.25, gt=0.0, le=30.0)


settings = Settings()
