@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo MAI environment not found. Run setup_windows.ps1 first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -m pip install -r requirements-memory.txt
if errorlevel 1 (
    echo Memory package installation failed.
    pause
    exit /b 1
)
echo.
echo Semantic memory dependencies installed.
pause
