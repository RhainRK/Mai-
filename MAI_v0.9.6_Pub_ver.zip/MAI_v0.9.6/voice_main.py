from idol import IdolAgent
from idol.version import __version__


def main():
    print(f"MAI v{__version__} Voice")
    idol = IdolAgent()
    try:
        idol.create_live_voice_session().run()
    except KeyboardInterrupt:
        print("\nVoice mode stopped.")
    finally:
        idol.close()


if __name__ == "__main__":
    main()
