# MAI v0.9.2 — Windows setup, step by step

This is the supported clean-install path for the current MAI build.

## Environment layout

Do **not** install every AI component into one Python environment. MAI is designed around isolated services:

```text
Windows
├─ Ollama                         local LLM service
│  └─ qwen3.5:4b                 MAI default brain
├─ MAI/.venv                     Python 3.11
│  ├─ MAI core
│  ├─ semantic memory (optional but recommended)
│  ├─ basic microphone STT (optional)
│  └─ realtime client libraries (optional)
├─ MAI/.venv-wlk                 Python 3.11
│  └─ WhisperLiveKit server      optional realtime STT
├─ CosyVoice Conda environment   Python 3.10, later
├─ singing environment           separate, later
└─ training environment          separate, later
```

Python 3.11 is the standard MAI Windows baseline. It also sits inside WhisperLiveKit's current supported Python range (>=3.11,<3.14). CosyVoice should remain separate because its official installation uses a Python 3.10 Conda environment.

---

## Phase 1 — Install the PC prerequisites

### 1. Install 64-bit Python 3.11

Download Python for Windows from:

https://www.python.org/downloads/windows/

Install Python 3.11 64-bit. If the installer offers PATH / launcher options, enable the Python launcher.

Open a new PowerShell window and run:

```powershell
py -3.11 --version
```

Expected:

```text
Python 3.11.x
```

Do not create MAI's main environment with Python 3.14. The build intentionally standardizes on Python 3.11 for cross-component compatibility.

### 2. Install Git for Windows

Download:

https://git-scm.com/download/win

Then check:

```powershell
git --version
```

Git is not needed for the basic chatbot runtime, but it is needed later for external voice/music/avatar repositories.

### 3. Install Ollama for Windows

Download:

https://ollama.com/download/windows

Start Ollama, then check:

```powershell
ollama --version
ollama list
```

### 4. Optional hardware check

From the MAI folder you can run:

```powershell
powershell -ExecutionPolicy Bypass -File .\check_windows_prereqs.ps1
```

If you have an NVIDIA GPU, the script also reports its name, VRAM and driver through `nvidia-smi`.

---

## Phase 2 — Install MAI core

### 5. Extract MAI

A simple location is recommended, for example:

```text
C:\AI\MAI-v0.9.2\
```

Avoid `C:\Program Files\...` because Windows permissions make development more awkward.

### 6. Open PowerShell in the MAI folder

In File Explorer, open the MAI folder, click the address bar, type `powershell`, and press Enter.

### 7. Run the corrected setup script

Easiest method: double-click `setup_windows.bat`.

Or run it directly from PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup_windows.ps1
```

The script now does all of the following deliberately:

1. requires/resolves Python 3.11;
2. creates `.venv` using Python 3.11;
3. upgrades pip/setuptools/wheel;
4. installs `requirements-core.txt`;
5. creates `.env` from `.env.example` if needed;
6. verifies that the Ollama service responds;
7. pulls `qwen3.5:4b` (not the older qwen3 model);
8. runs `doctor.py`;
9. runs `smoke_test.py`.

When it finishes successfully, start MAI with:

```powershell
.\start_mai.bat
```

Or directly:

```powershell
.\.venv\Scripts\python.exe main.py
```

---

## Phase 3 — Add MAI's recommended memory layer

### 8. Install semantic memory

Run:

```powershell
.\install_memory.bat
```

This installs Sentence Transformers into MAI's `.venv`. The embedding model is downloaded automatically the first time it is needed.

Then verify again:

```powershell
.\.venv\Scripts\python.exe doctor.py
```

You should see semantic memory as `OK`.

You can alternatively install core + memory in one setup call on a fresh install:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup_windows.ps1 -WithMemory
```

---

## Phase 4 — Add basic microphone voice

This is the stable, easiest voice path:

```text
microphone -> Faster-Whisper -> MAI -> Windows TTS -> speakers
```

### 9. Install basic voice dependencies

```powershell
.\install_voice.bat
```

This installs `sounddevice` and `faster-whisper` in MAI's main `.venv` and runs `voice_doctor.py`.

Keep the initial STT settings in `.env` conservative:

```text
MAI_STT_MODEL_SIZE=base.en
MAI_STT_DEVICE=cpu
MAI_STT_COMPUTE_TYPE=int8
MAI_STT_LANGUAGE=en
```

CPU mode is the compatibility baseline. GPU acceleration can be configured after the exact GPU/VRAM has been checked.

### 10. Test voice

Start MAI:

```powershell
.\start_mai.bat
```

Then use:

```text
/mic-test
/voice-test
/talk
/voice-loop
```

`/mic-test` should transcribe your microphone. `/voice-test` checks output speech.

---

## Phase 5 — Install the realtime client components

### 11. Install MAI's realtime client dependencies

```powershell
.\install_realtime.bat
```

This installs only the lightweight realtime client pieces in MAI's main `.venv` (`websockets` and `pywebrtc-audio`).

WhisperLiveKit itself is **not** installed into `.venv`.

### 12. Install WhisperLiveKit in its own Python 3.11 environment

Run `install_whisperlivekit.bat`, or from PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\install_whisperlivekit.ps1
```

This creates:

```text
.venv-wlk
```

and installs the current WhisperLiveKit package there.

### 13. Start WhisperLiveKit

Run:

```powershell
.\start_whisperlivekit.bat
```

Leave that terminal open.

MAI's client connects to:

```text
ws://127.0.0.1:8000/asr
```

The launch script uses `--pcm-input` because MAI streams raw signed 16-bit PCM audio rather than browser MediaRecorder chunks.

**Important:** `/realtime` also requires an HTTP streaming TTS service. WhisperLiveKit alone provides realtime speech recognition, not MAI's realtime speech synthesis. Until CosyVoice/another compatible HTTP TTS service is configured, use `/voice-loop` for complete two-way voice interaction.

---

## Phase 6 — CosyVoice (later, separate environment)

Do not install CosyVoice into `.venv` or `.venv-wlk`.

The upstream CosyVoice installation uses Conda with Python 3.10. The intended MAI architecture is:

```text
MAI (.venv, Python 3.11)
       |
       | HTTP
       v
CosyVoice service (Conda, Python 3.10)
```

When this layer is installed, set in `.env`:

```text
MAI_VOICE_TTS_BACKEND=http
MAI_VOICE_TTS_URL=http://127.0.0.1:8080/v1
MAI_VOICE_TTS_MODEL=cosyvoice3
```

Do this only after the CosyVoice HTTP adapter/service has been configured and tested.

---

## Phase 7 — Singing/music/training (later)

Keep these separate too:

- singing synthesis: its own environment;
- music-generation engine: its own environment/service;
- LoRA/persona training: its own GPU training environment.

Do **not** run `pip install -r training/requirements.txt` inside MAI's normal `.venv`. Training packages can change PyTorch/Transformers/CUDA dependencies and destabilize inference.

---

## Useful verification commands

From the MAI folder:

```powershell
.\.venv\Scripts\python.exe doctor.py
.\.venv\Scripts\python.exe smoke_test.py
.\.venv\Scripts\python.exe voice_doctor.py
.\.venv\Scripts\python.exe -m pytest -q
```

Ollama checks:

```powershell
ollama list
ollama run qwen3.5:4b
```

Exit the Ollama interactive prompt when finished, then run MAI normally.

---

## What you should install first

For the first working MAI session, stop after these items:

1. Python 3.11 64-bit
2. Git for Windows
3. Ollama
4. MAI core setup
5. `qwen3.5:4b`
6. semantic memory
7. basic voice dependencies

Get text chat and `/voice-loop` stable before installing CosyVoice, singing, music generation or training packages.
