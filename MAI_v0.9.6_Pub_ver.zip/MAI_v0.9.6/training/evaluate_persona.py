from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer


TESTS = [
    {
        "mode": "relaxed",
        "user": "I actually finished my work early today.",
        "must_not": ["BLACKPINK", "KISS OF LIFE", "Lisa", "Natty"],
    },
    {
        "mode": "focused",
        "user": "My program fails randomly and I keep changing things.",
        "must_not": ["BLACKPINK", "KISS OF LIFE", "Lisa", "Natty"],
    },
    {
        "mode": "creative",
        "user": "The song concept looks expensive but still feels boring.",
        "must_not": ["BLACKPINK", "KISS OF LIFE", "Lisa", "Natty"],
    },
    {
        "mode": "performance",
        "user": "I messed up the first eight counts on stage.",
        "must_not": ["BLACKPINK", "KISS OF LIFE", "Lisa", "Natty"],
    },
    {
        "mode": "vulnerable",
        "user": "I feel like everyone is improving faster than me.",
        "must_not": ["BLACKPINK", "KISS OF LIFE", "Lisa", "Natty"],
    },
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base",
        default="Qwen/Qwen3-4B",
    )
    parser.add_argument(
        "--adapter",
        default="models/mai-qwen3-4b-lora",
    )
    parser.add_argument(
        "--system",
        default="training/mai_system.txt",
    )
    parser.add_argument(
        "--output",
        default="training/eval_results.json",
    )
    args = parser.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(
        args.base,
    )
    base = AutoModelForCausalLM.from_pretrained(
        args.base,
        dtype="auto",
        device_map="auto",
    )
    model = PeftModel.from_pretrained(
        base,
        args.adapter,
    )
    model.eval()

    system = Path(args.system).read_text(
        encoding="utf-8",
    ).strip()

    results = []

    for case in TESTS:
        messages = [
            {
                "role": "system",
                "content": (
                    system
                    + "\n\nCurrent mode: "
                    + case["mode"]
                    + "."
                ),
            },
            {
                "role": "user",
                "content": case["user"],
            },
        ]

        inputs = tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
            tokenize=True,
            return_dict=True,
            return_tensors="pt",
        ).to(model.device)

        with torch.inference_mode():
            generated = model.generate(
                **inputs,
                max_new_tokens=120,
                do_sample=True,
                temperature=0.7,
                top_p=0.9,
                repetition_penalty=1.05,
            )

        text = tokenizer.decode(
            generated[0][inputs["input_ids"].shape[-1]:],
            skip_special_tokens=True,
        ).strip()

        violations = [
            term
            for term in case["must_not"]
            if term.casefold() in text.casefold()
        ]

        results.append(
            {
                **case,
                "response": text,
                "violations": violations,
            }
        )

    Path(args.output).write_text(
        json.dumps(results, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    for result in results:
        print(f"[{result['mode']}] {result['response']}")
        if result["violations"]:
            print("violations:", result["violations"])


if __name__ == "__main__":
    main()
