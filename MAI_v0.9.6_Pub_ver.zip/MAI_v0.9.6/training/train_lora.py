from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
from datasets import load_dataset
from peft import LoraConfig
from transformers import BitsAndBytesConfig
from trl import SFTConfig, SFTTrainer


def supports_bf16() -> bool:
    return bool(
        torch.cuda.is_available()
        and torch.cuda.is_bf16_supported()
    )


def model_kwargs(qlora: bool) -> dict:
    if not qlora:
        return {
            "dtype": (
                torch.bfloat16
                if supports_bf16()
                else torch.float16
            ),
            "device_map": "auto",
        }

    compute_dtype = (
        torch.bfloat16
        if supports_bf16()
        else torch.float16
    )

    return {
        "device_map": "auto",
        "quantization_config": BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=compute_dtype,
        ),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model",
        default="Qwen/Qwen3-4B",
    )
    parser.add_argument(
        "--train",
        default="training/data/train.jsonl",
    )
    parser.add_argument(
        "--eval",
        default="training/data/eval.jsonl",
    )
    parser.add_argument(
        "--output",
        default="models/mai-qwen3-4b-lora",
    )
    parser.add_argument(
        "--epochs",
        type=float,
        default=3.0,
    )
    parser.add_argument(
        "--lr",
        type=float,
        default=1.0e-4,
    )
    parser.add_argument(
        "--rank",
        type=int,
        default=32,
    )
    parser.add_argument(
        "--alpha",
        type=int,
        default=64,
    )
    parser.add_argument(
        "--max-length",
        type=int,
        default=1024,
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=1,
    )
    parser.add_argument(
        "--gradient-accumulation",
        type=int,
        default=8,
    )
    parser.add_argument(
        "--no-qlora",
        action="store_true",
    )
    parser.add_argument(
        "--allow-small-dataset",
        action="store_true",
    )
    parser.add_argument(
        "--no-packing",
        action="store_true",
        help="Disable TRL example packing (packing is efficient for MAI's short dialogue rows).",
    )
    args = parser.parse_args()

    train_rows = load_dataset(
        "json",
        data_files=args.train,
        split="train",
    )
    eval_rows = load_dataset(
        "json",
        data_files=args.eval,
        split="train",
    )

    if len(train_rows) < 300 and not args.allow_small_dataset:
        raise SystemExit(
            "Refusing to train on fewer than 300 examples. "
            "Expand the dataset or pass --allow-small-dataset."
        )

    lora = LoraConfig(
        r=args.rank,
        lora_alpha=args.alpha,
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules="all-linear",
    )

    bf16 = supports_bf16()

    config = SFTConfig(
        output_dir=args.output,
        num_train_epochs=args.epochs,
        learning_rate=args.lr,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=1,
        gradient_accumulation_steps=args.gradient_accumulation,
        gradient_checkpointing=True,
        max_length=args.max_length,
        completion_only_loss=True,
        packing=not args.no_packing,
        eval_packing=False,
        eval_strategy="epoch",
        save_strategy="epoch",
        logging_steps=5,
        bf16=bf16,
        fp16=not bf16,
        optim="paged_adamw_8bit" if not args.no_qlora else "adamw_torch",
        warmup_ratio=0.05,
        lr_scheduler_type="cosine",
        weight_decay=0.01,
        report_to="none",
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        greater_is_better=False,
        model_init_kwargs=model_kwargs(not args.no_qlora),
    )

    trainer = SFTTrainer(
        model=args.model,
        args=config,
        train_dataset=train_rows,
        eval_dataset=eval_rows,
        peft_config=lora,
    )

    trainer.train()
    trainer.save_model(args.output)
    trainer.processing_class.save_pretrained(args.output)

    metadata = {
        "base_model": args.model,
        "adapter": args.output,
        "train_examples": len(train_rows),
        "eval_examples": len(eval_rows),
        "qlora": not args.no_qlora,
        "rank": args.rank,
        "alpha": args.alpha,
        "learning_rate": args.lr,
        "epochs": args.epochs,
        "packing": not args.no_packing,
        "runtime_compatibility_note": (
            "LoRA adapters are architecture-specific. The default Qwen3 adapter cannot be "
            "loaded into MAI's Qwen3.5 runtime model without a separately validated Qwen3.5 training path."
        ),
    }

    Path(args.output).mkdir(parents=True, exist_ok=True)
    Path(args.output, "mai_training.json").write_text(
        json.dumps(metadata, indent=2),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
