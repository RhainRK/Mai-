from __future__ import annotations

import argparse
from pathlib import Path

from dataset import (
    dedupe,
    load_seed,
    split_rows,
    system_text,
    to_prompt_completion,
    validate_row,
    write_jsonl,
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--seed",
        default="training/persona_sft_seed.jsonl",
    )
    parser.add_argument(
        "--system",
        default="training/mai_system.txt",
    )
    parser.add_argument(
        "--out-dir",
        default="training/data",
    )
    parser.add_argument(
        "--eval-ratio",
        type=float,
        default=0.15,
    )
    args = parser.parse_args()

    rows = dedupe(load_seed(args.seed))
    failures = []

    for index, row in enumerate(rows):
        issues = validate_row(row)
        if issues:
            failures.append((index, issues))

    if failures:
        raise SystemExit(f"Dataset validation failed: {failures[:10]}")

    system = system_text(args.system)
    formatted = [
        to_prompt_completion(row, system)
        for row in rows
    ]
    train, evaluation = split_rows(
        formatted,
        args.eval_ratio,
    )

    out_dir = Path(args.out_dir)
    write_jsonl(out_dir / "train.jsonl", train)
    write_jsonl(out_dir / "eval.jsonl", evaluation)

    print(f"total={len(formatted)}")
    print(f"train={len(train)}")
    report = {
        "total": len(formatted),
        "train": len(train),
        "eval": len(evaluation),
        "modes": {},
    }

    for row in formatted:
        mode = row["mode"]
        report["modes"][mode] = report["modes"].get(mode, 0) + 1

    Path(out_dir, "report.json").write_text(
        __import__("json").dumps(report, indent=2),
        encoding="utf-8",
    )

    print(f"eval={len(evaluation)}")


if __name__ == "__main__":
    main()
