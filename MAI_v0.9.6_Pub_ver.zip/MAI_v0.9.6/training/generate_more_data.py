from __future__ import annotations

import argparse
import json
from pathlib import Path
import random

from openai import OpenAI

from dataset import FORBIDDEN


MODES = {
    "relaxed": (
        "casual, playful, concise, warm, mildly teasing, never clingy"
    ),
    "focused": (
        "precise, practical, low-joke, direct without sounding cold"
    ),
    "creative": (
        "aesthetic, opinionated, experimental, specific about craft"
    ),
    "performance": (
        "energetic, disciplined, decisive, competitive but grounded"
    ),
    "vulnerable": (
        "plain, warm, restrained, growth-oriented, not melodramatic"
    ),
    "fan_facing": (
        "playful, appreciative, memorable, non-exclusive, non-explicit, never manipulative"
    ),
    "interview": (
        "polished, concise, self-aware, broadcast-safe, gives collaborators credit"
    ),
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url")
    parser.add_argument("--api-key", default="local")
    parser.add_argument("--model", required=True)
    parser.add_argument(
        "--system",
        default="training/mai_system.txt",
    )
    parser.add_argument(
        "--output",
        default="training/persona_generated.jsonl",
    )
    parser.add_argument("--count", type=int, default=200)
    parser.add_argument("--max-attempts", type=int, default=0)
    args = parser.parse_args()

    client = OpenAI(
        api_key=args.api_key,
        base_url=args.base_url,
    )
    system = Path(args.system).read_text(
        encoding="utf-8",
    ).strip()

    rows = []
    modes = list(MODES)
    attempts = 0
    max_attempts = args.max_attempts or max(args.count * 10, 100)

    while len(rows) < args.count and attempts < max_attempts:
        attempts += 1
        mode = random.choice(modes)
        request = f'''
Create one ORIGINAL dialogue example for MAI.

Mode: {mode}
Style: {MODES[mode]}

Return strict JSON:
{{
  "input": "one realistic user message",
  "response": "MAI's response"
}}

Rules:
- Do not mention or imitate any real reference artist.
- Do not copy celebrity wording or catchphrases.
- Keep MAI's response under 90 words.
- Avoid generic assistant phrases.
- Make the scenario different from obvious chatbot benchmarks.

MAI identity:
{system}
'''.strip()

        result = client.chat.completions.create(
            model=args.model,
            messages=[
                {
                    "role": "user",
                    "content": request,
                }
            ],
            temperature=1.0,
        )

        raw = result.choices[0].message.content.strip()

        try:
            item = json.loads(raw)
        except json.JSONDecodeError:
            continue

        response = str(item.get("response", "")).strip()
        user = str(item.get("input", "")).strip()
        lowered = response.casefold()

        if not user or not response:
            continue

        if any(term in lowered for term in FORBIDDEN):
            continue

        rows.append(
            {
                "mode": mode,
                "input": user,
                "response": response,
            }
        )

    client.close()

    if len(rows) < args.count:
        raise SystemExit(
            f"Generated only {len(rows)}/{args.count} valid rows after {attempts} attempts. "
            "Inspect model output or increase --max-attempts."
        )

    Path(args.output).write_text(
        "\n".join(
            json.dumps(row, ensure_ascii=False)
            for row in rows
        )
        + "\n",
        encoding="utf-8",
    )

    print(f"wrote={len(rows)}")


if __name__ == "__main__":
    main()
