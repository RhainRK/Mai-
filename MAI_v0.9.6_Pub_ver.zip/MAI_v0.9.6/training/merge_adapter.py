from __future__ import annotations

import argparse

from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base",
        default="Qwen/Qwen3-4B",
    )
    parser.add_argument(
        "--adapter",
        default="models/mai-qwen3-4b-lora",
    )
    parser.add_argument(
        "--output",
        default="models/mai-qwen3-4b-merged",
    )
    args = parser.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(
        args.base,
    )
    model = AutoModelForCausalLM.from_pretrained(
        args.base,
        dtype="auto",
        device_map="auto",
        low_cpu_mem_usage=True,
    )

    model = PeftModel.from_pretrained(
        model,
        args.adapter,
    )
    merged = model.merge_and_unload()

    merged.save_pretrained(
        args.output,
        safe_serialization=True,
    )
    tokenizer.save_pretrained(args.output)


if __name__ == "__main__":
    main()
