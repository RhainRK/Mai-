from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Iterable


FORBIDDEN = (
    "blackpink",
    "kiss of life",
    "lisa",
    "natty",
    "ariana grande",
    "katseye",
    "aespa",
)


def load_seed(path: str | Path) -> list[dict]:
    rows = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def system_text(path: str | Path) -> str:
    return Path(path).read_text(encoding="utf-8").strip()


def validate_row(row: dict) -> list[str]:
    issues = []

    if row.get("mode") not in {
        "relaxed",
        "focused",
        "creative",
        "performance",
        "vulnerable",
        "fan_facing",
        "interview",
    }:
        issues.append("mode")

    prompt = str(row.get("input", "")).strip()
    response = str(row.get("response", "")).strip()

    if len(prompt) < 2:
        issues.append("input")

    if len(response) < 8:
        issues.append("response")

    lowered = response.casefold()
    if any(term in lowered for term in FORBIDDEN):
        issues.append("identity")

    if len(response) > 700:
        issues.append("length")

    return issues


def signature(row: dict) -> str:
    payload = (
        str(row.get("mode", "")).casefold().strip()
        + "\0"
        + str(row.get("input", "")).casefold().strip()
        + "\0"
        + str(row.get("response", "")).casefold().strip()
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def dedupe(rows: Iterable[dict]) -> list[dict]:
    seen = set()
    result = []

    for row in rows:
        key = signature(row)
        if key in seen:
            continue
        seen.add(key)
        result.append(row)

    return result


def to_prompt_completion(row: dict, system: str) -> dict:
    mode = row["mode"]
    mode_instruction = {
        "relaxed": "Current mode: relaxed.",
        "focused": "Current mode: focused and precise.",
        "creative": "Current mode: creative and opinionated.",
        "performance": "Current mode: performance-focused and energetic.",
        "vulnerable": "Current mode: emotionally open but grounded.",
        "fan_facing": "Current mode: fan-facing, playful, appreciative and non-exclusive.",
        "interview": "Current mode: polished, concise, self-aware and broadcast-safe.",
    }[mode]

    return {
        "prompt": [
            {
                "role": "system",
                "content": system + "\n\n" + mode_instruction,
            },
            {
                "role": "user",
                "content": row["input"].strip(),
            },
        ],
        "completion": [
            {
                "role": "assistant",
                "content": row["response"].strip(),
            }
        ],
        "mode": mode,
    }


def split_rows(
    rows: list[dict],
    eval_ratio: float = 0.15,
) -> tuple[list[dict], list[dict]]:
    groups: dict[str, list[dict]] = {}

    for row in rows:
        groups.setdefault(row.get("mode", "unknown"), []).append(row)

    train = []
    evaluation = []

    for group in groups.values():
        ordered = sorted(
            group,
            key=lambda row: hashlib.sha256(
                json.dumps(
                    row,
                    ensure_ascii=False,
                    sort_keys=True,
                ).encode("utf-8")
            ).hexdigest(),
        )

        count = max(
            1,
            min(
                len(ordered) - 1,
                round(len(ordered) * eval_ratio),
            ),
        )

        if len(ordered) == 1:
            train.extend(ordered)
            continue

        evaluation.extend(ordered[:count])
        train.extend(ordered[count:])

    return train, evaluation


def write_jsonl(path: str | Path, rows: Iterable[dict]):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "\n".join(json.dumps(row, ensure_ascii=False) for row in rows) + "\n",
        encoding="utf-8",
    )
