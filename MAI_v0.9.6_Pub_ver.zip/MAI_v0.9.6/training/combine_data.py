from __future__ import annotations

import argparse
import json
from pathlib import Path


def read(path: str) -> list[dict]:
    result = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.strip():
            result.append(json.loads(line))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "files",
        nargs="+",
    )
    parser.add_argument(
        "--output",
        default="training/persona_sft_seed.jsonl",
    )
    args = parser.parse_args()

    seen = set()
    rows = []

    for file in args.files:
        for row in read(file):
            key = (
                row.get("mode", "").strip().casefold(),
                row.get("input", "").strip().casefold(),
            )
            if key in seen:
                continue
            seen.add(key)
            rows.append(row)

    Path(args.output).write_text(
        "\n".join(
            json.dumps(row, ensure_ascii=False)
            for row in rows
        )
        + "\n",
        encoding="utf-8",
    )

    print(f"rows={len(rows)}")


if __name__ == "__main__":
    main()
