# Clean release check — MAI v0.9.6

## Verdict

Clean source preview prepared. Full dependency/security sign-off NOT achieved. No GitHub upload performed. Do not describe this release as fully audited or free of vulnerabilities.

## Reset scope

This is a fresh distribution, not a reset of the user's PC. It contains no runtime database, conversation log, context cache, audio, .env, model weights or generated training dataset. Creator attribution and versioned default persona configuration remain. Automatic creator binding is disabled. Account-specific voice preset is blank. Training seed is empty and must be populated with reviewed examples before training.

Original private files and earlier packages remain unchanged. Nothing was securely erased. The old local reset batch removes only the default database, not custom database paths, audio, backups, exports or other copies. Do not use it as a GitHub sanitization guarantee.

## Available logs

No user runtime logs or memory database were supplied or found in the release source. Library searches did not locate those logs. Inspected prior Bandit/pip-audit output and this run's dependency resolver/auditor results. None of this establishes what the user's own installation logged.

## Dependency checks

Metadata-only binary resolution on Linux / Python 3.12 followed by pip-audit of exact resolved package versions. No model weights installed, no source build execution, no Windows compatibility validation. The full direct inventory and machine-readable results are attached in dependency_review/. A clean advisory result does not establish that a package is benign or bug-free.

| Group | Result |
| --- | --- |
| Realtime | 6 resolved packages; no known advisories returned |
| Chess | 2 resolved packages; no known advisories returned |
| Development | 6 resolved packages; no known advisories returned |
| WhisperLiveKit speech server | 84 resolved packages; no known advisories returned |
| Core | Resolution failed: httpx not available from configured source in this attempt |
| Training | Resolution failed: accelerate unavailable in this attempt |
| Voice | Resolution failed: faster-whisper unavailable in this attempt |
| Semantic memory | Resolution timed out |
| Build tooling | Resolution failed; not cleared |

Counts overlap between groups. Resolution failure is not evidence that a dependency is missing globally or vulnerable. Previous installed-environment audit reported pip 25.0.1 advisories; that separate finding remains documented in SECURITY_AUDIT.md. Native executables (Ollama, Stockfish), VNyan, external DiffSinger and downloaded model/adaptor artifacts were not supplied or audited.

## Distribution checks

- Rebuilt with allowlisted source directories, default JSON configuration and selected documentation.
- Excluded generated training data and old release-history documents.
- Credential defaults validated as empty; limited key-pattern scan passed.
- 129 tests passed, 1 skipped on the clean tree.
- ZIP integrity and SHA-256 checks performed at packaging.
- Git commit history and remotes unavailable; no history scan performed.
- No open-source license selected. Decide licensing before advertising this as an open-source release.

## To finish the audit

Provide redacted runtime logs and installed package names/versions for EACH environment (core, realtime server, training and any external voice environment). Do not include API keys, tokens or .env files. Provide the intended GitHub repository to inspect tracked files/history; use a new empty repository for this clean source if no existing history needs preserving. Never assume a clean working tree removes secrets from older commits.
