# Security policy

MAI is an experimental, single-user local application, not an authenticated multi-user service or a sandbox for untrusted code. Do not expose Ollama, speech services or avatar endpoints directly to the internet. Use trusted local endpoints, OS access controls and HTTPS/WSS for remote connections.

## Data and credentials

Configuration, memories, tool logs, observations, transcripts and context caches may contain private information. SQLite storage is not encrypted by this application. Never commit your `.env`, runtime `data/`, audio, model weights or personal fine-tuning datasets. `/forget` removes one memory record, not all archived copies or mentions.

Public releases disable automatic local-operator creator binding. This setting is not an authentication mechanism. Rhain remains the project's creator attribution.

Speech authentication currently uses a query parameter; access logs/proxies can retain it. Use short-lived tokens and avoid logging query strings. Redaction is best-effort and cannot recognize every secret in free text.

## Trust boundaries

Prompts and historical excerpts can influence model output. Tool allowlists and permissions are necessary, but do not make prompt injection impossible. User-configured executable paths, model repositories, adapters, and endpoints are trusted local configuration. Review them before use.

## Reporting

Do not put secrets or sensitive reproduction data in public issues. Use GitHub private vulnerability reporting if the repository maintainer enables it. A reporting contact and repository have not been configured in this source package.

## Release limitations

No independent penetration test, Windows hardware test, optional dependency audit, or repository-history secret scan has been completed. Review SECURITY_AUDIT.md before deployment. Use a maintained pip release and audit your own fully installed environment.
