# MAI v0.9.6 — Public Security Preview

Local-first AI idol runtime with persistent identity, memory, continuity, tools, voice, realtime speech and VNyan avatar integration.

## Overview

MAI separates the language model from the character layer. Identity, behaviour, continuity and creator canon live in versioned project data so the underlying model can be replaced without redefining MAI.

Rhain is the canonical creator and lead developer. This public sample does not authenticate the local operator as the creator. Read `SECURITY.md`, `SECURITY_AUDIT.md` and `RELEASE_DESCRIPTION.md` before use. This is an experimental pre-release, not an internet-facing service.

## Features

- Versioned MAI identity and locked canon
- Data-driven behaviour modes and social registers
- Creator-close register for Rhain
- Persistent memory and typed creative continuity
- Public/private context boundaries
- Turn planning, tools and trace diagnostics
- Ollama and OpenAI-compatible model backends
- Original MAI voice workflow with ElevenLabs Voice Design and expressive realtime TTS
- Voice, realtime STT/TTS and VNyan avatar hooks
- Fine-tuning dataset tooling
- Career and public-history tracking without fabricated events

## Requirements

- Windows 10/11
- Python 3.11 64-bit
- Ollama
- Recommended local model: `qwen3.5:4b`

Optional components have separate installers for semantic memory, voice, realtime speech and chess.

## Quick Start

```text
setup_windows.bat
start_mai.bat
```

For a manual install, follow `SETUP_WINDOWS_STEP_BY_STEP.md`.

## Configuration

Copy `.env.example` to `.env` and edit only the settings you need. Core paths and defaults are defined in `config.py`.

Persona data:

```text
data/persona/mai_profile.json
data/persona/mai_identity.json
data/persona/mai_sources.json
```

## Commands

Key diagnostics include `/identity`, `/creator`, `/canon`, `/continuity`, `/memory-map`, `/timeline`, `/trace`, `/stats`, `/avatar-status` and `/audio-devices`.

## Docs

- `RUN_ME_FIRST.md` — first launch
- `SETUP_WINDOWS_STEP_BY_STEP.md` — Windows environment
- `VOICE_SETUP.md` — voice setup
- `AVATAR_SETUP.md` — VNyan/VRM integration
- `VNYAN_MOVEMENT_SETUP.md` — movement, eyes and expressions
- `RESEARCH_AUDIT_2026_09_09.md` — architecture research audit
- `AI_IDOL_ROADMAP.md` — development roadmap

Run the test suite with:

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```
