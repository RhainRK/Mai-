param(
    [switch]$WithMemory,
    [switch]$WithVoice,
    [switch]$WithRealtime,
    [switch]$SkipModelPull
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Stop-Setup([string]$Message) {
    Write-Host ""
    Write-Host "ERROR: $Message" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "MAI v0.9.2 Windows setup"
Write-Host "========================="
Write-Host ""
Write-Host "Supported baseline: Python 3.11 64-bit + Ollama + qwen3.5:4b"
Write-Host ""

$PythonCommand = $null
$PythonPrefixArgs = @()
$PythonProbe = "import struct,sys; assert sys.version_info[:2] == (3, 11); assert struct.calcsize('P') * 8 == 64"

if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3.11 -c $PythonProbe 2>$null
    if ($LASTEXITCODE -eq 0) {
        $PythonCommand = "py"
        $PythonPrefixArgs = @("-3.11")
    }
}

if (-not $PythonCommand -and (Get-Command python -ErrorAction SilentlyContinue)) {
    & python -c $PythonProbe 2>$null
    if ($LASTEXITCODE -eq 0) {
        $PythonCommand = "python"
        $PythonPrefixArgs = @()
    }
}

if (-not $PythonCommand) {
    Stop-Setup "Python 3.11 64-bit was not found. Install Python 3.11 64-bit from python.org, then rerun setup."
}

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "Creating MAI Python 3.11 environment..."
    & $PythonCommand @PythonPrefixArgs -m venv .venv
    if ($LASTEXITCODE -ne 0) {
        Stop-Setup "Could not create .venv."
    }
}

$VenvPython = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
$VenvInfo = (& $VenvPython -c "import struct,sys; print(str(sys.version_info.major)+'.'+str(sys.version_info.minor)+'|'+str(struct.calcsize('P')*8))").Trim()
if ($LASTEXITCODE -ne 0) {
    Stop-Setup "The existing .venv could not be inspected. Delete .venv and rerun setup_windows.ps1."
}
$VenvParts = $VenvInfo.Split("|")
$VenvVersion = $VenvParts[0]
$VenvBits = if ($VenvParts.Length -gt 1) { $VenvParts[1] } else { "unknown" }
if ($VenvVersion -ne "3.11" -or $VenvBits -ne "64") {
    Stop-Setup "The existing .venv uses Python $VenvVersion ($VenvBits-bit). MAI's supported Windows baseline is Python 3.11 64-bit. Delete .venv and rerun setup_windows.ps1."
}

Write-Host "Updating pip tooling..."
& $VenvPython -m pip install --upgrade pip setuptools wheel
if ($LASTEXITCODE -ne 0) { Stop-Setup "pip bootstrap failed." }

Write-Host "Installing MAI core dependencies..."
& $VenvPython -m pip install -r requirements-core.txt
if ($LASTEXITCODE -ne 0) { Stop-Setup "Core dependency installation failed." }

if ($WithMemory) {
    Write-Host "Installing semantic-memory dependencies..."
    & $VenvPython -m pip install -r requirements-memory.txt
    if ($LASTEXITCODE -ne 0) { Stop-Setup "Memory dependency installation failed." }
}

if ($WithVoice) {
    Write-Host "Installing microphone/STT dependencies..."
    & $VenvPython -m pip install -r requirements-voice.txt
    if ($LASTEXITCODE -ne 0) { Stop-Setup "Voice dependency installation failed." }
}

if ($WithRealtime) {
    Write-Host "Installing realtime client dependencies..."
    & $VenvPython -m pip install -r requirements-realtime.txt
    if ($LASTEXITCODE -ne 0) { Stop-Setup "Realtime dependency installation failed." }
}

if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "Created .env from .env.example."
}

if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
    Stop-Setup "Ollama was not found. Install Ollama for Windows, make sure it is running, then rerun setup_windows.ps1."
}

Write-Host "Checking Ollama..."
& ollama list *> $null
if ($LASTEXITCODE -ne 0) {
    Stop-Setup "Ollama is installed but its local service is not responding. Start Ollama, then rerun this script."
}

if (-not $SkipModelPull) {
    Write-Host "Ensuring MAI's default local brain is installed: qwen3.5:4b"
    & ollama pull qwen3.5:4b
    if ($LASTEXITCODE -ne 0) { Stop-Setup "Could not pull qwen3.5:4b." }
}

Write-Host ""
Write-Host "Running MAI diagnostics..."
& $VenvPython doctor.py
if ($LASTEXITCODE -ne 0) { Stop-Setup "doctor.py reported a required setup problem." }

if (-not $SkipModelPull) {
    Write-Host ""
    Write-Host "Running model smoke test..."
    & $VenvPython smoke_test.py
    if ($LASTEXITCODE -ne 0) { Stop-Setup "smoke_test.py failed. Check Ollama and the model installation." }
}

Write-Host ""
Write-Host "SETUP COMPLETE" -ForegroundColor Green
Write-Host "Run start_mai.bat to start MAI."
if (-not $WithMemory) { Write-Host "Optional: run install_memory.bat for semantic memory." }
if (-not $WithVoice) { Write-Host "Optional: run install_voice.bat for microphone voice mode." }
if (-not $WithRealtime) { Write-Host "Optional: run install_realtime.bat for MAI's realtime client dependencies." }
Write-Host "See SETUP_WINDOWS_STEP_BY_STEP.md for the complete environment layout."
