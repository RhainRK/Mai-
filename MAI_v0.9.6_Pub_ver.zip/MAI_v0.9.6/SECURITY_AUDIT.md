# Security audit — MAI public preview

## Scope

Source-level review of v0.9.5 runtime, tool permissions/logging, memory/cache boundaries, subprocess calls, speech transport, installer configuration, code graph, training trust boundaries and distribution contents. Bandit scanned 8,613 runtime/training lines; pytest and pip-audit complement manual review. This is not a complete penetration test or proof of absence of vulnerabilities.

## Findings

| Priority | Finding | Disposition |
| --- | --- | --- |
| High if made multi-user | Local operator can be assumed to be creator without authentication | Disabled in public configuration; do not expose runtime as a service |
| Medium | Private free-text data persists in tool logs, memory observations and caches | Open; OS protection required; field-name redaction is not full DLP |
| Medium | STT token in URL query string | Open; avoid access-log collection, use short-lived credentials and WSS remotely |
| Medium | Configured remote URLs can use plaintext transports | Open; local defaults, trusted configuration only; use TLS remotely |
| Medium | Model/adaptor downloads and broad dependency ranges are not reproducibly pinned | Open; optional stacks untested, review supply chain and audit installed environment |
| Medium | Unbounded context/tool output growth and singing subprocess duration | Open availability risks for long sessions/untrusted workloads |
| Medium | `/forget` does not purge all historical copies | Open; do not claim complete erasure |
| Low | Graph SHA-1 identifiers | Non-security use; not an authentication primitive; scanner finding retained |
| Release privacy | Account-specific voice preset and operator binding distributed | Removed preset and disabled binding; creator attribution remains |

## Automated findings and triage

Bandit baseline: 28 findings (1 high, 14 medium, 13 low). High B324 is SHA-1 for graph node IDs, not password/security hashing. Eight B608 reports use fixed SQL clauses/table selections and generated placeholders with bound user values in the inspected paths; no exploitable interpolation established. Six B615 findings cover unpinned training model downloads and remain supply-chain risks. Low reports include non-cryptographic animation/dataset randomness, subprocess use and ignored exceptions. No scanner suppressions added.

pip-audit of the installed Python test environment returned 12 advisory entries for pip 25.0.1, including duplicates (six unique advisory IDs). Reported fixes extend through pip 26.2.0. This is a tooling finding, not evidence of 12 MAI runtime vulnerabilities. Optional training/voice packages were not installed/audited. Source ranges are not a lockfile. The public Windows installer already upgrades pip; audit the resulting installation.

## Release gate

Suitable as a source preview for review, not production sign-off. Publishing requires the owner's confirmation of repository, licensing and any persona/source-reference material they wish to make public. Original private build is unchanged. Git history was not available and has not been scanned. An archive without a secret does not establish that earlier commits lack it; rotate any previously exposed credentials.

The packaged source is tested separately after public configuration changes. See the delivered verification summary for the exact result; baseline v0.9.5 had 129 passing tests and one skipped.
