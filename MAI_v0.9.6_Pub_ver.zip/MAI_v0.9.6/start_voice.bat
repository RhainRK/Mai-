@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo MAI environment not found. Run setup_windows.ps1 first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" doctor.py
if errorlevel 1 (
    pause
    exit /b 1
)
".venv\Scripts\python.exe" voice_doctor.py
if errorlevel 1 (
    echo.
    echo Run install_voice.bat first.
    pause
    exit /b 1
)
echo.
".venv\Scripts\python.exe" voice_main.py
pause
