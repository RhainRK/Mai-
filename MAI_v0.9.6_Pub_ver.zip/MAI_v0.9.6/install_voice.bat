@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo MAI environment not found. Run setup_windows.ps1 first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -m pip install -r requirements-voice.txt
if errorlevel 1 (
    echo Voice package installation failed.
    pause
    exit /b 1
)
echo.
".venv\Scripts\python.exe" voice_doctor.py
if errorlevel 1 (
    echo.
    echo Voice packages installed, but voice_doctor found a problem.
    pause
    exit /b 1
)
pause
