@echo off
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo MAI is not installed yet.
    echo Run setup_windows.ps1 first.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" doctor.py
if errorlevel 1 (
    echo.
    echo Fix the items above, then try again.
    pause
    exit /b 1
)

echo.
echo Testing model response...
".venv\Scripts\python.exe" smoke_test.py
if errorlevel 1 (
    echo.
    echo Ollama is running but the model response test failed.
    pause
    exit /b 1
)

echo.
".venv\Scripts\python.exe" main.py
pause
