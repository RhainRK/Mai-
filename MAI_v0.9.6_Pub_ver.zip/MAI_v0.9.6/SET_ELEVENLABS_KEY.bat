@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0configure_elevenlabs_key.ps1"
if errorlevel 1 (
  echo.
  echo ElevenLabs setup failed.
  pause
)
endlocal
