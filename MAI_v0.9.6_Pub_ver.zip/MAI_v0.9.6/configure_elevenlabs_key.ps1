$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$EnvFile = Join-Path $Root ".env"
$VoiceId = ""

if (-not (Test-Path $EnvFile)) {
    Copy-Item (Join-Path $Root ".env.example") $EnvFile
}

$Secure = Read-Host "Paste your ElevenLabs API key" -AsSecureString
$Ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
try {
    $ApiKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($Ptr)
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($Ptr)
}

if ([string]::IsNullOrWhiteSpace($ApiKey)) {
    throw "No API key entered. Nothing was changed."
}

$Lines = Get-Content $EnvFile
function Set-EnvValue([string[]]$InputLines, [string]$Name, [string]$Value) {
    $Prefix = "$Name="
    $Found = $false
    $Out = foreach ($Line in $InputLines) {
        if ($Line.StartsWith($Prefix)) {
            $Found = $true
            "$Name=$Value"
        } else {
            $Line
        }
    }
    if (-not $Found) { $Out += "$Name=$Value" }
    return ,$Out
}

$Lines = Set-EnvValue $Lines "MAI_VOICE_TTS_BACKEND" "auto"
$Lines = Set-EnvValue $Lines "MAI_ELEVENLABS_API_KEY" $ApiKey
$Lines = Set-EnvValue $Lines "MAI_ELEVENLABS_VOICE_ID" $VoiceId
Set-Content -Path $EnvFile -Value $Lines -Encoding UTF8

Write-Host ""
Write-Host "MAI voice configured." -ForegroundColor Green
Write-Host "Voice ID: $VoiceId"
Write-Host "You can now run start_mai.bat and use /voice-test."
Write-Host ""
Read-Host "Press Enter to close"
