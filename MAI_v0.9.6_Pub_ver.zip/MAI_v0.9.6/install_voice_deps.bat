@echo off
cd /d "%~dp0"
call install_voice.bat
