from idol import IdolAgent
from idol.realtime_voice import EXIT
from idol.version import __version__


COMMANDS = (
    "/talk /voice-loop /mic-test /voice-test /voices /audio-devices "
    "/avatar-status /avatar-test /avatar-idle-test /avatar-expression /avatar-look /realtime "
    "/interview /identity /creator /canon /timeline /career-add /career-stats "
    "/continuity /decision /continuity-history /continuity-stats /memory-map "
    "/teach /skills /skill /practice /chess /goals /goal /work "
    "/tools /actions /state /profile /memories /memory-stats /forget "
    "/model /stats /trace /traces /trace-stats /reset-session /quit"
)


def chess_command(idol: IdolAgent, args: str):
    if idol.chess is None:
        print("Chess support requires python-chess.")
        return
    parts = args.strip().split(maxsplit=1)
    command = parts[0].casefold() if parts else "board"
    value = parts[1] if len(parts) > 1 else ""
    try:
        if command == "new":
            print(idol.chess.new_game())
        elif command == "board":
            print(idol.chess.board_text())
        elif command == "fen":
            print(idol.chess.fen())
        elif command == "move":
            print(idol.chess.play(value))
        elif command == "hint":
            print(idol.chess.hint())
        elif command == "analyse":
            print(idol.chess.analyse())
        elif command == "state":
            print(idol.chess.state())
        else:
            print(idol.chess.play(args))
    except Exception as exc:
        print(f"Chess error: {exc}")


def main():
    print(f"MAI v{__version__} Avatar Bridge")
    print("Commands:", COMMANDS)
    idol = IdolAgent()
    try:
        while True:
            try:
                text = input("You > ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nMAI > See you later.")
                break
            if not text:
                continue
            if text == "/quit":
                print("MAI > See you later.")
                break
            if text.startswith("/interview "):
                question = text[len("/interview "):].strip()
                if not question:
                    print("Use: /interview question")
                    continue
                try:
                    print("MAI [public] > " + idol.interview(question))
                except Exception as exc:
                    print(f"Interview error: {exc}")
                continue
            if text == "/identity":
                print(idol.identity_info())
                continue
            if text == "/creator":
                print(idol.creator_info())
                continue
            if text == "/canon":
                print(idol.canon())
                continue
            if text == "/timeline":
                print(idol.timeline())
                continue
            if text == "/career-stats":
                print(idol.career.stats())
                continue
            if text.startswith("/career-add "):
                parts = [part.strip() for part in text[len("/career-add "):].split("|", 3)]
                if len(parts) < 3:
                    print("Use: /career-add type | title | summary | visibility")
                    continue
                event_type, title, summary = parts[:3]
                visibility = parts[3] if len(parts) == 4 and parts[3] else "public"
                try:
                    print(
                        idol.record_career_event(
                            event_type,
                            title,
                            summary,
                            visibility=visibility,
                        )
                    )
                except Exception as exc:
                    print(f"Career event error: {exc}")
                continue
            if text == "/continuity":
                print(idol.continuity_current())
                continue
            if text.startswith("/continuity "):
                memory_type = text[len("/continuity "):].strip() or None
                try:
                    print(idol.continuity_current(memory_type))
                except Exception as exc:
                    print(f"Continuity error: {exc}")
                continue
            if text.startswith("/decision "):
                parts = [part.strip() for part in text[len("/decision "):].split("|", 3)]
                if len(parts) < 2:
                    print("Use: /decision key | value | reason | visibility")
                    continue
                key, value = parts[:2]
                reason = parts[2] if len(parts) >= 3 else ""
                visibility = parts[3] if len(parts) == 4 and parts[3] else "private"
                try:
                    print(
                        idol.set_continuity(
                            "creative",
                            key,
                            value,
                            reason=reason,
                            visibility=visibility,
                        )
                    )
                except Exception as exc:
                    print(f"Decision error: {exc}")
                continue
            if text.startswith("/continuity-history "):
                key = text[len("/continuity-history "):].strip()
                if not key:
                    print("Use: /continuity-history key")
                    continue
                try:
                    print(idol.continuity_history(key))
                except Exception as exc:
                    print(f"Continuity history error: {exc}")
                continue
            if text == "/continuity-stats":
                print(idol.continuity_stats())
                continue
            if text == "/memory-map":
                print(idol.memory_map())
                continue
            if text == "/realtime":
                try:
                    import asyncio
                    asyncio.run(idol.create_realtime_session().run())
                except Exception as exc:
                    print(f"Realtime error: {exc}")
                continue
            if text == "/talk":
                try:
                    if idol.create_live_voice_session().one_turn() is EXIT:
                        print("Voice turn cancelled.")
                except Exception as exc:
                    print(f"Voice error: {exc}")
                continue
            if text == "/voice-loop":
                try:
                    idol.create_live_voice_session().run()
                except Exception as exc:
                    print(f"Voice error: {exc}")
                continue
            if text == "/mic-test":
                try:
                    heard = idol.create_live_voice_session().capture_text()
                    print(f"Heard > {heard or '[nothing]'}")
                except Exception as exc:
                    print(f"Microphone error: {exc}")
                continue
            if text == "/voice-test":
                try:
                    text = "Hi, I'm MAI. Voice output is working."
                    path = idol.speak(text)
                    idol.play_voice(path, text)
                    print("Voice output OK.")
                except Exception as exc:
                    print(f"Voice error: {exc}")
                continue
            if text == "/voices":
                voices = idol.voices()
                if voices:
                    print("Installed voices:")
                    for voice in voices:
                        print(f"- {voice}")
                else:
                    print("No Windows speech voices found.")
                continue
            if text == "/audio-devices":
                for device in idol.audio_devices():
                    print(
                        f"[{device['index']}] {device['name']} "
                        f"({device['channels']} ch)"
                    )
                continue
            if text == "/avatar-status":
                print(idol.avatar_status())
                continue
            if text == "/avatar-test":
                sent = idol.avatar_test()
                print("Avatar event sent." if sent else "Avatar event not sent.")
                continue
            if text == "/avatar-idle-test":
                sent = idol.avatar_idle_test()
                print("Avatar motion cues sent." if sent else "Avatar motion cues not sent.")
                continue
            if text.startswith("/avatar-expression "):
                parts = text.split()
                name = parts[1] if len(parts) >= 2 else "neutral"
                try:
                    intensity = float(parts[2]) if len(parts) >= 3 else 0.7
                except ValueError:
                    print("Use: /avatar-expression name [intensity], where intensity is 0 to 1")
                    continue
                sent = idol.avatar_expression(name, intensity)
                print("Avatar expression sent." if sent else "Avatar expression not sent.")
                continue
            if text.startswith("/avatar-look "):
                parts = text.split()
                if len(parts) < 3:
                    print("Use: /avatar-look x y [hold_ms], where x/y are -1 to 1")
                    continue
                try:
                    x = float(parts[1])
                    y = float(parts[2])
                    hold_ms = int(parts[3]) if len(parts) >= 4 else 1400
                except ValueError:
                    print("Use: /avatar-look x y [hold_ms], where x/y are numbers")
                    continue
                sent = idol.avatar_look(x, y, hold_ms)
                print("Avatar gaze sent." if sent else "Avatar gaze not sent.")
                continue
            if text.startswith("/teach "):
                payload = text[7:]
                if "|" not in payload:
                    print("Use: /teach skill | lesson")
                    continue
                skill, lesson = payload.split("|", 1)
                print(idol.teach(skill, lesson))
                continue
            if text == "/skills":
                print(idol.skills())
                continue
            if text.startswith("/skill "):
                print(idol.skill(text[7:].strip()))
                continue
            if text.startswith("/practice "):
                parts = [part.strip() for part in text[10:].split("|", 4)]
                if len(parts) < 4:
                    print("Use: /practice skill | task | result | score | feedback")
                    continue
                skill, task, result, score_text = parts[:4]
                feedback = parts[4] if len(parts) == 5 else ""
                try:
                    score = None if score_text.casefold() == "none" else float(score_text)
                except ValueError:
                    print("Use: /practice skill | task | result | score | feedback; score must be a number or none")
                    continue
                idol.record_practice(skill, task, result, score, feedback)
                print("Practice recorded.")
                continue
            if text.startswith("/chess"):
                chess_command(idol, text[6:].strip())
                continue
            if text == "/goals":
                print(idol.tasks.list("all"))
                continue
            if text.startswith("/goal "):
                print(idol.tasks.get(text[6:].strip()))
                continue
            if text.startswith("/work"):
                parts = text.split()
                goal_id = parts[1] if len(parts) >= 2 else None
                try:
                    cycles = int(parts[2]) if len(parts) >= 3 else 1
                except ValueError:
                    print("Use: /work [goal_id] [cycles], where cycles is an integer")
                    continue
                print(idol.work(goal_id, cycles))
                continue
            if text == "/tools":
                print(idol.available_tools())
                continue
            if text == "/actions":
                print(idol.recent_actions())
                continue
            if text == "/state":
                print(idol.state_dict())
                continue
            if text == "/profile":
                print(idol.profile())
                continue
            if text == "/memories":
                print(idol.memories())
                continue
            if text == "/memory-stats":
                print(idol.memory_stats())
                continue
            if text.startswith("/forget "):
                try:
                    memory_id = int(text[8:].strip())
                    print("Forgotten." if idol.forget_memory(memory_id) else "Memory not found.")
                except ValueError:
                    print("Use: /forget memory_id")
                continue
            if text == "/model":
                print(f"Model: {idol.active_model}")
                continue
            if text == "/stats":
                print(idol.metrics())
                continue
            if text == "/trace":
                print(idol.trace())
                continue
            if text.startswith("/trace "):
                print(idol.trace(text[7:].strip()))
                continue
            if text == "/traces":
                print(idol.traces())
                continue
            if text.startswith("/traces "):
                try:
                    print(idol.traces(int(text[8:].strip())))
                except ValueError:
                    print("Use: /traces [limit]")
                continue
            if text == "/trace-stats":
                print(idol.trace_stats())
                continue
            if text == "/reset-session":
                idol.reset_session()
                print("Session history cleared.")
                continue
            try:
                print("MAI > ", end="", flush=True)
                wrote = False
                for chunk in idol.stream_respond(text):
                    print(chunk, end="", flush=True)
                    wrote = True
                if wrote:
                    print()
                metrics = idol.metrics()
                wall = metrics.get("wall_seconds") or 0.0
                rate = metrics.get("tokens_per_second")
                if rate:
                    print(f"[{wall:.1f}s | {rate:.1f} tok/s]\n")
                elif wall:
                    print(f"[{wall:.1f}s]\n")
                else:
                    print()
            except Exception as exc:
                print(f"\nError: {exc}")
    finally:
        idol.close()


if __name__ == "__main__":
    main()
