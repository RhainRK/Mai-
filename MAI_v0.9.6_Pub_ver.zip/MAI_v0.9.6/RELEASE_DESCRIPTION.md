# MAI v0.9.6 — Public Security Preview

MAI is a local-first AI character runtime combining persistent memory, configurable identity, typed tools, speech integration and avatar control.

This experimental release incorporates the v0.9.5 reliability fixes and prepares the source for public distribution.

## Highlights

- Turn-level tool allowlists and explicit permission handling.
- Superseded-memory filtering and durable session summary batches.
- Conversation-aware history compression without elevating excerpts into system instructions.
- Incremental Python code indexing with stale-source cleanup.
- Public configuration disables automatic creator recognition and removes the account-specific voice preset.
- Credential, database, audio and cache exclusions, plus security documentation and audit findings.

## Installation

Extract the source, copy `.env.example` to `.env`, and configure your own services and voice ID. See the Windows setup guide. Back up your existing installation and database before upgrading; do not replace your private identity configuration with the public sample unintentionally.

## Status

Publish as a pre-release. Not a security certification, complete plugin replacement or internet-facing service. Live voice/avatar tests, optional dependency audits and a complete privacy-erasure workflow remain outstanding. Read SECURITY_AUDIT.md.

Suggested tag: `v0.9.6`. Source package only; no model weights, credentials or personal conversation database included. No open-source license has been selected by this release preparation.
